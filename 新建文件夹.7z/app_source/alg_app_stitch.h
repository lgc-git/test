﻿#ifndef _ALG_APP_STITCH_H_
#define _ALG_APP_STITCH_H_

#define DLL_EXPORTS extern "C" __declspec(dllexport)
#define DLL_CLASSEXP __declspec(dllexport)
#include "dataStructure.h"
#include "stitchConfig.h"
#include<vector>
namespace stitchAlg
{
	/**
	 * @brief 测试dump接口，实现一个野指针赋值触发崩溃
	 */

	DLL_EXPORTS void _ALG_STITCH_DumpTrigger();

	/**
	 * @brief 项目初始化操作
	 */
	DLL_EXPORTS void _ALG_STITCH_Init();

	/**
	 *  @brief 拼接app handle
	 */
	typedef void* STITCH_HANDLE;

	/**
	 * @brief 从cacheDir加载stitch app
	 * 
	 * @author yqligc (yqligc@sunnyoptical.com)
	 * @date 2025-03-25
	 * 
	 * @param cacheDir 
	 * @param processType 
	 * @return STITCH_HANDLE 
	 * 
	 */
	DLL_EXPORTS STITCH_HANDLE _ALG_STITCH_LoadStitchApp(const std::string& cacheDir, const std::string& processType);

	/**
	 * @brief 平台建模
	 * 
	 * @author yqligc (yqligc@sunnyoptical.com)
	 * @date 2025-03-25
	 * 
	 * @param handle 
	 * @return int 
	 * 
	 */
	DLL_EXPORTS int _ALG_STITCH_PlatformModel(const STITCH_HANDLE handle);

	/**
	 * @brief 偏移量校正
	 * 
	 * @author yqligc (yqligc@sunnyoptical.com)
	 * @date 2025-03-25
	 * 
	 * @param handle 
	 * @return int 
	 * 
	 */
	DLL_EXPORTS int _ALG_STITCH_RefineMatch(const STITCH_HANDLE handle);

	/**
	 * @brief 路径规划
	 * 
	 * @author yqligc (yqligc@sunnyoptical.com)
	 * @date 2025-03-25
	 * 
	 * @param handle 
	 * @return int 
	 * 
	 */
	DLL_EXPORTS int _ALG_STITCH_PathPlanning(const STITCH_HANDLE handle);

	/**
	 * @brief 拼接质量评估
	 * 
	 * @author yqligc (yqligc@sunnyoptical.com)
	 * @date 2025-03-25
	 * 
	 * @param handle 
	 * @param fScore 输出分数
	 * @return int 
	 * 
	 */
	DLL_EXPORTS int _ALG_STITCH_Evaluate(const STITCH_HANDLE handle, float& fScore);

	//模拟通用拼接流程
	/**
		* @fn	_ALG_STITCH_CreateStitchApp(const StitchConfig& initParam);
		*
		* @brief	_ALG_STITCH_CreateStitchApp函数作用：初始化拼接相关参数 
		* 			入参:
		* 			  initParam: 输入自定义初始化参数结构体
		* @author	Yqtangfy
		* @date	2025/2/11
		*
		* @returns	An HANDLE.
	**/
	DLL_EXPORTS STITCH_HANDLE _ALG_STITCH_CreateStitchApp(const StitchConfig& stitchParams);
	/**
	* @fn	int _ALG_STITCH_PostImageOnce(const STITCH_HANDLE handle, const SyImage& image, const int relativeRowId, const int relativeColId);;
	*
	* @brief	_ALG_STITCH_PostImageOnce函数作用：逐步输入图像数据 
	*			入参:
	* 			   handle:句柄信息; relativeRowId:扫描图像行坐标, relativeColId:扫描图像列坐标;
	*
	* @author	Yqtangfy
	* @date	2025/2/11
	*
	* @returns	An Int.
	**/
	DLL_EXPORTS	int _ALG_STITCH_PostImageOnce(const STITCH_HANDLE handle, const SyImage& image, const int relativeRowId, const int relativeColId);
	/**
	* @fn	bool _ALG_STITCH_PostImageFinish(const STITCH_HANDLE handle);
	*
	* @brief	_ALG_STITCH_PostImageFinish函数作用：提示图像输入已经结束
	*           入参:	
	*				handle:句柄信息	
	* @author	Yqtangfy
	*
	* @date	2025/2/11
	*
	*  @returns	An Int.
	**/
	DLL_EXPORTS int _ALG_STITCH_PostImageFinish(const STITCH_HANDLE handle);

	/**
	* @fn	int _ALG_STITCH_MatchImageOver(const STITCH_HANDLE handle, float** pImgCoordinate);
	*
	* @brief	isMatchOverStitchApp函数作用：判断拼接是否结束 
	*           入参:  
	*				handle:句柄信息
	*           出参: 
	*				pImgCoordinate: 输出仿射变换矩阵		 
	*
	* @author	Yqtangfy
	* @date	2025/2/11
	*
	* @returns	An Int;
	**/
	DLL_EXPORTS int _ALG_STITCH_MatchImageOver(const STITCH_HANDLE handle);
	/**
	* @fn	bool _ALG_STITCH_GetWSISize(const STITCH_HANDLE handle, int& width, int& height, float** pImgCoordinate=nullptr);
	*
	* @brief	_ALG_STITCH_GetWSISize函数作用：输出拼接大图的宽和高,以及所有图像的全局偏移量
	*           入参:
	*				handle:全局句柄, width 拼接后大图宽, height:拼接后大图高
	*			出参: 
	*				float** pImgCoordinate,输出图像全局坐标
	*
	* @author	Yqtangfy
	* @date	2025/2/24
	*
	* @returns	An Int.
	**/
	DLL_EXPORTS int _ALG_STITCH_GetWSISize(const STITCH_HANDLE handle, int& width, int& height, float** pImgCoordinate=nullptr);
	/**
	* @fn	int _ALG_STITCH_WSIBlender(const STITCH_HANDLE handle, SyImage& image);
	*
	* @brief	_ALG_STITCH_WSIBlender函数作用：拼接缝融合
	*           入参:
	*             handle:全局句柄信息
	*           出参:
	* 			  image: 输出拼接后大图
	*
	* @author	Yqtangfy
	* @date	2025/2/11
	*
	* @returns	An Int.
	**/
	DLL_EXPORTS int _ALG_STITCH_WSIBlender(const STITCH_HANDLE handle, SyImage& image);
	/**
	* @fn	int _ALG_STITCH_ClearStitchApp(const STITCH_HANDLE handle);
	*
	* @brief	_ALG_STITCH_ClearStitchApp函数作用：拼接结束后清理相关变量 
	*			入参:
	* 			  handle: 全局句柄
	*
	* @author	Yqtangfy
	* @date	2025/2/11.
	*
	* @returns	An Int.
	**/
	DLL_EXPORTS int _ALG_STITCH_ClearStitchApp(const STITCH_HANDLE handle);
}
#endif
