#include "alg_app_stitch.h"
#include "commitid.h"
#include "alg_base_common.h"
#include "stitchApp.h"
#include"stitchEvaluateDll.h"
namespace  stitchAlg
{
	std::string getCommitID_appStitch()
	{
		return COMMIT_ID_APP_STITCH;
	}

	void _ALG_STITCH_DumpTrigger()
    {
		dumpTrigger_baseCommon();
        return;
    }

	void printComId()
	{
		std::string strCommitId_baseCommon = getCommitID_baseCommon();
		LOG_INFO("default", "CommitId_baseCommon:" + strCommitId_baseCommon);
		std::cout << "CommitId_baseCommon: " << strCommitId_baseCommon << std::endl;

		std::string strCommitId_baseMatching = getCommitID_baseMatching();
		LOG_INFO("default", "CommitId_baseMatching:" + strCommitId_baseMatching);
		std::cout << "CommitId_baseMatching: " << strCommitId_baseMatching << std::endl;

		std::string strCommitId_appStitch = getCommitID_appStitch();
		LOG_INFO("default", "CommitId_appStitch:" + strCommitId_appStitch);
		std::cout << "CommitId_appStitch: " << strCommitId_appStitch << std::endl;
	}

	void _ALG_STITCH_Init()
    {
		commonInit();
		printComId();
        return ;
    }

	int _ALG_STITCH_CreateStitchApp_INVOKE( const StitchConfig& stitchParams, STITCH_HANDLE& handle)
	{
		//����ƴ��app�������������߳�
		StitchApp* stitchObj = new StitchApp(stitchParams);
		int flag = stitchObj->init();
		if (flag == 1)
		{
			handle = (STITCH_HANDLE)stitchObj;
		}
		else
		{
			delete stitchObj;
			handle = nullptr;
		}
		return flag;
	}

	STITCH_HANDLE _ALG_STITCH_CreateStitchApp(const StitchConfig& stitchParams)
	{
		STITCH_HANDLE handle;
		int resFlag = INVOKE_METHOD(_ALG_STITCH_CreateStitchApp_INVOKE, stitchParams, handle);
		return handle;
	}
	int _ALG_STITCH_LoadStitchApp_INVOKE(const std::string& cacheDir, const std::string& processType, STITCH_HANDLE& handle)
	{
		//����ƴ��app�������������߳�
		StitchApp* stitchObj = new StitchApp();
		int flag = stitchObj->init(cacheDir, processType);
		if (flag == 1)
		{
			handle = (STITCH_HANDLE)stitchObj;
		}
		else
		{
			delete stitchObj;
			handle = nullptr;
		}
		return flag;
	}

	STITCH_HANDLE _ALG_STITCH_LoadStitchApp(const std::string& cacheDir, const std::string& processType) 
	{
		STITCH_HANDLE handle;
		int resFlag = INVOKE_METHOD(_ALG_STITCH_LoadStitchApp_INVOKE, cacheDir, processType, handle);
		return handle;
	}



	int _ALG_STITCH_PostImageOnce_INVOKE(const STITCH_HANDLE handle, const SyImage& image, const int relativeRowId, const int relativeColId) 
	{
		StitchApp* stitchObj = (StitchApp*)handle;
		cv::Mat input(image.height, image.width, image.type, image.data);
		Position world_coor(relativeRowId, relativeColId);
		stitchObj->postImage(input, world_coor);
		return INFO_OK;
	}

	int _ALG_STITCH_PostImageOnce(const STITCH_HANDLE handle, const SyImage& image, const int relativeRowId, const int relativeColId) 
	{
		return INVOKE_METHOD(_ALG_STITCH_PostImageOnce_INVOKE, handle, image, relativeRowId, relativeColId);
	}

	//������ͼ
	int _ALG_STITCH_PostImageFinish_INVOKE(const STITCH_HANDLE handle) 
	{
		StitchApp* stitchObj = (StitchApp*)handle;
		return stitchObj->postFinish();
	}

	int _ALG_STITCH_PostImageFinish(const STITCH_HANDLE handle) 
	{
		return INVOKE_METHOD(_ALG_STITCH_PostImageFinish_INVOKE, handle);
	}

	//ƽ̨��ģ
	int _ALG_STITCH_PlatformModel_INVOKE(const STITCH_HANDLE handle) 
	{
		StitchApp* stitchObj = (StitchApp*)handle;
		return stitchObj->platformModel();
	}
	int _ALG_STITCH_PlatformModel(const STITCH_HANDLE handle) 
	{
		return INVOKE_METHOD(_ALG_STITCH_PlatformModel_INVOKE, handle);
	}

	//ƫ��������
	int _ALG_STITCH_RefineMatch_INVOKE(const STITCH_HANDLE handle) 
	{
		StitchApp* stitchObj = (StitchApp*)handle;
		return stitchObj->refineMatch();
	}
	int _ALG_STITCH_RefineMatch(const STITCH_HANDLE handle) 
	{
		return INVOKE_METHOD(_ALG_STITCH_RefineMatch_INVOKE, handle);
	}

	//·���滮
	int _ALG_STITCH_PathPlanning_INVOKE(const STITCH_HANDLE handle) 
	{
		StitchApp* stitchObj = (StitchApp*)handle;
		return stitchObj->pathPlanning();
	}
	int _ALG_STITCH_PathPlanning(const STITCH_HANDLE handle) 
	{
		return INVOKE_METHOD(_ALG_STITCH_PathPlanning_INVOKE, handle);
	}
	//��ȡƴ��ͼ�ߴ�
	int _ALG_STITCH_GetWSISize_INVOKE(const STITCH_HANDLE handle, int& width, int& height, float** pImgCoordinate)
	{
		StitchApp* stitchObj = (StitchApp*)handle;

		return stitchObj->getWSISize(width, height, pImgCoordinate);
	}
	
	int _ALG_STITCH_GetWSISize(const STITCH_HANDLE handle, int& width, int& height, float** pImgCoordinate)
	{
		return INVOKE_METHOD(_ALG_STITCH_GetWSISize_INVOKE, handle, width, height, pImgCoordinate);
	}

	//��ȡƴ�Ӵ�ͼ
	int _ALG_STITCH_WSIBlender_INVOKE(const STITCH_HANDLE handle, SyImage& image)
	{
		StitchApp* stitchObj = (StitchApp*)handle;
		return stitchObj->blender(image);
	}

	int _ALG_STITCH_WSIBlender(const STITCH_HANDLE handle, SyImage& image) 
	{

		return INVOKE_METHOD(_ALG_STITCH_WSIBlender_INVOKE, handle, image);
	}

	int _ALG_STITCH_Evaluate_INVOKE(const STITCH_HANDLE handle, float& fScore)
	{
		StitchApp* stitchObj = (StitchApp*)handle;
		return stitchObj->evaluateApp(fScore);
	}
	int _ALG_STITCH_Evaluate(const STITCH_HANDLE handle, float& fScore)
	{
		return INVOKE_METHOD(_ALG_STITCH_Evaluate_INVOKE, handle, fScore);
	}

	//���app
	int _ALG_STITCH_ClearStitchApp_INVOKE(const STITCH_HANDLE handle)
	{
		StitchApp* stitchObj = (StitchApp*)handle;
		delete stitchObj;
		return 1;
	}
	int _ALG_STITCH_ClearStitchApp(const STITCH_HANDLE handle) 
	{
		return INVOKE_METHOD(_ALG_STITCH_ClearStitchApp_INVOKE, handle);
	}

	int _ALG_STITCH_MatchImageOver_INVOKE(const STITCH_HANDLE handle)
	{
		int resFlag;
		resFlag = _ALG_STITCH_PlatformModel(handle);
		if (resFlag != 1)
		{
			LOG_ERROR("default", "_ALG_STITCH_PlatformModel ERROR!");
			return resFlag;
		}
		resFlag = _ALG_STITCH_RefineMatch(handle);
		if (resFlag != 1)
		{
			LOG_INFO("default", "_ALG_STITCH_RefineMatch ERROR!");
			return resFlag;
		}
		resFlag = _ALG_STITCH_PathPlanning(handle);
		if (resFlag != 1)
		{
			LOG_INFO("default", "_ALG_STITCH_PathPlanning ERROR!");
			return resFlag;
		}

		return 1;
	}

	int _ALG_STITCH_MatchImageOver(const STITCH_HANDLE handle)
	{
		return INVOKE_METHOD(_ALG_STITCH_MatchImageOver_INVOKE, handle);
	}
}

