from conan import ConanFile
from conan.tools.cmake import CMakeToolchain, CMake, cmake_layout, CMakeDeps
from conan.tools.files import copy
import os 
class alg_app_stitch(ConanFile):
    name = "alg_app_stitch"
    version = "1.0.0"
    package_type = "library"

    # Optional metadata
    license = "<Put the package license here>"
    author = ""
    url = "<Package recipe repository url here, for issues about the package>"
    description = "<Description of alg_app_stitch package here>"
    topics = (" stitch", "...")

    # Binary configuration
    settings = "os", "compiler", "build_type", "arch"
    options = {"shared": [True, False], "fPIC": [True, False], "gpu_support": [True, False]}
    default_options = {"shared": False, "fPIC": True, "gpu_support": True}

    # Sources are located in the same place as this recipe, copy them to the recipe
    exports_sources = "CMakeLists.txt", "src/*", "include/*"
    def package_id(self):
        #忽略编译器信息
        self.info.settings.rm_safe("compiler.version")
    def config_options(self):
        if self.settings.os == "Windows":
            self.options.rm_safe("fPIC")
    def layout(self):
        cmake_layout(self)
    def generate(self):
        deps = CMakeDeps(self)
        deps.generate()
        tc = CMakeToolchain(self)
        # 根据 Conan 选项设置 CMake 变量
        if self.options.gpu_support:
            tc.variables["GPU_SUPPORT"] = "ON"
        else:
            tc.variables["GPU_SUPPORT"] = "OFF"
        tc.generate()
        
        #将第三方库移动到exe目录下
        cmake = CMake(self)
        cmake.configure()
        cmake.build()
        
        alg_evaluate = self.dependencies.get("stitchevaluate")
        if alg_evaluate is None:
            print("alg_evaluate dependency not found.")
            return
        evaluate_source_file = os.path.join(alg_evaluate.package_folder, "bin")
       
        # 自定义构建类型
        build_type = str(self.settings.build_type)  # 可以是 "Release" 或 "RelWithDebInfo"
        build_director = self.build_folder;
        target_directory = os.path.join(build_director, build_type)  # 你需要确保 self.build_folder 是有效的目录
        if not os.path.isdir(target_directory):
            print(f"target_directory does not exist: {target_directory}")
            os.makedirs(target_directory)  # 创建目录，包括所有必要的父目录
            return
        # 拷贝 stitchevaluate.dll
        copy(self, "stitchevaluate.dll", evaluate_source_file, target_directory, keep_path=False)
        print(f"evaluate_source_file directory: {evaluate_source_file} to target_directory: {target_directory}")
        
    def build(self):#conan-build的时候未启用
        print("Build method started.")
        cmake = CMake(self)
        #用于在CMakeLists区分是实时调试还是打包发布
        cmake.configure(cli_args=["-DCONAN_CREATE_BUILD=1"])#conanbuild会导致不构建_test项目库
        cmake.build()
    print("package method started before.")    
    def package(self):
        cmake = CMake(self)
        cmake.install()
        print("package method started end.")
    def package_info(self):
        self.cpp_info.libs = ["alg_app_stitch"]
 
    def requirements(self):
        self.requires("alg_base_common/[1.2.19]")
        self.requires("syopencv/4.6.0")
        self.requires("alg_base_matching/[^1.0.9]")
        self.requires("nlohmann_json/[^3.11.3]")
        self.requires("stitchevaluate/[^1.0.0]")
        if self.options.gpu_support:
            self.requires("sycuda/11.0.0")

