﻿#pragma once
#include <string>
enum TileProducerType
{
	eTileProducerDefault = 0,
};

enum TaskProducerType
{
	eTaskProducerDefault = 0,
};

enum TaskConsumerType
{
	eTaskConsumerDefault = 0,
	eTaskConsumerSIFT = 1,
	eTaskConsumerCUDANCC = 2,
};

enum PlatformModelType
{
	ePlatformModelDefault = 0,
	ePlatformModelDefaultV2 = 1,
};

enum RefineConsumerType
{
	eRefineConsumerDefault = 0,
};

enum PathPlanningType
{
	ePathPlanningDefault = 0,
	ePathPlanningNearest = 1
};

enum StitchBlenderType
{
	eStitchBlenderDefault = 0,
	eStitchBlenderBoardWeight = 1,
	eStitchBlenderBoardWeightTiff = 2,
	eStitchBlenderBoardPyr = 3
};

enum StitchEvaluateType
{
	eEvaluateNCC = 0,
};

struct StitchConfig
{
	TileProducerType tileProducerType = TileProducerType::eTileProducerDefault;
	TaskProducerType taskProducerType = TaskProducerType::eTaskProducerDefault;
	TaskConsumerType taskConsumerType = TaskConsumerType::eTaskConsumerDefault;
	PlatformModelType platformModelType = PlatformModelType::ePlatformModelDefault;
	RefineConsumerType refineConsumerType = RefineConsumerType::eRefineConsumerDefault;
	PathPlanningType pathPlanningType = PathPlanningType::ePathPlanningDefault;
	StitchBlenderType stitchBlenderType = StitchBlenderType::eStitchBlenderBoardWeight;
	StitchEvaluateType stitchEvaluateType = StitchEvaluateType::eEvaluateNCC;

	int matchTaskConsumerNum = 4;
	int refineTaskConsumerNum = 4;

	int maxTaskQueueSize = 80;

	//图像保存模式
	bool storeInMemory = true;
	bool copyImage = true;
	//文件内存映射需要的参数 storeInMemory为false时启用
	std::string _mappingFileDir = "./mappingImg/";

	//输入图像尺寸
	int imageHeight = 0;
	int imageWidth = 0;
	int imageChannels = 3;

	//Stage model parameters
	/*
	* 该值表示显微镜载物台与移动载物台的机械装置相关的不确定性。
	* 设置此值可能会增加用于查找相邻图像之间正确转换的搜索空间。该值以像素为单位指定。
	*/
	float stageRepeatabilityX = 5;
	float stageRepeatabilityY = 5;

	//水平方向重叠比例
	float horizontalOverlap = 0.2;

	//垂直方向重叠比例
	float verticalOverlap = 0.2;

	/*
	* 在平移优化期间，使用用户指定的重叠不确定性来计算平台的可重复性。
	* 将此字段留空以使用默认值。修改此字段将有助于纠正应该增加重叠不确定性的翻译。
	* 该值以百分比指定。提示：值不应超过 20.0，默认为 5.0
	*/ 
	float overlapUncertainty = 5;
	float validCorrelationThreshold = 0.3;

	//Cache存储一些过程中的信息便于debug
	std::string cacheDir = "";
};


