﻿#pragma once
#include <map>
#include <functional>
#include <memory>

template<typename BaseType>
struct factory
{
	template<typename DerivedType>
	struct register_t
	{
		register_t(const std::string& key)
		{
			factory::get().map_.emplace(key, [] { return new DerivedType(); });
		}

		template<typename... Args>
		register_t(const std::string& key, Args... args)
		{
			factory::get().map_.emplace(key, [=] { return new DerivedType(args...); });
		}
	};

	static BaseType* produce(const std::string& key)
	{
		if (map_.find(key) == map_.end())
			return nullptr;

		return map_[key]();
	}

	static std::unique_ptr<BaseType> produce_unique(const std::string& key)
	{
		return std::unique_ptr<BaseType>(produce(key));
	}

	static std::shared_ptr<BaseType> produce_shared(const std::string& key)
	{
		return std::shared_ptr<BaseType>(produce(key));
	}

private:
	factory() {};
	factory(const factory&) = delete;
	factory(factory&&) = delete;

	static factory& get()
	{
		static factory instance;
		return instance;
	}

	static std::map<std::string, std::function<BaseType*()>> map_;
};

