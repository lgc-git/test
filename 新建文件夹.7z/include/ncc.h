﻿#pragma once
#include "opencv2/opencv.hpp"
#include <xmmintrin.h>

#define MM_EXTRACT_FLOAT(v,i)  _mm_cvtss_f32(_mm_shuffle_ps(v, v, _MM_SHUFFLE(0, 0, 0, i)))
#define MM_EXTRACT_DOUBLE(v,i) _mm_cvtsd_f64(_mm_shuffle_pd(v, v, _MM_SHUFFLE2(0, i)))

int computeNCC_8UC1(const cv::Mat& a1, const cv::Mat& a2, double& nccVal);
