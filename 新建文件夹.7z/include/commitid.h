#pragma once
#define COMMIT_ID_APP_STITCH "fd9a024" 