#pragma once
#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>
#include <iterator>
#include <cmath>
#include <stack> 
#include <limits>
#include <algorithm>
#include <opencv2/cudafeatures2d.hpp>
#include <opencv2/xfeatures2d.hpp>
#include <opencv2/xfeatures2d/cuda.hpp>

class node {
public:
	float x;
	float y;
	node() {}
	~node() {}

	node(float a, float b) {
		x = a;
		y = b;
	}
	bool operator==(node node)
	{
		return ((this->x == node.x) && this->y == node.y);
	}
	bool operator < (const node &n) const
	{
		if (x < n.x)
			return true;
		else if (x == n.x)
			if (y < n.y)
				return true;

		return false;
	}
};

class point {
public:
	float x;
	float y;
	std::vector<node> nds;
	point() {}
	~point() {}

	point(float a, float b) {
		x = a;
		y = b;
		node t(a, b);
		nds.push_back(t);
	}
};

float stringToFloat(std::string i);

float EuclideanDistance(point a, point b);

float ManhattenDistance(point a, point b);

void HierarchicalClustering(std::vector<point>& dataset, int dis_thresh = 1);


void HierarchicalClustering_match(std::vector<point>& dataset,
	std::vector<int> imgStatus_left, std::vector<int> imgStatus_right,
	std::vector<int> imgStatus_top, std::vector<int> imgStatus_down, int col);

void HierarchicalClustering_match_new(std::vector<point>& dataset,
	std::vector<int> imgStatus_left, std::vector<int> imgStatus_right,
	std::vector<int> imgStatus_top, std::vector<int> imgStatus_down, int row, int col);

void HierarchicalClustering_match_fast(std::vector<point>& dataset,
	std::vector<int> imgStatus_left, std::vector<int> imgStatus_right,
	std::vector<int> imgStatus_top, std::vector<int> imgStatus_down, int row, int col);

int HierarchicalClustering_match_faster(std::vector<point>& dataset,
	std::vector<int> imgStatus_left, std::vector<int> imgStatus_right,
	std::vector<int> imgStatus_top, std::vector<int> imgStatus_down, int row, int col);

std::vector<cv::Point2f> PointsFilter_ClusteringV2(std::vector<cv::Point2f> inputs, int dis_thresh = 1, float good_rate = 0.4);
