﻿#pragma once
#include <memory>
#include <opencv2/opencv.hpp>
#include "stitchDataStruct.h"
#include "factory.h"
#include "stitchConfig.h"
// Tile 生产
class TileProducerDefault
{
public:
	TileProducerDefault();
	~TileProducerDefault();
	void setStitchConfig(const StitchConfig & config);
	virtual std::shared_ptr<Tile> tileProduce(void* ptr_Mapping);
private:
	StitchConfig _config;

};

