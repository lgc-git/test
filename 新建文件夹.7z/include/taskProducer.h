﻿#pragma once
#include <memory>
#include "opencv2/opencv.hpp"
#include "stitchDataStruct.h"
// Task 生产
class TaskProducerDefault
{
public:
	TaskProducerDefault();
	~TaskProducerDefault();
	virtual std::shared_ptr<Task> taskProduce(const std::shared_ptr<Tile>& t1_ptr, const std::shared_ptr<Tile>& t2_ptr, const Position & relativeGridCoor, const cv::Point& relativeOffset, const cv::Point& platformDeviationCoor);
};

