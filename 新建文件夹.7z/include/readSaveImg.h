#pragma once
#include <windows.h>
#include <opencv2/opencv.hpp>
#include <string>
#include<iostream>
#include<alg_base_common.h>
// ����ͼ�񵽴�����
int saveMatToDiskStitch(const cv::Mat &in_Img, const std::string &name_Str, ESaveMode saveMode);
//
int readMapingImgStitch(std::string imgPath, cv::Mat& outImg);