﻿#pragma once
#include <memory>
#include "opencv2/opencv.hpp"
#include "stitchDataStruct.h"

struct SPathInfo
{
	std::string regularPathStr = "";
};
// 路径规划
class PathPlanningDefault
{
public:
	PathPlanningDefault();
	~PathPlanningDefault();
	virtual int pathPlanning(std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, const SPathInfo& pathIn) = 0;
};


class PathPlanningKruskal: public PathPlanningDefault
{
public:
	struct sEdge
	{
		Position start;
		Position end;
		double val;
		static bool cmp(const sEdge& a, const sEdge& b) { return a.val > b.val; };
	};

	struct dsu
	{
		dsu(const std::vector<Position>& nodes);
		std::unordered_map<Position, Position, Position::Hash> pa;

		Position find(Position& key);

		void unite(Position& x, Position& y);

	};
	PathPlanningKruskal() = default;
	~PathPlanningKruskal() {};
	int pathPlanning(std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, const SPathInfo& pathIn) final;
};

class PathPlanningNearest : public PathPlanningDefault
{
public:
	PathPlanningNearest() = default;
	~PathPlanningNearest() {};

	bool comparePoints(const Position& a, const Position& b);
	int pathPlanning(std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, const SPathInfo& pathIn) final;
};
