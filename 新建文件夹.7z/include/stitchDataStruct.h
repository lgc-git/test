﻿#pragma once
#include <atomic>
#include <memory>
#include <nlohmann/json.hpp>
#include "opencv2/opencv.hpp"
#include <unordered_map>

struct ComparePoint {
	bool operator()(const cv::Point& p1, const cv::Point& p2) const {
		return p1.y < p2.y || (p1.y == p2.y && p1.x < p2.x);
	}
};

struct cvPointHash {
	std::size_t operator()(const cv::Point& key) const {
		return std::hash<int>()(key.x) ^ std::hash<int>()(key.y);
	}
};
struct cvSizeHash {
	std::size_t operator()(const cv::Size& key) const {
		return std::hash<int>()(key.width) ^ std::hash<int>()(key.height);
	}
};
struct MatchInfo
{
	cv::Point offset = { 0, 0 };
	double precison = 0;
};

struct Position
{
	int _row = 0;
	int _col = 0;
	Position() {};
	Position(const int& row, const int& col) { _row = row; _col = col; };

	//operator cv::Point() const { return cv::Point(_col, _row); };

	Position operator+(const Position &b) const { return Position(b._row + _row, b._col + _col); };
	Position operator-(const Position &b) const { return Position(_row - b._row, _col - b._col); };
	bool operator == (const Position &b) const { return bool(b._row == _row && b._col == _col); };
	bool operator != (const Position &b) const { return !bool(b._row == _row && b._col == _col); };

	struct Hash {
		std::size_t operator()(const Position & key) const {return std::hash<int>()(key._row) ^ std::hash<int>()(key._col);}
	};
};

class Tile
{
public:
	Tile() = default;
	Tile(const bool storeInMemory, const bool clone, void* ptr_Mapping, const std::string& cacheDir);
	~Tile();
	Position _grid_coor;					// tile grid 坐标 （grid_colid, grid_rowid）
	cv::Point _global_coor;					// tile 左上角全局坐标全局
	int matchFlags[4] = { -1,-1,-1,-1 };	//上 右 下 左;
	MatchInfo matchInfos[4];				//上 右 下 左;  //以当前tile为中心，其他四个方向tile相对于中心tile的偏移量

	int saveMat(const cv::Mat& input, const Position & grid_coor);
	cv::Mat getMat();
	void cacheMat(const std::string& cacheDir, const bool & storeOrNot = false);

	nlohmann::json toJson();
	void fromJson(const nlohmann::json& jsonObj);

	std::string getRowColKeyStr();

private:
	bool _store_in_memory = false;
	bool _clone = false;
	void* _ptr_Mapping = nullptr;
	cv::Mat _input;
	std::string _path;
	std::string _cacheDir;
};


class Task
{
public:
	Task() = default;
	Task(const std::shared_ptr<Tile>& t1_ptr, const std::shared_ptr<Tile>& t2_ptr, const Position& relativeGridCoor, const cv::Point& relativeGlobalCoor, const cv::Point& platformDeviationCoor);
	~Task();
	std::shared_ptr<Tile> _t1_ptr;
	std::shared_ptr<Tile> _t2_ptr;
	Position _relativeGridCoor; //t2相对与t1的grid坐标偏移
	cv::Point _relativeGlobalCoor;	//t2相对于t1的像素坐标偏移
	cv::Point _platformDeviationCoor; //平台偏差范围

	nlohmann::json toJson();
	void fromJson(const nlohmann::json& jsonObj, const std::shared_ptr<Tile>& t1_ptr, const std::shared_ptr<Tile>& t2_ptr);

};


template<typename Key, typename Value, typename Hash = std::hash<Key>>
class TileMap :public std::unordered_map<Key, Value, Hash>
{
public:
	std::pair<typename std::unordered_map<Key, Value, Hash>::iterator, bool> insert(const Key& key, const Value& value, const std::string& cacheDir);
	typename std::unordered_map<Key, Value, Hash>::iterator find(const Key& key);

	int width() { return grid_coor_max_col - grid_coor_min_col + 1; };
	int height() { return grid_coor_max_row - grid_coor_min_row + 1; };
	Position tl() { return Position(grid_coor_min_row, grid_coor_min_col); };
	Position br() { return Position(grid_coor_max_row, grid_coor_max_col); };

	nlohmann::json toJson();
	void fromJson(const nlohmann::json& jsonObj, const std::string& cacheDir);
	bool storeOrNot = false;
private:
	int grid_coor_min_row = 0;
	int grid_coor_max_row = 0;
	int grid_coor_min_col = 0;
	int grid_coor_max_col = 0;
	std::mutex mtx;

};

class TaskQueue
{
public:
	TaskQueue() = default;
	TaskQueue(const int& max_task_queue_size);
	~TaskQueue();
	void setMaxQueueSize(const int& maxQueueSize);
	void setProduceFinish();
	void push(std::shared_ptr<Task>& task);
	bool take(std::shared_ptr<Task>& task);
private:
	std::queue<std::shared_ptr<Task>> taskQueue;
	std::mutex mtx;
	std::condition_variable cv;
	std::atomic<bool> produceFinish = false; // 状态量

	int _max_task_queue_size = 40;
};

class AtomicTaskQueue
{
public:
	AtomicTaskQueue();
	~AtomicTaskQueue();
	void push(std::shared_ptr<Task>& task);
	bool take(std::shared_ptr<Task>& task);
	nlohmann::json toJson();
	int fromJson(nlohmann::json& jsonObj, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap);
	std::queue<std::shared_ptr<Task>> taskQueue;
	std::mutex mtx;
};

