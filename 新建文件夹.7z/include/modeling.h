﻿#pragma once
#include <memory>
#include <opencv2/opencv.hpp>
#include "stitchDataStruct.h"
#include"alg_base_common.h"

// 对外输出接口
#define DLL_CLASSEXP __declspec(dllexport)

//std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap



// 配置表
struct ModelingArgs
{
	// 图像大小
	int imageWidth = 0;
	int imageHeight = 0;
	// 重叠的不确定性
	float overlapUncertainty = 3.0;

	// 上右下左重叠率
	float upOverlap = -1;
	float rightOverlap = -1;
	float downOverlap = -1;
	float leftOverlap = -1;
	float horizontalOverlap = 30.0;
	float verticalOverlap = 30.0;
	// 上下左右平台精度
	float upRepeatability = -1;
	float rightRepeatability = -1;
	float downRepeatability = -1;
	float leftRepeatability = -1;
	// 输入的平台建模精度
	float stageRepeatability = 5.0;

	// ncc阈值
	float validCorrelationThreshold = 0.3;
	// 最大
	const int NUMBER_STABLE_MLE_ITERATIONS = 20;
	// 设置有限数
	float finite = 100000;
	// pi
	float pi = 3.1415926;
	// 极小值
	float epsilon = 0.0001;

	// 替换最值
	float paddingNcc = -FLT_MAX;
	// 更改值标记位
	int label = 1;

};


// 爬坡结构体
struct MlePoint
{
	int piUni = 0;
	int mu = 0;
	int sigma = 0;
	float likelihood = -FLT_MAX;
};


namespace std
{
	template <>
	struct hash<std::tuple<std::string, int, int, int>>
	{
		size_t operator()(const std::tuple<std::string, int, int, int>& key) const
		{
			std::string str = std::get<0>(key) + "," + std::to_string(std::get<1>(key)) + "," + std::to_string(std::get<2>(key)) + "," + std::to_string(std::get<3>(key));
			return std::hash<std::string>{}(str);
		}
	};
}

// 平台建模
class DLL_CLASSEXP ModelingDefault
{
public:
	// 构造函数
	ModelingDefault();

	// 析构函数
	~ModelingDefault();

	// 建模初始化
	void Init(int imageWidth, int imageHeight, float overlapUncertainty, float validCorrelationThreshold, float horizontalOverlap, float verticalOverlap);

	// 模型参数配置
	void ModelingArgsInit(int imageWidth, int imageHeight, float overlapUncertainty, float validCorrelationThreshold, float horizontalOverlap, float verticalOverlap);

	// 判断是否有效
	bool IsValid(MlePoint newPoint);

	// 用于平台建模，并返回偏移量，主要针对上右下左4个方向分别进行建模
	int newBuild(std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap);

	// 计算各方向的重叠率，目前方向分为上右下左
	int ComputerOverlapDirection(const std::string direction, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, float& overlap);

	// 计算各方向的偏移量，目前方向分为上右下左
	int GetTranslationDirection(const std::string direction, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, std::vector<int32_t>& translations);

	// 获取该方向图像尺寸，目前方向分为上右下左
	int GetImageSizeDirection(const std::string direction, int& hOrW);

	// 过滤各方向不在图像范围的偏移量
	int FilterTranslationsImageRange(const std::vector<int32_t> translations, const int hOrW, std::vector<int32_t>& newTranslations);

	// 将重叠率转成百分比
	int TranslationsToPercentage(const std::vector<int32_t> newTranslations, int hOrW, std::vector<float>& translationsPercentage);

	// 极大似然估计，去找point最合适的值
	int MleDirection(const std::string direction, std::vector<float> translationsPercentage, float& overlap);

	// 随机生成起始点
	void RandomMlePoint(MlePoint& point);

	// 使用参数空间中的百分位分辨率爬山算法来计算MLE模型。
	void HillClimbSearchDirection(const std::string direction, MlePoint& point, const std::vector<float> translations);

	// 计算爬坡值
	void computeLikelihoodDirection(MlePoint& point, const std::vector<float> translations);

	// 计算各方向的平台精度
	int ComputeRepeatabilityDirection(const std::string direction, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, float& repeatability);

	// 过滤各方向偏移量
	int FilterTranslationsDirection(const std::string direction, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, int& validCount);

	// 根据方向设置重叠度和平移阈值
	int ComputeParametersDirection(const std::string direction, int height, int width, float& overlap, float& tMin, float& tMax, float& overlapError);

	// 过滤偏移量，得到有效数据集
	int GetValidTranslation(const std::string direction, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, const float tMin, const float tMax, const float overlapError, int& validCount);

	// 三道过滤，分别是ncc,有效范围和正交误差，此处ncc过滤掉会改成2， 有效范围过滤会改成3， 正交误差过滤会改成4
	int FilterDirection(const std::string direction, std::shared_ptr<Tile>& tile, const float tMin, const float tMax, const float overlapError);

	// 用四分位数法过滤有效值
	int QuartileFilterDirection(const std::string direction, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap);

	// 几个各方向的异常值过滤
	int LclFilterDirection(const std::string direction, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, const std::string displacement);

	// 对某个方向的数据进行有效值收集
	int ExtractValsDirection(std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, const std::string direction, const std::string displacement, std::vector<int32_t>& tVals);

	// 计算中位数和四分位数
	int ComputeFilterParametersDirection(const std::vector<int32_t> tVals, float& medianData, float& upQuartileData, float& downQuartileData, float& quartileDistance);

	// 计算平台精度1
	int repeatabilityOneDirection(const std::string direction, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, float& repeatability);

	// 计算平台精度2
	int repeatabilityTwoDirection(const std::string direction, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, float& repeatability);

	// 在各方向上应用模型
	int ApplyModelDirection(const std::string direction, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap);

	// 重叠度建模
	int OverlapApplyModelDirection(const std::string direction, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap);

	// 根据方向对有效tile集进行过滤
	int FilterTranslationPerDirection(const std::string direction, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, std::unordered_map<int, int>& medXVals, std::unordered_map<int, int>& medYVals);

	// 填充有行列tile数据
	int ReplaceTranslationDirection(const std::string direction, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, std::unordered_map<int, int> medXVals, std::unordered_map<int, int> medYVals);

	// 填充其余tile的数据
	int ReplaceOtherTranslationDirection(const std::string direction, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap);

	// 随机生成爬坡起始点
	int GetRandomPoint(MlePoint& point);

	// 计算爬坡的值
	int computeLikelihood(MlePoint& point, std::vector<float> translations);

	// 计算中位数
	int Median(const std::vector<int> tVals, float& medianData);

public:
	// 配置参数
	ModelingArgs args;

	// 重叠率部分
	// 上方向重叠率
	float upOverlap = 0;
	// 右方向重叠率
	float rightOverlap = 0;
	// 下方向重叠率
	float downOverlap = 0;
	// 左方向重叠率
	float leftOverlap = 0;


	// 平台精度
	// 上方向平台精度
	float upRepeatability = 0;
	// 右方向平台精度
	float rightRepeatability = 0;
	// 下方向平台精度
	float downRepeatability = 0;
	// 左方向平台精度
	float leftRepeatability = 0;

	// 总平台精度
	int repeatability = 5;


	// 定义爬坡方向
	std::vector<std::vector<int>> mleHillClimbDirection = { { 1, 0, 0 },
															{ -1, 0, 0 },
															{ 0, 1, 0 },
															{ 0, -1, 0 },
															{ 0, 0, 1 },
															{ 0, 0, -1 },
															{ 0, 0, 0 }, };

	// 异常权值
	float weight = 1.5;

	// 缓存结构
	std::unordered_map<std::tuple<std::string, int, int, int>, float> likelihoodCache;

};

