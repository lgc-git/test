﻿#pragma once
#include "alg_base_common.h"
#include <memory>
#include <opencv2/opencv.hpp>
#include <unordered_map>
#include "stitchDataStruct.h"
#include "stitchConfig.h"
#include "alg_base_matching.h"
#include "cluster.h"
#include "errorInfo.h"
// Task 消费

class TaskConsumerDefault
{
public:
	TaskConsumerDefault();
	virtual ~TaskConsumerDefault();
	void setId(const int& id) { _id = id; return; };
	int getId() { return _id; };
	void setConfig(const StitchConfig& config) { _config = config; };
	virtual int taskConsume(const std::shared_ptr<Task>& task_ptr);
	std::queue<std::shared_ptr<Task>> finishedTasks;

	// 提取图像的矩形区域
	cv::Mat extract_subregion(const cv::Mat& t1, int x, int y);
	//峰值搜索
	void peaksearch(cv::Mat& PCM, int& num_peaks, std::vector<double>& max_value, std::vector<cv::Point>& max_Loc);
private:
	int _id = -1;
	StitchConfig _config;

	struct PCC_type {
		 
		int x;
		int y;
		double value;
	};

	//计算PCM
	int computePCM(cv::Mat& I1, cv::Mat& I2, cv::Mat& pcm_Mat);

	//计算PCC
	int computePCC(const cv::Mat& I1, const cv::Mat& I2, std::string& direction, cv::Point& Loc, std::vector<int>& m, std::vector<int>& n, std::vector<double>& value);

	int matchOption_PCIAM(const cv::Mat& preImg, const cv::Mat& curImg, const cv::Point& inputBias, int matchOriten, cv::Point& outputBias, double& matchValue);

	cv::Mat PCM;
	cv::Mat CPS;

	cv::Mat Img1_DFT;
	cv::Mat Img2_DFT;

};

class TaskConsumerSIFT : public TaskConsumerDefault
{
public:
	TaskConsumerSIFT();
	~TaskConsumerSIFT();

	virtual int taskConsume(const std::shared_ptr<Task>& task_ptr);

private:
	// 基于SIFT特征点的图像匹配
	int matchOption_SIFT(const cv::Mat& img_in1, const cv::Mat& img_in2, const cv::Point& inputPtBias, int matchOriten, cv::Point& outputPtBias, double& matchValue);

	SiftData featureData1;
	SiftData featureData2;
	siftMatchParam matchParam;
};


