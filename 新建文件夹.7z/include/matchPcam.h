#pragma once
#include "errorInfo.h"
#include"alg_base_matching.h"

struct PCC_type {

	int x;
	int y;
	double value;
};

//����PCM
cv::Mat calculate_PCM(cv::Mat& I1, cv::Mat& I2);
//��ֵ����
void peaksearch_PCM(cv::Mat& PCM, int& num_peaks, std::vector<double>& max_value, std::vector<cv::Point>& max_Loc);
//����PCC
int calculate_PCC(const cv::Mat& I1, const cv::Mat& I2, std::string& direction, cv::Point& Loc, std::vector<int>& m, std::vector<int>& n, std::vector<double>& value);

int matchOption_PCIAM(const cv::Mat& preImg, const cv::Mat& curImg, const cv::Point& inputBias, int matchOriten, cv::Point& outputBias, double& matchValue);