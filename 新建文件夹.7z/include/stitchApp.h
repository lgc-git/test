﻿#pragma once
#include <memory>
#include <thread>
#include "opencv2/opencv.hpp"
#include "registerManager.h"
#include "stitchDataStruct.h"
#include "stitchConfig.h"
#include "alg_base_common.h"
#include "alg_base_matching.h"
#include "evaluate.h"

class StitchApp
{
public:
	StitchApp() = default;

	StitchApp(const StitchConfig& params);

	~StitchApp();

	int init();

	int init(const std::string& cacheDir, const std::string& processType);

	int postImage(const cv::Mat& input, const Position & world_coor);

	int postFinish();

	int platformModel();

	int refineMatch();

	int pathPlanning();

	int getWSISize(int& wsiWidth, int& wsiHeight,float** pImgCoordinate);

	int blender(SyImage& image);

	void saveConfig(const std::string& saveDir);

	int loadConfig(const std::string& saveDir);

	void saveTileMapInfos(const std::string& saveDir, const std::string& processName);

	int loadTileMap(const std::string& saveDir, const std::string& processName);

	void saveFinishedTaskVec(const std::string& saveDir);

	int loadFinishedTaskVec(const std::string& saveDir);

	int evaluateApp(float& fScore);
private:
	//配置参数
	StitchConfig _params;
	// tile的生产类
	std::shared_ptr<TileProducerDefault> tileProducer;
	// 存图
	void saveImage(const cv::Point & world_coor, const cv::Mat & input);


	// taskd的生产类
	std::shared_ptr<TaskProducerDefault> taskProducer;

	// 全局grid
	TileMap<Position, std::shared_ptr<Tile>, Position::Hash> tileMap;

	// 内存映射文件指针
	void* ptr_Mapping = nullptr;
	// 内存映射文件保存位置
	std::string _mappingFileDir;
	
	// 两两拼接消费者线程
	std::vector<std::thread> taskConsumerThreads;
	// 两两拼接消费者
	std::vector<std::shared_ptr<TaskConsumerDefault>> taskConsumers;
	// 两两拼接消费者方法
	int taskConsumeFunc(std::shared_ptr<TaskConsumerDefault>& consumer);
	// 两两拼接任务队列
	TaskQueue taskQueue;

	// 完成两两拼接的任务队列
	AtomicTaskQueue finishedTaskVec;

	// 平台建模模块
	std::shared_ptr<ModelingDefault> platformModelObj;

	// 最小生成数路径规划
	std::shared_ptr<PathPlanningDefault> pathPlannObj;

	SunnyMatchRefineParam refineParam;
	// refine 消费者线程
	std::vector<std::thread> refineConsumerThreads;
	// refine 消费者
	std::vector<std::shared_ptr<RefineConsumerDefault>> refineConsumers;
	// refine 消费者方法
	int refineConsumeFunc(std::shared_ptr<RefineConsumerDefault>& consumer);

	// blender方法
	std::shared_ptr<BlenderDefault> blenderObj;
	//图像评价方法
	std::shared_ptr<CEvaluateDefault> evaluateObj;

};
