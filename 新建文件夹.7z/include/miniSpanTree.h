

#ifndef ALG_MINI_SPAN_TREE_H
#define ALG_MINI_SPAN_TREE_H
#include<vector>
#include<string>
#include<map>
#include<opencv2/opencv.hpp>
#include<alg_base_matching.h>
/**
 * @def	DLL_EXPORTS
 *
 * @brief	A macro that defines DLL exports
 *
 * @author	Yqxiaochong
 * @date	2024/11/25
**/

#define DLL_EXPORTS extern "C" __declspec(dllexport)

/**
 * @def	INF
 *
 * @brief	最大值定义
 *
 * @author	Yqxiaochong
 * @date	2024/11/25
**/

#define INF 0x3f3f3f3f

typedef struct
{
	int vexRowA;
	int vexColA;
	int vexRowB;
	int vexColB;
	float fMatchScore;
	int offsetX;
	int offsetY;
}InMST;

typedef struct
{
	int vexRowA;
	int vexColA;
	int globalOffsetX;
	int globalOffsetY;
}OutMST;

/**
 * @struct	IntSyVex2D
 *
 * @brief	两个顶点
 *
 * @author	Yqxiaochong
 * @date	2024/12/9
**/

typedef struct
{
	/** @brief	点a */
	int a;
	/** @brief	点b */
	int b;
}IntSyVex2D;

/**
 * @struct	UoffsetCoord
 *
 * @brief	相对偏移量
 *
 * @author	Yqxiaochong
 * @date	2024/12/9
**/

typedef struct
{
	/** @brief	X方向偏移 */
	int offsetX;
	/** @brief	Y方向偏移 */
	int offsetY;
}UoffsetCoord;

/**
 * @struct	UGlobalOffset
 *
 * @brief	全局偏移量
 *
 * @author	Yqxiaochong
 * @date	2024/12/10
**/

typedef struct
{
	/** @brief	X方向全局偏移 */
	int globalOffsetX;
	/** @brief	Y方向全局偏移 */
	int globalOffsetY;
}UGlobalOffset;

/**
 * @struct	SCompare
 *
 * @brief	用于map中自定义结构体，直接初始化
 *
 * @author	Yqxiaochong
 * @date	2024/12/10
**/

struct SCompare {

	/**
	 * @fn	bool operator()(const IntSyVex2D& a, const IntSyVex2D& b) const
	 *
	 * @brief	Function call operator
	 *
	 * @author	Yqxiaochong
	 * @date	2024/12/10
	 *
	 * @param  a	An IntSyVex2D to process.
	 * @param  b	An IntSyVex2D to process.
	 *
	 * @returns	The result of the operation.
	**/

	bool operator()(const IntSyVex2D& a, const IntSyVex2D& b) const {
		if (a.a != b.a) return a.a < b.a;
		return a.b < b.b;
	}
};

/**
 * @fn DLL_EXPORTS void createGraph_sample(UGraph &G, std::vector<IntSyVex2D>& connectEdge, std::vector<float>& fMatchScores, int verTexNum);
 *
 * @brief	创建图功能实现函数 参数：图G  insertNode 作用：创建图
 *
 * @author	Yqxiaochong
 * @date	2024/12/5
 *
 * @param [in,out] G		   	A Graph to process.
 * @param [in,out] connectEdge 	连接边的两个端点的集合.
 * @param [in,out] fMatchScores	表示边的权重的集合.
 * @param 		   verTexNum   	表示顶点的数量.
**/

DLL_EXPORTS void createGraph_simple(UGraph &G, std::vector<IntSyVex2D>& connectEdge, std::vector<float>& fMatchScores, int verTexNum);

/**
 * @fn DLL_EXPORTS void prim_sample(UGraph& G, std::vector<IntSyVex2D>&connectPoint, std::map<int, std::vector<int>>& treeIndexMap, int orderTree, std::string filePath = "no Path");
 *
 * @brief	prim函数作用:prim最小生成树路径规划
 *
 * @author	Yqxiaochong
 * @date	2024/11/25
 *
 * @param [in,out] G		   	自定义图的数据结构.
 * @param [in,out] connectPoint	连接边的两个顶点的集合.
 * @param [in,out] treeIndexMap	键值对,键表示基础端点,值表示与端点相连的其他端点.
 * @param 		   orderTree   	表示第几个生成树,支持多孤岛图像,根据每个孤岛图像集构建成一个树.
 * @param 		   filePath	   	(Optional) 根据文件夹路径是否存在确认是否保存路径规划结果,方便后续异常排查.
**/

DLL_EXPORTS void prim_simple(UGraph& G, std::vector<IntSyVex2D>&connectPoint, std::map<int, std::vector<int>>& treeIndexMap, int orderTree, std::string filePath = "no Path");

/**
 * @fn DLL_EXPORTS void globalCoordinateBuild(UGraph uGraph, std::map<int, std::vector<int>> treeIndexMap,std::map<IntSyVex2D, UoffsetCoord, SCompare> mOffsetCoord, std::vector<UGlobalOffset>& vGlobalOffse);
 *
 * @brief	生成全局坐标
 *
 * @author	Yqxiaochong
 * @date	2024/12/9
 *
 * @param 		   uGraph	   	自定义图的数据结构.
 * @param 		   treeIndexMap	键值对,键表示基础端点,值表示与基础端点相连的其他端点.
 * @param 		   mOffsetCoord	键值对,键表示两个顶点，值表示偏移坐标信息.
 * @param [in,out] vGlobalOffse	全局坐标偏移.
**/

DLL_EXPORTS void globalCoordinateBuild(UGraph uGraph, std::map<int, std::vector<int>> treeIndexMap,std::map<IntSyVex2D, UoffsetCoord, SCompare> mOffsetCoord, std::vector<UGlobalOffset>& vGlobalOffse);

/**
 * @fn DLL_EXPORTS void drawMiniSpanTreeInImg(std::vector<cv::Mat> vImg, std::vector<IntSyVex2D> connectEdge, std::vector<float> fMatchScores, std::map<int, std::vector<int>> treeIndexMap, std::vector<UGlobalOffset> vGlobalOffse, float fResize);
 *
 * @brief	Draw mini span tree in image
 *
 * @author	Yqxiaochong
 * @date	2024/12/10
 *
 * @param  vImg		   	一组待拼接的图像.
 * @param  connectEdge 	连接边的两个顶点的集合.
 * @param  fMatchScores	表示边的权重的集合.
 * @param  treeIndexMap	键值对,键表示基础端点,值表示与基础端点相连的其他端点.
 * @param  vGlobalOffse	全局坐标偏移.
 * @param  fResize	   	图像缩放因子.
**/

DLL_EXPORTS void drawMiniSpanTreeInImg(std::vector<cv::Mat> vImg, std::map<int, cv::Point> mapVex2Point, std::vector<IntSyVex2D> connectEdge, std::vector<float> fMatchScores, std::map<int, std::vector<int>> treeIndexMap, std::vector<UGlobalOffset> vGlobalOffse, float fResize);

#endif