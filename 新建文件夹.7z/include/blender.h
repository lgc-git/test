﻿#pragma once
#include <memory>
#include <opencv2/opencv.hpp>
#include "stitchDataStruct.h"
#include"dataStructure.h"
#include"alg_base_common.h"


//将拼接图像的全局坐标转换为组成图像间的全局坐标
int globalCoordinateConvertLocalCoordinate(std::vector<cv::Point>& coordinates, cv::Rect& baseRect, int& maxX, int& maxY, int& minX, int & minY);

//对多张图像组成的矩形区域进行拼接缝融合及裁剪
void imgsOverlapWithBlockFusion(cv::Rect& blockRect, cv::Mat& fusionBlockMat, const cv::Mat& weightMap, const std::vector<cv::Mat>& overlapRectImgs, std::vector<cv::Point> & imgsPoints, std::vector<cv::Rect> overlapBlockRects);

class BlenderDefault
{
public:
	BlenderDefault();
	virtual ~BlenderDefault();
	//计算拼接大图的宽高
	int stitchWidthHeightCalcute(std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, int & stitch_Width, int& stitch_Height, float** pImgCoordinate);
	//图像拼接无融合
	virtual int blender(const std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, SyImage* pImg_out);
};


class CBoarderWeightFusion: public BlenderDefault
{
public:
	CBoarderWeightFusion();
	~CBoarderWeightFusion();
	//图像拼接+边界加权融合
	int blender(const std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tiles_Map, SyImage* pImg_out) override;
};

class CBoarderPyrFusion : public BlenderDefault
{
public:
	CBoarderPyrFusion();
	~CBoarderPyrFusion();
	//图像拼接+双加权融合
	int blender(const std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tiles_Map, SyImage* pImg_out) override;
};
