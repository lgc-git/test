﻿#pragma once
#include <memory>
#include <opencv2/opencv.hpp>
#include "stitchDataStruct.h"
#include "alg_base_matching.h"
// 偏移量校正
class RefineConsumerDefault
{
public:
	RefineConsumerDefault();
	~RefineConsumerDefault();
	int id = 0;

	virtual int refineTaskConsume(const std::shared_ptr<Task>& task_ptr, const SunnyMatchRefineParam & refineParam);

private:
	int refineShiftProcessBaseNccMatch(const cv::Mat& img_in1, const cv::Mat& img_in2, const cv::Point& inputPtBias, cv::Point& outputPtBias, const SunnyMatchRefineParam& refineParam, float& fPrecision);

};