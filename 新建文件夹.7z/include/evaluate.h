#pragma once
#include <memory>
#include <opencv2/opencv.hpp>
#include "stitchDataStruct.h"
#include"dataStructure.h"
#include"stitchEvaluateDll.h"

class CEvaluateDefault
{
public:
	CEvaluateDefault();
	virtual ~CEvaluateDefault();
	//ͼ��ƴ�����ں�
	virtual int evaluate(const std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, float& fScore);
};