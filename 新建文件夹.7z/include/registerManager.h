﻿#pragma once
#include <string>
#include "stitchDataStruct.h"
#include "tileProducer.h"
#include "taskProducer.h"
#include "taskConsumer.h"
#include "refineConsumer.h"
#include "pathPlanning.h"
#include "modeling.h"
#include "blender.h"
#include"evaluate.h"

// 使用工厂模式，对模块进行注册， https://www.cnblogs.com/qicosmos/p/5090159.html

#define REGISTER_CLASS_VNAME(BaseType, DerivedType) reg_##BaseType##_##DerivedType##_
//初始化模块注册表
std::map<std::string, std::function<TileProducerDefault*()>> factory<TileProducerDefault>::map_;
std::map<std::string, std::function<TaskProducerDefault*()>> factory<TaskProducerDefault>::map_;
std::map<std::string, std::function<TaskConsumerDefault*()>> factory<TaskConsumerDefault>::map_;
std::map<std::string, std::function<ModelingDefault*()>> factory<ModelingDefault>::map_;
std::map<std::string, std::function<RefineConsumerDefault*()>> factory<RefineConsumerDefault>::map_;
std::map<std::string, std::function<PathPlanningDefault*()>> factory<PathPlanningDefault>::map_;
std::map<std::string, std::function<BlenderDefault*()>> factory<BlenderDefault>::map_;
std::map<std::string, std::function<CEvaluateDefault*()>>factory<CEvaluateDefault>::map_;

template<typename BaseType, typename DerivedType, typename keyType>
void register_class_once(const keyType& key);

template<typename BaseType, typename DerivedType, typename keyType, typename... Args>
void register_class_once(keyType& key, Args... args);

void registerClass();


