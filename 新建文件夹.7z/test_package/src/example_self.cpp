#include "example.h"
#include "alg_app_stitch.h"
#include "stitchConfig.h"
#include "alg_base_common.h"
#include <iostream>
#include "opencv2/opencv.hpp"
#include <random>  
using namespace std;
using namespace cv;
using namespace stitchAlg;

int test_stitch() 
{
	_ALG_STITCH_Init();

	string imageDir = PathUtils::getParentDirectory(__FILE__) + "/data/exp4";
	int row_num = 3;
	int col_num = 3;

	StitchConfig stitchParams;
	STITCH_HANDLE  stitch_handle = _ALG_STITCH_CreateStitchApp(stitchParams);
	if (stitch_handle == nullptr) 
	{
		cout << "create stitch app error!" << endl;
		return -1;
	}
	int sourceType = -1;
	for (size_t i = 0; i < row_num; i++)
	{
		for (size_t j = 0; j < col_num; j++)
		{
			if (i == 1 && j == 1)
			{
				continue;
			}
			string imagepath = imageDir + "/" + to_string(i) + "_" + to_string(j) + ".bmp";
			Mat input = cv::imread(imagepath, -1);
			
			SyImage image;
			image.data = input.data;
			image.height = input.rows;
			image.width = input.cols;
			image.type = input.type();
			sourceType = input.type();
			int flag = _ALG_STITCH_PostImageOnce(stitch_handle, image, i, j);
			if (flag != 1)
			{
				cout << imagepath << endl;
			}
		}
	}
	int flag = _ALG_STITCH_PostImageFinish(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PostImageFinish error!" << endl;
	}

	flag = _ALG_STITCH_RefineMatch(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_RefineMatch error!" << endl;
	}

	flag = _ALG_STITCH_PathPlanning(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PathPlanning error!" << endl;
	}


	int resWidth, resHeight;
	_ALG_STITCH_GetWSISize(stitch_handle, resWidth, resHeight);

	Mat res(resHeight, resWidth, sourceType, Scalar::all(0));
	SyImage resImage;
	resImage.data = res.data;
	resImage.width = res.cols;
	resImage.height = res.rows;
	resImage.type = res.type();
	_ALG_STITCH_WSIBlender(stitch_handle, resImage);

	_ALG_STITCH_ClearStitchApp(stitch_handle); 
	return 1;
}

int test_stitchSaveApp()
{
	_ALG_STITCH_Init();

	string imageDir = PathUtils::getParentDirectory(__FILE__) + "/data/exp5";

	int row_num = 9;
	int col_num = 10;

	StitchConfig stitchParams;
	stitchParams.cacheDir = "./Cache";
	stitchParams.matchTaskConsumerNum = 1;
	stitchParams.imageHeight = 1536;
	stitchParams.imageWidth = 2048;
	stitchParams.imageChannels = 3;
	stitchParams.horizontalOverlap = 0.3;
	stitchParams.verticalOverlap = 0.3;

	STITCH_HANDLE  stitch_handle = _ALG_STITCH_CreateStitchApp(stitchParams);
	if (stitch_handle == nullptr)
	{
		cout << "create stitch app error!" << endl;
		return -1;
	}
	int sourceType = -1;
	for (size_t i = 0; i < row_num; i++)
	{
		for (size_t j = 0; j < col_num; j++)
		{
			string imagepath = imageDir + "/" + to_string(i) + "_" + to_string(j) + ".bmp";
			Mat input = cv::imread(imagepath, -1);

			SyImage image;
			image.data = input.data;
			image.height = input.rows;
			image.width = input.cols;
			image.type = input.type();
			sourceType = input.type();
			int flag = _ALG_STITCH_PostImageOnce(stitch_handle, image, i, j);
			if (flag != 1)
			{
				cout << imagepath << endl;
			}
		}
	}
	int flag = _ALG_STITCH_PostImageFinish(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PostImageFinish error!" << endl;
	}

	flag = _ALG_STITCH_RefineMatch(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_RefineMatch error!" << endl;
	}

	flag = _ALG_STITCH_PathPlanning(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PathPlanning error!" << endl;
	}


	int resWidth, resHeight;
	_ALG_STITCH_GetWSISize(stitch_handle, resWidth, resHeight);

	Mat res(resHeight, resWidth, sourceType, Scalar::all(0));
	SyImage resImage;
	resImage.data = res.data;
	resImage.width = res.cols;
	resImage.height = res.rows;
	resImage.type = res.type();
	_ALG_STITCH_WSIBlender(stitch_handle, resImage);

	_ALG_STITCH_ClearStitchApp(stitch_handle);
	return 1;
}

int test_stitchLoadApp()
{
	_ALG_STITCH_Init();

	string cacheDir =  "./cache";

	STITCH_HANDLE  stitch_handle = _ALG_STITCH_LoadStitchApp(cacheDir, "pathPlanning");
	if (stitch_handle == nullptr)
	{
		cout << "create stitch app error!" << endl;
		return -1;
	}
	int flag;
	//int flag = _ALG_STITCH_PostImageFinish(stitch_handle);
	//if (flag != 1)
	//{
	//	cout << "_ALG_STITCH_PostImageFinish error!" << endl;
	//}

	//flag = _ALG_STITCH_RefineMatch(stitch_handle);
	//if (flag != 1)
	//{
	//	cout << "_ALG_STITCH_RefineMatch error!" << endl;
	//}

	flag = _ALG_STITCH_PathPlanning(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PathPlanning error!" << endl;
	}


	int resWidth, resHeight;
	_ALG_STITCH_GetWSISize(stitch_handle, resWidth, resHeight);

	Mat res(resHeight, resWidth, CV_8UC3, Scalar::all(0));
	SyImage resImage;
	resImage.data = res.data;
	resImage.width = res.cols;
	resImage.height = res.rows;
	resImage.type = res.type();
	_ALG_STITCH_WSIBlender(stitch_handle, resImage);

	_ALG_STITCH_ClearStitchApp(stitch_handle);
	return 1;
}

int test_stitch_self()
{
	_ALG_STITCH_Init();

	string imageDir = PathUtils::getParentDirectory(__FILE__) + "/data/exp5";
	int row_num = 4;
	int col_num = 4;

	StitchConfig stitchParams;
	stitchParams.matchTaskConsumerNum = 4;
	stitchParams.refineTaskConsumerNum = 4;
	stitchParams.imageHeight = 1536;
	stitchParams.imageWidth = 2048;
	stitchParams.imageChannels = 3;
	stitchParams.horizontalOverlap = 0.3;
	stitchParams.verticalOverlap = 0.3;
	stitchParams.cacheDir = "./cache";

	stitchParams.storeInMemory = true;
	stitchParams.copyImage = true;
	stitchParams.stitchBlenderType = eStitchBlenderBoardWeight;


	STITCH_HANDLE  stitch_handle = _ALG_STITCH_CreateStitchApp(stitchParams);
	if (stitch_handle == nullptr)
	{
		cout << "create stitch app error!" << endl;
		return -1;
	}
	int sourceType = -1;
	std::vector<cv::Mat> srcImgVec(row_num * col_num);
	for (size_t i = 0; i < row_num; i++)
	{
		for (size_t j = 0; j < col_num; j++)
		{
			//string imagepath = imageDir + "/scanImage_0__" + to_string(i) + "_" + to_string(j) + ".bmp";
			string imagepath = imageDir + "/" + to_string(i) + "_" + to_string(j) + ".bmp";
			Mat input = cv::imread(imagepath, -1);

			SyImage image;
			image.data = input.data;
			image.height = input.rows;
			image.width = input.cols;
			image.type = input.type();
			sourceType = input.type();
			int flag = _ALG_STITCH_PostImageOnce(stitch_handle, image, i, j);
			if (flag != 1)
			{
				cout << imagepath << endl;
			}
		}
	}
	int flag = _ALG_STITCH_PostImageFinish(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PostImageFinish error!" << endl;
	}
	flag = _ALG_STITCH_PlatformModel(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PlatformModel error!" << endl;
	}
	flag = _ALG_STITCH_RefineMatch(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_RefineMatch error!" << endl;
	}

	flag = _ALG_STITCH_PathPlanning(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PathPlanning error!" << endl;
	}


	int resWidth, resHeight;
	_ALG_STITCH_GetWSISize(stitch_handle, resWidth, resHeight);
	//
	Mat res(resHeight, resWidth, sourceType, Scalar::all(0));
	SyImage resImage;
	resImage.data = res.data;
	resImage.width = res.cols;
	resImage.height = res.rows;
	resImage.type = res.type();
	_ALG_STITCH_WSIBlender(stitch_handle, resImage);
	//ͼ�����ۺ���
	float fScores;
	_ALG_STITCH_Evaluate(stitch_handle, fScores);
	return 1;
}

int test_stitch_mmap()
{
	_ALG_STITCH_Init();

	string imageDir = PathUtils::getParentDirectory(__FILE__) + "/data/exp5";
	int row_num = 4;
	int col_num = 4;

	StitchConfig stitchParams;
	stitchParams.matchTaskConsumerNum = 4;
	stitchParams.refineTaskConsumerNum = 4;
	stitchParams.imageHeight = 1536;
	stitchParams.imageWidth = 2048;
	stitchParams.imageChannels = 3;
	stitchParams.horizontalOverlap = 0.3;
	stitchParams.verticalOverlap = 0.3;
	stitchParams.cacheDir = "./cache";

	stitchParams.storeInMemory = true;
	stitchParams.copyImage = true;
	stitchParams.stitchBlenderType = eStitchBlenderBoardWeight;


	STITCH_HANDLE  stitch_handle = _ALG_STITCH_CreateStitchApp(stitchParams);
	if (stitch_handle == nullptr)
	{
		cout << "create stitch app error!" << endl;
		return -1;
	}
	int sourceType = -1;
	std::vector<cv::Mat> srcImgVec(row_num * col_num);
	for (size_t i = 0; i < row_num; i++)
	{
		for (size_t j = 0; j < col_num; j++)
		{
			//string imagepath = imageDir + "/scanImage_0__" + to_string(i) + "_" + to_string(j) + ".bmp";
			string imagepath = imageDir + "/" + to_string(i) + "_" + to_string(j) + ".bmp";
			Mat input = cv::imread(imagepath, -1);

			SyImage image;
			image.data = input.data;
			image.height = input.rows;
			image.width = input.cols;
			image.type = input.type();
			sourceType = input.type();
			int flag = _ALG_STITCH_PostImageOnce(stitch_handle, image, i, j);
			if (flag != 1)
			{
				cout << imagepath << endl;
			}
		}
	}
	int flag = _ALG_STITCH_PostImageFinish(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PostImageFinish error!" << endl;
	}
	flag = _ALG_STITCH_PlatformModel(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PlatformModel error!" << endl;
	}
	flag = _ALG_STITCH_RefineMatch(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_RefineMatch error!" << endl;
	}

	flag = _ALG_STITCH_PathPlanning(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PathPlanning error!" << endl;
	}


	int resWidth, resHeight;
	_ALG_STITCH_GetWSISize(stitch_handle, resWidth, resHeight);
	//
	Mat res(resHeight, resWidth, sourceType, Scalar::all(0));
	SyImage resImage;
	resImage.data = res.data;
	resImage.width = res.cols;
	resImage.height = res.rows;
	resImage.type = res.type();
	_ALG_STITCH_WSIBlender(stitch_handle, resImage);
	//ͼ�����ۺ���
	float fScores;
	_ALG_STITCH_Evaluate(stitch_handle, fScores);
	return 1;
}

int test_stitch_selfDebug()
{
	_ALG_STITCH_Init();

	string cacheDir = "./cache";

	STITCH_HANDLE  stitch_handle = _ALG_STITCH_LoadStitchApp(cacheDir, "pathPlanning");
	if (stitch_handle == nullptr)
	{
		cout << "create stitch app error!" << endl;
		return -1;
	}
	int flag;
	//flag = _ALG_STITCH_PlatformModel(stitch_handle);
	//if (flag != 1)
	//{
	//	cout << "_ALG_STITCH_PlatformModel error!" << endl;
	//}
	//flag = _ALG_STITCH_RefineMatch(stitch_handle);
	//if (flag != 1)
	//{
	//	cout << "_ALG_STITCH_RefineMatch error!" << endl;
	//}
	auto start = std::chrono::high_resolution_clock::now();

	flag = _ALG_STITCH_PathPlanning(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PathPlanning error!" << endl;
	}
	auto end = std::chrono::high_resolution_clock::now();
	std::chrono::duration<double> duration = end - start;
	std::cout << "_ALG_STITCH_PathPlanning ����ִ��ʱ��: " << duration.count() << " ��" << std::endl;


	int resWidth, resHeight;
	_ALG_STITCH_GetWSISize(stitch_handle, resWidth, resHeight);

	Mat res(resHeight, resWidth, CV_8UC3, Scalar::all(0));
	SyImage resImage;
	resImage.data = res.data;
	resImage.width = res.cols;
	resImage.height = res.rows;
	resImage.type = res.type();
	_ALG_STITCH_WSIBlender(stitch_handle, resImage);
}

int test_stitch_finish()
{
	_ALG_STITCH_Init();

	string imageDir = PathUtils::getParentDirectory(__FILE__) + "/data/exp5";
	int row_num = 4;
	int col_num = 4;

	StitchConfig stitchParams;
	stitchParams.matchTaskConsumerNum = 4;
	stitchParams.refineTaskConsumerNum = 4;
	stitchParams.imageHeight = 1536;
	stitchParams.imageWidth = 2048;
	stitchParams.imageChannels = 3;
	stitchParams.horizontalOverlap = 0.3;
	stitchParams.verticalOverlap = 0.3;
	stitchParams.cacheDir = "";

	stitchParams.storeInMemory = true;
	stitchParams.copyImage = true;
	//stitchParams.pathPlanningType = ePathPlanningKruskal;
	stitchParams.stitchBlenderType = eStitchBlenderBoardWeight;

	int flag = 0;
	STITCH_HANDLE  stitch_handle = _ALG_STITCH_CreateStitchApp(stitchParams);
	if (stitch_handle == nullptr)
	{
		cout << "create stitch app error!" << endl;
		return -1;
	}
	int sourceType = -1;
	std::vector<cv::Mat> srcImgVec(row_num * col_num);
	for (size_t i = 0; i < row_num; i++)
	{
		for (size_t j = 0; j < col_num; j++)
		{
			//string imagepath = imageDir + "/scanImage_0__" + to_string(i) + "_" + to_string(j) + ".bmp";
			string imagepath = imageDir + "/" + to_string(i) + "_" + to_string(j) + ".bmp";
			Mat input = cv::imread(imagepath, -1);

			SyImage image;
			image.data = input.data;
			image.height = input.rows;
			image.width = input.cols;
			image.type = input.type();
			sourceType = input.type();
			flag = _ALG_STITCH_PostImageOnce(stitch_handle, image, i, j);
			if (flag != 1)
			{
				cout << imagepath << endl;
			}
			if (i == 2 && j == 2)
			{
				int flag = _ALG_STITCH_PostImageFinish(stitch_handle);
				if (flag != 1)
				{
					cout << "_ALG_STITCH_PostImageFinish error!" << endl;
				}
				goto finish;
			}
		}
	}
	finish:

	flag = _ALG_STITCH_PlatformModel(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PlatformModel error!" << endl;
	}
	flag = _ALG_STITCH_RefineMatch(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_RefineMatch error!" << endl;
	}

	flag = _ALG_STITCH_PathPlanning(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PathPlanning error!" << endl;
	}


	int resWidth, resHeight;
	_ALG_STITCH_GetWSISize(stitch_handle, resWidth, resHeight);
	//
	Mat res(resHeight, resWidth, sourceType, Scalar::all(0));
	SyImage resImage;
	resImage.data = res.data;
	resImage.width = res.cols;
	resImage.height = res.rows;
	resImage.type = res.type();
	_ALG_STITCH_WSIBlender(stitch_handle, resImage);
	//ͼ�����ۺ���
	float fScores;
	_ALG_STITCH_Evaluate(stitch_handle, fScores);
	return 1;
}

int test_stitch_time()
{
	_ALG_STITCH_Init();

	string imageDir = "D:/DMSimg/";
	//int row_num = 31;
	//int col_num = 23;
	int row_num = 20;
	int col_num = 20;
	StitchConfig stitchParams;
	stitchParams.matchTaskConsumerNum = 8;
	stitchParams.refineTaskConsumerNum = 8;
	stitchParams.imageHeight = 2100;
	stitchParams.imageWidth = 2800;
	stitchParams.imageChannels = 3;
	stitchParams.horizontalOverlap = 0.27;
	stitchParams.verticalOverlap = 0.27;
	stitchParams.cacheDir = "";
	stitchParams.stitchBlenderType = eStitchBlenderBoardWeight;

	stitchParams.storeInMemory = true;
	stitchParams.copyImage = false;

	CpuTimer timer;
	timer.StartTime();
	int sourceType = -1;
	vector <vector<Mat>> ins;
	ins.resize(row_num);

	for (size_t i = 0; i < row_num; i++)
	{
		ins[i].resize(col_num);
		for (size_t j = 0; j < col_num; j++)
		{
			cout << i << "__" << j << endl;
			//string imagepath = imageDir + "/scanImage_0__" + to_string(i) + "_" + to_string(j) + ".bmp";
			string imagepath = imageDir + "/" + to_string(i) + "-" + to_string(j) + ".bmp";
			ins[i][j] = cv::imread(imagepath, -1);
		}
	}
	float t0 = timer.StopTime("load image");
	STITCH_HANDLE  stitch_handle = _ALG_STITCH_CreateStitchApp(stitchParams);
	if (stitch_handle == nullptr)
	{
		cout << "create stitch app error!" << endl;
		return -1;
	}

	for (size_t i = 0; i < row_num; i++)
	{
		for (size_t j = 0; j < col_num; j++)
		{
			Mat input = ins[i][j];
			SyImage image;
			image.data = input.data;
			image.height = input.rows;
			image.width = input.cols;
			image.type = input.type();
			sourceType = input.type();
			int flag = _ALG_STITCH_PostImageOnce(stitch_handle, image, i, j);
			if (flag != 1)
			{
				cout << i << "__"<< j << endl;
			}
		}
	}
	int flag = _ALG_STITCH_PostImageFinish(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PostImageFinish error!" << endl;
	}
	float t1 = timer.StopTime("_ALG_STITCH_PostImageFinish", true);


	flag = _ALG_STITCH_PlatformModel(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PlatformModel error!" << endl;
	}
	float t2 = timer.StopTime("_ALG_STITCH_PlatformModel", true);


	flag = _ALG_STITCH_RefineMatch(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_RefineMatch error!" << endl;
	}
	float t3 = timer.StopTime("_ALG_STITCH_RefineMatch", true);

	flag = _ALG_STITCH_PathPlanning(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PathPlanning error!" << endl;
	}
	float t4 = timer.StopTime("_ALG_STITCH_PathPlanning", true);


	int resWidth, resHeight;
	_ALG_STITCH_GetWSISize(stitch_handle, resWidth, resHeight);
	float t5 = timer.StopTime("_ALG_STITCH_GetWSISize", true);

	Mat res(resHeight, resWidth, sourceType, Scalar::all(0));
	SyImage resImage;
	resImage.data = res.data;
	resImage.width = res.cols;
	resImage.height = res.rows;
	resImage.type = res.type();
	_ALG_STITCH_WSIBlender(stitch_handle, resImage);
	float t6 = timer.StopTime("_ALG_STITCH_WSIBlender", true);

	cout << "_ALG_STITCH_LoadImage: " << t0 << endl;
	cout << "_ALG_STITCH_PostImageFinish: " << t1 << endl;
	cout << "_ALG_STITCH_PlatformModel: " << t2 << endl;
	cout << "_ALG_STITCH_RefineMatch: " << t3 << endl;
	cout << "_ALG_STITCH_PathPlanning: " << t4 << endl;
	cout << "_ALG_STITCH_GetWSISize: " << t5 << endl;
	cout << "_ALG_STITCH_WSIBlender: " << t6 << endl;
	cout << "_ALG_STITCH_all_time: " << max(t0, t1) + t3 + t4 + t5 + t6 << endl;
	cv::imwrite("./res.jpg", res);
	return 1;
}

int test_stitch_exp6()
{
	_ALG_STITCH_Init();

	string imageDir = PathUtils::getParentDirectory(__FILE__) + "/data/exp6";
	int row_num = 7;
	int col_num = 7;
	StitchConfig stitchParams;
	stitchParams.matchTaskConsumerNum = 1;
	stitchParams.refineTaskConsumerNum = 8;
	stitchParams.imageHeight = 2000;
	stitchParams.imageWidth = 2000;
	stitchParams.imageChannels = 3;
	stitchParams.horizontalOverlap = 0.05;
	stitchParams.verticalOverlap = 0.05;
	stitchParams.cacheDir = "./cache";
	stitchParams.stitchBlenderType = eStitchBlenderBoardWeight;
	stitchParams.taskConsumerType = eTaskConsumerCUDANCC;
	stitchParams.storeInMemory = true;
	stitchParams.copyImage = false;

	CpuTimer timer;
	timer.StartTime();
	int sourceType = -1;
	vector <vector<Mat>> ins;
	ins.resize(row_num);

	for (size_t i = 0; i < row_num; i++)
	{
		ins[i].resize(col_num);
		for (size_t j = 0; j < col_num; j++)
		{
			cout << i << "__" << j << endl;
			//string imagepath = imageDir + "/scanImage_0__" + to_string(i) + "_" + to_string(j) + ".bmp";
			string imagepath = imageDir + "/" + to_string(i) + "_" + to_string(j) + ".bmp";
			ins[i][j] = cv::imread(imagepath, -1);
		}
	}
	float t0 = timer.StopTime("load image");
	STITCH_HANDLE  stitch_handle = _ALG_STITCH_CreateStitchApp(stitchParams);
	if (stitch_handle == nullptr)
	{
		cout << "create stitch app error!" << endl;
		return -1;
	}

	for (size_t i = 0; i < row_num; i++)
	{
		for (size_t j = 0; j < col_num; j++)
		{
			Mat input = ins[i][j];
			SyImage image;
			image.data = input.data;
			image.height = input.rows;
			image.width = input.cols;
			image.type = input.type();
			sourceType = input.type();
			int flag = _ALG_STITCH_PostImageOnce(stitch_handle, image, i, j);
			if (flag != 1)
			{
				cout << i << "__" << j << endl;
			}
		}
	}
	int flag = _ALG_STITCH_PostImageFinish(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PostImageFinish error!" << endl;
	}
	float t1 = timer.StopTime("_ALG_STITCH_PostImageFinish", true);


	flag = _ALG_STITCH_PlatformModel(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PlatformModel error!" << endl;
	}
	float t2 = timer.StopTime("_ALG_STITCH_PlatformModel", true);


	flag = _ALG_STITCH_RefineMatch(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_RefineMatch error!" << endl;
	}
	float t3 = timer.StopTime("_ALG_STITCH_RefineMatch", true);

	flag = _ALG_STITCH_PathPlanning(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PathPlanning error!" << endl;
	}
	float t4 = timer.StopTime("_ALG_STITCH_PathPlanning", true);


	int resWidth, resHeight;
	_ALG_STITCH_GetWSISize(stitch_handle, resWidth, resHeight);
	float t5 = timer.StopTime("_ALG_STITCH_GetWSISize", true);

	Mat res(resHeight, resWidth, sourceType, Scalar::all(0));
	SyImage resImage;
	resImage.data = res.data;
	resImage.width = res.cols;
	resImage.height = res.rows;
	resImage.type = res.type();
	_ALG_STITCH_WSIBlender(stitch_handle, resImage);
	float t6 = timer.StopTime("_ALG_STITCH_WSIBlender", true);

	cout << "_ALG_STITCH_LoadImage: " << t0 << endl;
	cout << "_ALG_STITCH_PostImageFinish: " << t1 << endl;
	cout << "_ALG_STITCH_PlatformModel: " << t2 << endl;
	cout << "_ALG_STITCH_RefineMatch: " << t3 << endl;
	cout << "_ALG_STITCH_PathPlanning: " << t4 << endl;
	cout << "_ALG_STITCH_GetWSISize: " << t5 << endl;
	cout << "_ALG_STITCH_WSIBlender: " << t6 << endl;
	cout << "_ALG_STITCH_all_time: " << max(t0, t1) + t3 + t4 + t5 + t6 << endl;
	cv::imwrite("./res.jpg", res);
	return 1;
}

void computeCPS1(const cv::Mat& src1, const cv::Mat& src2, cv::Mat& res)
{
	if (res.empty() || src1.size() != res.size())
	{
		res = cv::Mat(src1.size(), src1.type(), cv::Scalar::all(0));
	}
	int rows = src1.rows;
	int cols = src1.cols;
	int blockSize = 2;
	for (int i = 0; i < rows; i++)
	{
		const float * src1LinePtr = (float*)src1.ptr<cv::Vec2f>(i);
		const float * src2LinePtr = (float*)src2.ptr<cv::Vec2f>(i);
		float * resLinePtr = (float*)res.ptr<cv::Vec2f>(i);
		int j = 0;
		for (; j < cols - blockSize + 1; j += blockSize)
		{
			__m128 val1 = _mm_loadu_ps(src1LinePtr + j * 2);
			__m128 val2 = _mm_loadu_ps(src2LinePtr + j * 2);

			__m128 val3 = _mm_mul_ps(_mm_shuffle_ps(val2, val2, _MM_SHUFFLE(2, 3, 0, 1)), _mm_setr_ps(-1, 1, -1, 1));
			__m128 mul1 = _mm_mul_ps(val1, val2);
			__m128 mul2 = _mm_mul_ps(val1, val3);

			__m128 hadd = _mm_hadd_ps(mul1, mul2);
			__m128 shufhadd = _mm_shuffle_ps(hadd, hadd, _MM_SHUFFLE(3, 1, 2, 0));
			shufhadd = _mm_add_ps(shufhadd, _mm_setr_ps(1e-10, 0, 1e-10, 0));
			__m128 powval = _mm_mul_ps(shufhadd, shufhadd);
			__m128 shufflePowVal = _mm_shuffle_ps(powval, powval, _MM_SHUFFLE(2, 3, 0, 1));
			__m128 addPow = _mm_add_ps(powval, shufflePowVal);
			__m128 sqrtAdd = _mm_sqrt_ps(addPow);
			__m128 res = _mm_div_ps(shufhadd, sqrtAdd);

			_mm_storeu_ps(resLinePtr + j * 2, res);

		}
		for (; j < cols; j++)
		{
			float a = src1LinePtr[j * 2 + 0];
			float b = src1LinePtr[j * 2 + 1];
			float c = src2LinePtr[j * 2 + 0];
			float d = src2LinePtr[j * 2 + 1];
			float v0 = a * c + b * d;
			float v1 = b * c - a * d;
			float vs = sqrt(v0*v0 + v1 * v1);
			resLinePtr[j * 2 + 0] = v0 / vs;
			resLinePtr[j * 2 + 1] = v1 / vs;
		}
	}
	return;
}


void test_xwxg() 
{
	cv::Mat I1(128, 128, CV_32FC1, Scalar::all(0));

	Rect r1(48, 48, 32, 32);
	I1(r1).setTo(Scalar::all(255));
	// ���������������
	std::random_device rd;                     // ��ȡ����豸
	std::mt19937 gen(rd());                    // ʹ�� Mersenne Twister �������������
	std::uniform_int_distribution<> dis(-48, 48); // ���������ֲ���ΧΪ -64 �� 64
	for (size_t i = 0; i < 1000; i++)
	{
		// ����һ���������
		int random_x_shift = dis(gen);
		int random_y_shift = dis(gen);

		Rect r2 = r1 + Point(random_x_shift, random_y_shift);


		cv::Mat I2(128, 128, CV_32FC1, Scalar::all(0));
		I2(r2).setTo(Scalar::all(255));

		cv::Mat Img1_DFT, Img2_DFT, CPS;
		dft(I1, Img1_DFT, cv::DFT_COMPLEX_OUTPUT);
		dft(I2, Img2_DFT, cv::DFT_COMPLEX_OUTPUT);
		computeCPS1(Img1_DFT, Img2_DFT, CPS);

		//	�渵��Ҷ�任
		Mat pcm;
		dft(CPS, pcm, cv::DFT_INVERSE | cv::DFT_REAL_OUTPUT | cv::DFT_SCALE);

		cv::Point shift;
		minMaxLoc(pcm, nullptr, nullptr, nullptr, &shift);
		
		cv::Vec2i vec = shift - Point(64, 64);
		cv::Vec2i die(vec[0] / abs(vec[0]), vec[1] / abs(vec[1]));

		Point res;
		res.x = (die[0] > 0 ? I1.cols - shift.x : shift.x) * die[0];
		res.y = (die[1] > 0 ? I1.rows - shift.y : shift.y) * die[1];

		cout << "random_x_shift: " << random_x_shift << " random_y_shift: " << random_y_shift << " res_shift_x: " << res.x << " res_shift_y: " << res.y << " diff:" << abs(res.x - random_x_shift) + abs(res.y - random_y_shift) << endl;;
	}
	return;
}

void test_image_xwxg() 
{
	string imageDir = PathUtils::getParentDirectory(__FILE__) + "/data/exp5";
	int row_num = 4;
	int col_num = 4;

	cv::Mat I1 = cv::imread(imageDir + "/0_1.bmp", IMREAD_GRAYSCALE);
	cv::Mat I2 = cv::imread(imageDir + "/0_2.bmp", IMREAD_GRAYSCALE);

	I1.convertTo(I1, CV_32F); 
	I2.convertTo(I2, CV_32F);

	Rect roi(0, 0, 614, 1536);
	I2 = I2(roi).clone();

	I1 = I1(roi + Point(1433, 0)).clone();

	cv::Mat Img1_DFT, Img2_DFT, CPS;
	dft(I1, Img1_DFT, cv::DFT_COMPLEX_OUTPUT);
	dft(I2, Img2_DFT, cv::DFT_COMPLEX_OUTPUT);
	computeCPS1(Img1_DFT, Img2_DFT, CPS);

	//	�渵��Ҷ�任
	Mat pcm;
	dft(CPS, pcm, cv::DFT_INVERSE | cv::DFT_REAL_OUTPUT | cv::DFT_SCALE);

	cv::Point shift;
	minMaxLoc(pcm, nullptr, nullptr, nullptr, &shift);

	cv::Vec2i vec = shift - Point(64, 64);
	cv::Vec2i die(vec[0] / abs(vec[0]), vec[1] / abs(vec[1]));

	Point res;
	res.x = (die[0] > 0 ? I1.cols - shift.x : shift.x) * die[0];
	res.y = (die[1] > 0 ? I1.rows - shift.y : shift.y) * die[1];




	return;
}

int main_self()
{
	//���Թ���debug����
	//test_stitchSaveApp();
	//test_stitchLoadApp();
	//test_stitch_finish();
	//test_stitch_selfDebug();
	//test_stitch_self();
	//test_image_xwxg();
	//test_xwxg();
	//test_stitch_self();
	//test_stitch_selfDebug();
	//test_stitch_DiffType();//��ͬɨ��ģʽ��ͼ��
	//test_NormalStitch();//ģ��ɰ�ƴ��ģʽ
	//test_NormalStitchLgc2();
	//test_NormalStitchLgc2();

	test_StitchNewSxd();

	return 1;
}
