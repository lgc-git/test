#include "example.h"
#include "alg_app_stitch.h"
#include "stitchConfig.h"
#include "alg_base_common.h"
#include <iostream>
#include "opencv2/opencv.hpp"
#include <windows.h>
#include<nlohmann/json.hpp>
#include<filesystem>
using namespace std;
using namespace cv;
using namespace stitchAlg;
namespace fs = std::filesystem;


// �����ƴ洢
void saveToBinary(const Mat& img, const string& filename) {
	ofstream outFile(filename, ios::binary);
	if (!outFile) {
		cerr << "�޷����ļ� " << filename << " ����д�룡" << endl;
		return;
	}

	int rows = img.rows, cols = img.cols, type = img.type();
	outFile.write((char*)&rows, sizeof(int));
	outFile.write((char*)&cols, sizeof(int));
	outFile.write((char*)&type, sizeof(int));
	outFile.write((char*)img.data, img.total() * img.elemSize());

	outFile.close();
}

// �����ƶ�ȡ
Mat loadFromBinary(const string& filename)
{
	ifstream inFile(filename, ios::binary);
	if (!inFile) {
		cerr << "�޷����ļ� " << filename << " ���ж�ȡ��" << endl;
		return Mat();
	}

	int rows, cols, type;
	inFile.read((char*)&rows, sizeof(int));
	inFile.read((char*)&cols, sizeof(int));
	inFile.read((char*)&type, sizeof(int));

	Mat img(rows, cols, type);
	inFile.read((char*)img.data, img.total() * img.elemSize());

	inFile.close();
	return img;
}





//ͨ�õ�ƴ������:��ʼ��-�ϴ�ͼ��-�ϴ�ͼ�����-ƴ�ӽ�����ȡƫ����-ȫ��ƫ����������ֵ,����ƴ�Ӻ�ͼ���ͼ
//-ͼ��ƴ�ӷ��ں�-��������
int test_NormalStitchLgc()
{
	_ALG_STITCH_Init();

	string cacheDir = "E:\\source\\DMS\\2DStitching\\exp\\badCase";
	string imageDir = cacheDir + "/data";
	int row_num = 4;
	int col_num = 2;
	STITCH_HANDLE  stitch_handle = _ALG_STITCH_LoadStitchApp(cacheDir, "platformModel");
	if (stitch_handle == nullptr)
	{
		cout << "create stitch app error!" << endl;
		return -1;
	}
	int flag;
	int sourceType = -1;
	//std::vector<cv::Mat> srcImgVec(row_num * col_num);
	//for (size_t i = 0; i < row_num; i++)
	//{
	//	for (size_t j = 0; j < col_num; j++)
	//	{
	//		//string imagepath = imageDir + "/scanImage_0__" + to_string(i) + "_" + to_string(j) + ".bmp";
	//		string imagepath = imageDir + "/" + to_string(i) + "_" + to_string(j) + ".bmp";
	//		Mat input = cv::imread(imagepath, -1);

	//		SyImage image;
	//		image.data = input.data;
	//		image.height = input.rows;
	//		image.width = input.cols;
	//		image.type = input.type();
	//		sourceType = input.type();
	//		int flag = _ALG_STITCH_PostImageOnce(stitch_handle, image, i, j);
	//		if (flag != 1)
	//		{
	//			cout << imagepath << endl;
	//		}
	//	}
	//}
	//int flag = _ALG_STITCH_PostImageFinish(stitch_handle);
	//if (flag != 1)
	//{
	//	cout << "_ALG_STITCH_PostImageFinish error!" << endl;
	//}
	flag = _ALG_STITCH_PlatformModel(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PlatformModel error!" << endl;
	}
	flag = _ALG_STITCH_RefineMatch(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_RefineMatch error!" << endl;
	}

	flag = _ALG_STITCH_PathPlanning(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PathPlanning error!" << endl;
	}


	int resWidth, resHeight;
	_ALG_STITCH_GetWSISize(stitch_handle, resWidth, resHeight);
	//
	Mat res(resHeight, resWidth, CV_8UC3, Scalar::all(0));
	SyImage resImage;
	resImage.data = res.data;
	resImage.width = res.cols;
	resImage.height = res.rows;
	resImage.type = res.type();
	_ALG_STITCH_WSIBlender(stitch_handle, resImage);
	return 1;
}


int test_NormalStitchLgc2()
{
	_ALG_STITCH_Init();
	CpuTimer ttr;
	ttr.StartTime();
	string cacheDir = "E:\\source\\DMS\\2DStitching\\exp\\21-09-20-36\\";
	string imageDir = cacheDir + "/data";
	int row_num = 6;
	int col_num = 6;
	StitchConfig param;
	param.horizontalOverlap = 0.358;
	param.verticalOverlap = 0.313;
	param.imageWidth = 2800;
	param.imageHeight = 2100;
	param.refineTaskConsumerNum = 1;
	//param.taskConsumerType = TaskConsumerType::eTaskConsumerCUDANCC;
	param.matchTaskConsumerNum = 1;
	param.cacheDir = "./data";
	STITCH_HANDLE  stitch_handle = _ALG_STITCH_CreateStitchApp(param);

	if (stitch_handle == nullptr)
	{
		cout << "create stitch app error!" << endl;
		return -1;
	}
	int flag;
	int sourceType = -1;
	std::vector<cv::Mat> srcImgVec(row_num * col_num);
	for (size_t i = 0; i < row_num; i++)
	{
		for (size_t j = 0; j < col_num; j++)
		{
			//string imagepath = imageDir + "/scanImage_0__" + to_string(i) + "_" + to_string(j) + ".bmp";
			string imagepath = imageDir + "/" + to_string(i) + "_" + to_string(j) + ".bmp";
			Mat input = cv::imread(imagepath, -1);
			//input = Mat(input.size(), input.type(), Scalar::all(0));
			SyImage image;
			image.data = input.data;
			image.height = input.rows;
			image.width = input.cols;
			image.type = input.type();
			sourceType = input.type();
			int flag = _ALG_STITCH_PostImageOnce(stitch_handle, image, i, j);
			if (flag != 1)
			{
				cout << imagepath << endl;
			}
		}
	}
	flag = _ALG_STITCH_PostImageFinish(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PostImageFinish error!" << endl;
	}
	flag = _ALG_STITCH_PlatformModel(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PlatformModel error!" << endl;
	}
	flag = _ALG_STITCH_RefineMatch(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_RefineMatch error!" << endl;
	}

	flag = _ALG_STITCH_PathPlanning(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PathPlanning error!" << endl;
	}


	int resWidth, resHeight;
	_ALG_STITCH_GetWSISize(stitch_handle, resWidth, resHeight);
	//
	Mat res(resHeight, resWidth, CV_8UC3, Scalar::all(0));
	SyImage resImage;
	resImage.data = res.data;
	resImage.width = res.cols;
	resImage.height = res.rows;
	resImage.type = res.type();
	_ALG_STITCH_WSIBlender(stitch_handle, resImage);

	_ALG_STITCH_ClearStitchApp(stitch_handle);
	ttr.StopTime("e", true);
	return 1;
}

int test_NormalStitchLgc3()
{
	_ALG_STITCH_Init();

	string cacheDir = "E:\\source\\DMS\\2DStitching\\exp\\19-15-19-30\\";
	string imageDir = cacheDir + "/data";
	int row_num = 5;
	int col_num = 5;
	STITCH_HANDLE  stitch_handle = _ALG_STITCH_LoadStitchApp(cacheDir, "pathPlanning");
	if (stitch_handle == nullptr)
	{
		cout << "create stitch app error!" << endl;
		return -1;
	}
	int flag;
	//int sourceType = -1;
	//std::vector<cv::Mat> srcImgVec(row_num * col_num);
	//for (size_t i = 0; i < row_num; i++)
	//{
	//	for (size_t j = 0; j < col_num; j++)
	//	{
	//		//string imagepath = imageDir + "/scanImage_0__" + to_string(i) + "_" + to_string(j) + ".bmp";
	//		string imagepath = imageDir + "/" + to_string(i) + "_" + to_string(j) + ".bmp";
	//		Mat input = cv::imread(imagepath, -1);

	//		SyImage image;
	//		image.data = input.data;
	//		image.height = input.rows;
	//		image.width = input.cols;
	//		image.type = input.type();
	//		sourceType = input.type();
	//		int flag = _ALG_STITCH_PostImageOnce(stitch_handle, image, i, j);
	//		if (flag != 1)
	//		{
	//			cout << imagepath << endl;
	//		}
	//	}
	//}
	//flag = _ALG_STITCH_PostImageFinish(stitch_handle);
	//if (flag != 1)
	//{
	//	cout << "_ALG_STITCH_PostImageFinish error!" << endl;
	//}
	//flag = _ALG_STITCH_PlatformModel(stitch_handle);
	//if (flag != 1)
	//{
	//	cout << "_ALG_STITCH_PlatformModel error!" << endl;
	//}
	//flag = _ALG_STITCH_RefineMatch(stitch_handle);
	//if (flag != 1)
	//{
	//	cout << "_ALG_STITCH_RefineMatch error!" << endl;
	//}

	flag = _ALG_STITCH_PathPlanning(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PathPlanning error!" << endl;
	}


	int resWidth, resHeight;
	_ALG_STITCH_GetWSISize(stitch_handle, resWidth, resHeight);
	//
	Mat res(resHeight, resWidth, CV_8UC3, Scalar::all(0));
	SyImage resImage;
	resImage.data = res.data;
	resImage.width = res.cols;
	resImage.height = res.rows;
	resImage.type = res.type();

	_ALG_STITCH_WSIBlender(stitch_handle, resImage);
	return 1;
}

int test_NormalUseDataStitch()
{
	_ALG_STITCH_Init();

	string cacheDir = "G:\\0314StitchAbnormalAnalysis\\ImageSave\\ChessBoard\\afterRemoveLens\\withFilter\\100XUndistort\\";
	string imageDir = cacheDir + "/data";
	int row_num = 8;
	int col_num = 11;
	std::string blenderPath = cacheDir + "/" + "blender.json";
	std::ifstream blenderFile(blenderPath);
	if (blenderFile.is_open())
	{
		nlohmann::json jsonObj;
		blenderFile >> jsonObj;
		row_num = jsonObj["GridInfo"]["height"];
		col_num = jsonObj["GridInfo"]["width"];
	}
	STITCH_HANDLE  stitch_handle = _ALG_STITCH_LoadStitchApp(cacheDir, "blender");
	if (stitch_handle == nullptr)
	{
		cout << "create stitch app error!" << endl;
		return -1;
	}
	int flag;
	int sourceType = -1;
	std::vector<cv::Mat> srcImgVec(row_num * col_num);
	for (size_t i = 0; i < row_num; i++)
	{
		for (size_t j = 0; j < col_num; j++)
		{
			//string imagepath = imageDir + "/scanImage_0__" + to_string(i) + "_" + to_string(j) + ".bmp";
			string imagepath = imageDir + "/" + to_string(i) + "_" + to_string(j) + ".bmp";
			Mat input = cv::imread(imagepath, -1);

			SyImage image;
			image.data = input.data;
			image.height = input.rows;
			image.width = input.cols;
			image.type = input.type();
			sourceType = input.type();
			int flag = _ALG_STITCH_PostImageOnce(stitch_handle, image, i, j);
			if (flag != 1)
			{
				cout << imagepath << endl;
			}
		}
	}
	flag = _ALG_STITCH_PostImageFinish(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PostImageFinish error!" << endl;
	}
	flag = _ALG_STITCH_PlatformModel(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PlatformModel error!" << endl;
	}
	flag = _ALG_STITCH_RefineMatch(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_RefineMatch error!" << endl;
	}

	flag = _ALG_STITCH_PathPlanning(stitch_handle);
	if (flag != 1)
	{
		cout << "_ALG_STITCH_PathPlanning error!" << endl;
	}


	int resWidth, resHeight;
	_ALG_STITCH_GetWSISize(stitch_handle, resWidth, resHeight);
	//
	Mat res(resHeight, resWidth, CV_8UC3, Scalar::all(0));
	SyImage resImage;
	resImage.data = res.data;
	resImage.width = res.cols;
	resImage.height = res.rows;
	resImage.type = res.type();
	
	_ALG_STITCH_WSIBlender(stitch_handle, resImage);
	return 1;
}

int test_readbinary() 
{
	string cacheDir = "E:\\source\\DMS\\2DStitching\\exp\\12-34-57-944";
	string imageDir = cacheDir + "/data";
	string imagepath = imageDir + "/" + to_string(0) + "_" + to_string(0) + ".bmp";
	Mat img = cv::imread(imagepath, -1);
	saveToBinary(img, "./1.data");

	CpuTimer ttr;
	ttr.StartTime();
	for (size_t i = 0; i < 1000; i++)
	{
		Mat t = imread(imagepath);
	}
	ttr.StopTime("imread time:", true);
	ttr.StartTime();
	for (size_t i = 0; i < 1000; i++)
	{
		Mat t = loadFromBinary("./1.data");
		continue;
	}
	ttr.StopTime("loadFromBinary time:", true);
	return 1;
}
