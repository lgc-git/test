//#include "example.h"
//#include <unordered_map>
//#include "opencv2/opencv.hpp"
//#include "stitchDataStruct.h"
//#include "modeling.h"
//
//int test_modeling()
//{
//	// ����
//	// ��ʼ������
//	std::unordered_map<cv::Point, std::shared_ptr<Tile>, cvPointHash> tileMap;
//	// ��һ��ֵ00
//	cv::Point p00;
//	p00.x = 0;
//	p00.y = 0;
//	cv::Mat input(1, 1, CV_8UC3, cv::Scalar(0, 0, 0));
//	cv::Point world_coor(0, 0);
//	bool store_in_memory = false;
//	bool clone = false;
//	std::shared_ptr<Tile> t00 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t00->matchFlags[0] = 0;
//	t00->matchInfos[0].offset.x = 0;
//	t00->matchInfos[0].offset.y = 0;
//	t00->matchInfos[0].precison = 0;
//	// 00��
//	t00->matchFlags[1] = 0;
//	t00->matchInfos[1].offset.x = 0;
//	t00->matchInfos[1].offset.y = 0;
//	t00->matchInfos[1].precison = 0;
//	tileMap.emplace(p00, t00);
//
//
//	// ��01
//	cv::Point p01;
//	p01.x = 1;
//	p01.y = 0;
//	std::shared_ptr<Tile> t01 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 01��
//	t01->matchFlags[0] = 0;
//	t01->matchInfos[0].offset.x = 0;
//	t01->matchInfos[0].offset.y = 0;
//	t01->matchInfos[0].precison = 0;
//	// 01��
//	t01->matchFlags[1] = 1;
//	t01->matchInfos[1].offset.x = 1438;
//	t01->matchInfos[1].offset.y = 0;
//	t01->matchInfos[1].precison = 0.6001634001731873;
//	tileMap.emplace(p01, t01);
//
//
//	// ��02
//	cv::Point p02;
//	p02.x = 2;
//	p02.y = 0;
//	std::shared_ptr<Tile> t02 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 01��
//	t02->matchFlags[0] = 0;
//	t02->matchInfos[0].offset.x = 0;
//	t02->matchInfos[0].offset.y = 0;
//	t02->matchInfos[0].precison = 0;
//	// 01��
//	t02->matchFlags[1] = 1;
//	t02->matchInfos[1].offset.x = 1425;
//	t02->matchInfos[1].offset.y = -3;
//	t02->matchInfos[1].precison = 0.797805905342102;
//	tileMap.emplace(p02, t02);
//
//	// ��03
//	cv::Point p03;
//	p03.x = 3;
//	p03.y = 0;
//	std::shared_ptr<Tile> t03 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 01��
//	t03->matchFlags[0] = 0;
//	t03->matchInfos[0].offset.x = 0;
//	t03->matchInfos[0].offset.y = 0;
//	t03->matchInfos[0].precison = 0;
//	// 01��
//	t03->matchFlags[1] = 1;
//	t03->matchInfos[1].offset.x = 0;
//	t03->matchInfos[1].offset.y = 4;
//	t03->matchInfos[1].precison = 0.6550357937812805;
//	tileMap.emplace(p03, t03);
//
//	// ��04
//	cv::Point p04;
//	p04.x = 4;
//	p04.y = 0;
//	std::shared_ptr<Tile> t04 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 01��
//	t04->matchFlags[0] = 0;
//	t04->matchInfos[0].offset.x = 0;
//	t04->matchInfos[0].offset.y = 0;
//	t04->matchInfos[0].precison = 0;
//	// 01��
//	t04->matchFlags[1] = 1;
//	t04->matchInfos[1].offset.x = 0;
//	t04->matchInfos[1].offset.y = -1;
//	t04->matchInfos[1].precison = 0.34021908044815063;
//	tileMap.emplace(p04, t04);
//
//	// ��05
//	cv::Point p05;
//	p05.x = 5;
//	p05.y = 0;
//	std::shared_ptr<Tile> t05 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 01��
//	t05->matchFlags[0] = 0;
//	t05->matchInfos[0].offset.x = 0;
//	t05->matchInfos[0].offset.y = 0;
//	t05->matchInfos[0].precison = 0;
//	// 01��
//	t05->matchFlags[1] = 1;
//	t05->matchInfos[1].offset.x = 0;
//	t05->matchInfos[1].offset.y = 1;
//	t05->matchInfos[1].precison = 0.4375365078449249;
//	tileMap.emplace(p05, t05);
//
//
//	// ��10
//	cv::Point p10;
//	p10.x = 0;
//	p10.y = 1;
//	std::shared_ptr<Tile> t10 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t10->matchFlags[0] = 1;
//	t10->matchInfos[0].offset.x = 2;
//	t10->matchInfos[0].offset.y = 1075;
//	t10->matchInfos[0].precison = 0.9518185257911682;
//	// 00��
//	t10->matchFlags[1] = 0;
//	t10->matchInfos[1].offset.x = 0;
//	t10->matchInfos[1].offset.y = 0;
//	t10->matchInfos[1].precison = 0;
//	tileMap.emplace(p10, t10);
//
//	// ��11
//	cv::Point p11;
//	p11.x = 1;
//	p11.y = 1;
//	std::shared_ptr<Tile> t11 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t11->matchFlags[0] = 1;
//	t11->matchInfos[0].offset.x = 0;
//	t11->matchInfos[0].offset.y = 1073;
//	t11->matchInfos[0].precison = 0.7877086400985718;
//	// 00��
//	t11->matchFlags[1] = 1;
//	t11->matchInfos[1].offset.x = 1437;
//	t11->matchInfos[1].offset.y = 0;
//	t11->matchInfos[1].precison = 0.6458391547203064;
//	tileMap.emplace(p11, t11);
//
//	// ��12
//	cv::Point p12;
//	p12.x = 2;
//	p12.y = 1;
//	std::shared_ptr<Tile> t12 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t12->matchFlags[0] = 1;
//	t12->matchInfos[0].offset.x = 2;
//	t12->matchInfos[0].offset.y = 1074;
//	t12->matchInfos[0].precison = 0.7455317378044128;
//	// 00��
//	t12->matchFlags[1] = 1;
//	t12->matchInfos[1].offset.x = 1426;
//	t12->matchInfos[1].offset.y = -3;
//	t12->matchInfos[1].precison = 0.8607562780380249;
//	tileMap.emplace(p12, t12);
//
//	// ��13
//	cv::Point p13;
//	p13.x = 3;
//	p13.y = 1;
//	std::shared_ptr<Tile> t13 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t13->matchFlags[0] = 1;
//	t13->matchInfos[0].offset.x = 0;
//	t13->matchInfos[0].offset.y = 0;
//	t13->matchInfos[0].precison = 0.5247988104820251;
//	// 00��
//	t13->matchFlags[1] = 1;
//	t13->matchInfos[1].offset.x = 0;
//	t13->matchInfos[1].offset.y = -1535;
//	t13->matchInfos[1].precison = 0.4437277615070343;
//	tileMap.emplace(p13, t13);
//
//	// ��14
//	cv::Point p14;
//	p14.x = 4;
//	p14.y = 1;
//	std::shared_ptr<Tile> t14 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t14->matchFlags[0] = 1;
//	t14->matchInfos[0].offset.x = 0;
//	t14->matchInfos[0].offset.y = 1535;
//	t14->matchInfos[0].precison = 0.6101338267326355;
//	// 00��
//	t14->matchFlags[1] = 1;
//	t14->matchInfos[1].offset.x = 0;
//	t14->matchInfos[1].offset.y = 1535;
//	t14->matchInfos[1].precison = 0.5385474562644958;
//	tileMap.emplace(p14, t14);
//
//	// ��15
//	cv::Point p15;
//	p15.x = 5;
//	p15.y = 1;
//	std::shared_ptr<Tile> t15 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t15->matchFlags[0] = 1;
//	t15->matchInfos[0].offset.x = 0;
//	t15->matchInfos[0].offset.y = 1535;
//	t15->matchInfos[0].precison = 0.6475358605384827;
//	// 00��
//	t15->matchFlags[1] = 1;
//	t15->matchInfos[1].offset.x = 0;
//	t15->matchInfos[1].offset.y = -1;
//	t15->matchInfos[1].precison = 0.19148215651512146;
//	tileMap.emplace(p15, t15);
//
//	// ��20
//	cv::Point p20;
//	p20.x = 0;
//	p20.y = 2;
//	std::shared_ptr<Tile> t20 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t20->matchFlags[0] = 1;
//	t20->matchInfos[0].offset.x = 2;
//	t20->matchInfos[0].offset.y = 1081;
//	t20->matchInfos[0].precison = 0.9815559387207031;
//	// 00��
//	t20->matchFlags[1] = 0;
//	t20->matchInfos[1].offset.x = 0;
//	t20->matchInfos[1].offset.y = 0;
//	t20->matchInfos[1].precison = 0;
//	tileMap.emplace(p20, t20);
//
//	// ��21
//	cv::Point p21;
//	p21.x = 1;
//	p21.y = 2;
//	std::shared_ptr<Tile> t21 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t21->matchFlags[0] = 1;
//	t21->matchInfos[0].offset.x = -4;
//	t21->matchInfos[0].offset.y = 0;
//	t21->matchInfos[0].precison = 0.4515910744667053;
//	// 00��
//	t21->matchFlags[1] = 1;
//	t21->matchInfos[1].offset.x = 1436;
//	t21->matchInfos[1].offset.y = 0;
//	t21->matchInfos[1].precison = 0.6647970080375671;
//	tileMap.emplace(p21, t21);
//
//	// ��22
//	cv::Point p22;
//	p22.x = 2;
//	p22.y = 2;
//	std::shared_ptr<Tile> t22 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t22->matchFlags[0] = 1;
//	t22->matchInfos[0].offset.x = 2;
//	t22->matchInfos[0].offset.y = 1082;
//	t22->matchInfos[0].precison = 0.6387355327606201;
//	// 00��
//	t22->matchFlags[1] = 1;
//	t22->matchInfos[1].offset.x = 1425;
//	t22->matchInfos[1].offset.y = -3;
//	t22->matchInfos[1].precison = 0.78263920545578;
//	tileMap.emplace(p22, t22);
//
//	// ��23
//	cv::Point p23;
//	p23.x = 3;
//	p23.y = 2;
//	std::shared_ptr<Tile> t23 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t23->matchFlags[0] = 1;
//	t23->matchInfos[0].offset.x = 0;
//	t23->matchInfos[0].offset.y = 1084;
//	t23->matchInfos[0].precison = 0.7567530274391174;
//	// 00��
//	t23->matchFlags[1] = 1;
//	t23->matchInfos[1].offset.x = 0;
//	t23->matchInfos[1].offset.y = -1535;
//	t23->matchInfos[1].precison = 0.29617181420326233;
//	tileMap.emplace(p23, t23);
//
//	// ��24
//	cv::Point p24;
//	p24.x = 4;
//	p24.y = 2;
//	std::shared_ptr<Tile> t24 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t24->matchFlags[0] = 1;
//	t24->matchInfos[0].offset.x = 0;
//	t24->matchInfos[0].offset.y = 1535;
//	t24->matchInfos[0].precison = 0.7664613723754883;
//	// 00��
//	t24->matchFlags[1] = 1;
//	t24->matchInfos[1].offset.x = 0;
//	t24->matchInfos[1].offset.y = 4;
//	t24->matchInfos[1].precison = 0.609341025352478;
//	tileMap.emplace(p24, t24);
//
//	// ��25
//	cv::Point p25;
//	p25.x = 5;
//	p25.y = 2;
//	std::shared_ptr<Tile> t25 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t25->matchFlags[0] = 1;
//	t25->matchInfos[0].offset.x = 0;
//	t25->matchInfos[0].offset.y = 1535;
//	t25->matchInfos[0].precison = 0.7750424742698669;
//	// 00��
//	t25->matchFlags[1] = 1;
//	t25->matchInfos[1].offset.x = 0;
//	t25->matchInfos[1].offset.y = -1;
//	t25->matchInfos[1].precison = 0.18755599856376648;
//	tileMap.emplace(p25, t25);
//
//	// ��30
//	cv::Point p30;
//	p30.x = 0;
//	p30.y = 3;
//	std::shared_ptr<Tile> t30 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t30->matchFlags[0] = 1;
//	t30->matchInfos[0].offset.x = -4;
//	t30->matchInfos[0].offset.y = 0;
//	t30->matchInfos[0].precison = 0.6682491302490234;
//	// 00��
//	t30->matchFlags[1] = 0;
//	t30->matchInfos[1].offset.x = 0;
//	t30->matchInfos[1].offset.y = 0;
//	t30->matchInfos[1].precison = 0;
//	tileMap.emplace(p30, t30);
//
//	// ��31
//	cv::Point p31;
//	p31.x = 1;
//	p31.y = 3;
//	std::shared_ptr<Tile> t31 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t31->matchFlags[0] = 1;
//	t31->matchInfos[0].offset.x = 4;
//	t31->matchInfos[0].offset.y = 1530;
//	t31->matchInfos[0].precison = 0.5284025073051453;
//	// 00��
//	t31->matchFlags[1] = 1;
//	t31->matchInfos[1].offset.x = 1439;
//	t31->matchInfos[1].offset.y = 0;
//	t31->matchInfos[1].precison = 0.6996123790740967;
//	tileMap.emplace(p31, t31);
//
//	// ��32
//	cv::Point p32;
//	p32.x = 2;
//	p32.y = 3;
//	std::shared_ptr<Tile> t32 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t32->matchFlags[0] = 1;
//	t32->matchInfos[0].offset.x = 2;
//	t32->matchInfos[0].offset.y = 1078;
//	t32->matchInfos[0].precison = 0.8270704746246338;
//	// 00��
//	t32->matchFlags[1] = 1;
//	t32->matchInfos[1].offset.x = 0;
//	t32->matchInfos[1].offset.y = 4;
//	t32->matchInfos[1].precison = 0.32165053486824036;
//	tileMap.emplace(p32, t32);
//
//	// ��33
//	cv::Point p33;
//	p33.x = 3;
//	p33.y = 3;
//	std::shared_ptr<Tile> t33 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t33->matchFlags[0] = 1;
//	t33->matchInfos[0].offset.x = 0;
//	t33->matchInfos[0].offset.y = 1077;
//	t33->matchInfos[0].precison = 0.8111937642097473;
//	// 00��
//	t33->matchFlags[1] = 1;
//	t33->matchInfos[1].offset.x = 0;
//	t33->matchInfos[1].offset.y = -1535;
//	t33->matchInfos[1].precison = 0.619720458984375;
//	tileMap.emplace(p33, t33);
//
//	// ��34
//	cv::Point p34;
//	p34.x = 4;
//	p34.y = 3;
//	std::shared_ptr<Tile> t34 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t34->matchFlags[0] = 1;
//	t34->matchInfos[0].offset.x = 0;
//	t34->matchInfos[0].offset.y = 24;
//	t34->matchInfos[0].precison = 0.47710472345352173;
//	// 00��
//	t34->matchFlags[1] = 1;
//	t34->matchInfos[1].offset.x = 0;
//	t34->matchInfos[1].offset.y = 4;
//	t34->matchInfos[1].precison = 0.8199015855789185;
//	tileMap.emplace(p34, t34);
//
//	// ��35
//	cv::Point p35;
//	p35.x = 5;
//	p35.y = 3;
//	std::shared_ptr<Tile> t35 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t35->matchFlags[0] = 1;
//	t35->matchInfos[0].offset.x = 0;
//	t35->matchInfos[0].offset.y = 1078;
//	t35->matchInfos[0].precison = 0.8740029335021973;
//	// 00��
//	t35->matchFlags[1] = 1;
//	t35->matchInfos[1].offset.x = 0;
//	t35->matchInfos[1].offset.y = 6;
//	t35->matchInfos[1].precison = 0.5730481743812561;
//	tileMap.emplace(p35, t35);
//
//	// ��40
//	cv::Point p40;
//	p40.x = 0;
//	p40.y = 4;
//	std::shared_ptr<Tile> t40 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t40->matchFlags[0] = 1;
//	t40->matchInfos[0].offset.x = 0;
//	t40->matchInfos[0].offset.y = 1076;
//	t40->matchInfos[0].precison = 0.989032506942749;
//	// 00��
//	t40->matchFlags[1] = 0;
//	t40->matchInfos[1].offset.x = 0;
//	t40->matchInfos[1].offset.y = 0;
//	t40->matchInfos[1].precison = 0;
//	tileMap.emplace(p40, t40);
//
//	// ��41
//	cv::Point p41;
//	p41.x = 1;
//	p41.y = 4;
//	std::shared_ptr<Tile> t41 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t41->matchFlags[0] = 1;
//	t41->matchInfos[0].offset.x = -10;
//	t41->matchInfos[0].offset.y = 0;
//	t41->matchInfos[0].precison = 0.545343279838562;
//	// 00��
//	t41->matchFlags[1] = 1;
//	t41->matchInfos[1].offset.x = 1440;
//	t41->matchInfos[1].offset.y = 0;
//	t41->matchInfos[1].precison = 0.7770206332206726;
//	tileMap.emplace(p41, t41);
//
//	// ��42
//	cv::Point p42;
//	p42.x = 2;
//	p42.y = 4;
//	std::shared_ptr<Tile> t42 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t42->matchFlags[0] = 1;
//	t42->matchInfos[0].offset.x = 0;
//	t42->matchInfos[0].offset.y = 247;
//	t42->matchInfos[0].precison = 0.5346609950065613;
//	// 00��
//	t42->matchFlags[1] = 1;
//	t42->matchInfos[1].offset.x = 1428;
//	t42->matchInfos[1].offset.y = -4;
//	t42->matchInfos[1].precison = 0.8799972534179688;
//	tileMap.emplace(p42, t42);
//
//	// ��43
//	cv::Point p43;
//	p43.x = 3;
//	p43.y = 4;
//	std::shared_ptr<Tile> t43 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t43->matchFlags[0] = 1;
//	t43->matchInfos[0].offset.x = 0;
//	t43->matchInfos[0].offset.y = 1070;
//	t43->matchInfos[0].precison = 0.7572630643844604;
//	// 00��
//	t43->matchFlags[1] = 1;
//	t43->matchInfos[1].offset.x = 0;
//	t43->matchInfos[1].offset.y = 1;
//	t43->matchInfos[1].precison = -0.10894949734210968;
//	tileMap.emplace(p43, t43);
//
//	// ��44
//	cv::Point p44;
//	p44.x = 4;
//	p44.y = 4;
//	std::shared_ptr<Tile> t44 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t44->matchFlags[0] = 1;
//	t44->matchInfos[0].offset.x = -6;
//	t44->matchInfos[0].offset.y = 0;
//	t44->matchInfos[0].precison = 0.5493403673171997;
//	// 00��
//	t44->matchFlags[1] = 1;
//	t44->matchInfos[1].offset.x = 0;
//	t44->matchInfos[1].offset.y = -4;
//	t44->matchInfos[1].precison = 0.8557126522064209;
//	tileMap.emplace(p44, t44);
//
//	// ��45
//	cv::Point p45;
//	p45.x = 5;
//	p45.y = 4;
//	std::shared_ptr<Tile> t45 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t45->matchFlags[0] = 1;
//	t45->matchInfos[0].offset.x = -2042;
//	t45->matchInfos[0].offset.y = 1534;
//	t45->matchInfos[0].precison = 0.5571673512458801;
//	// 00��
//	t45->matchFlags[1] = 1;
//	t45->matchInfos[1].offset.x = 0;
//	t45->matchInfos[1].offset.y = -1535;
//	t45->matchInfos[1].precison = -0.22825796902179718;
//	tileMap.emplace(p45, t45);
//
//	// ��50
//	cv::Point p50;
//	p50.x = 0;
//	p50.y = 5;
//	std::shared_ptr<Tile> t50 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t50->matchFlags[0] = 1;
//	t50->matchInfos[0].offset.x = 0;
//	t50->matchInfos[0].offset.y = 1075;
//	t50->matchInfos[0].precison = 0.9874300360679626;
//	// 00��
//	t50->matchFlags[1] = 0;
//	t50->matchInfos[1].offset.x = 0;
//	t50->matchInfos[1].offset.y = 0;
//	t50->matchInfos[1].precison = 0;
//	tileMap.emplace(p50, t50);
//
//	// ��51
//	cv::Point p51;
//	p51.x = 1;
//	p51.y = 5;
//	std::shared_ptr<Tile> t51 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t51->matchFlags[0] = 1;
//	t51->matchInfos[0].offset.x = 0;
//	t51->matchInfos[0].offset.y = 1535;
//	t51->matchInfos[0].precison = 0.7405360341072083;
//	// 00��
//	t51->matchFlags[1] = 1;
//	t51->matchInfos[1].offset.x = 1178;
//	t51->matchInfos[1].offset.y = 0;
//	t51->matchInfos[1].precison = 0.22522802650928497;
//	tileMap.emplace(p51, t51);
//
//	// ��52
//	cv::Point p52;
//	p52.x = 2;
//	p52.y = 5;
//	std::shared_ptr<Tile> t52 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t52->matchFlags[0] = 1;
//	t52->matchInfos[0].offset.x = 2;
//	t52->matchInfos[0].offset.y = 1074;
//	t52->matchInfos[0].precison = 0.7926246523857117;
//	// 00��
//	t52->matchFlags[1] = 1;
//	t52->matchInfos[1].offset.x = 1427;
//	t52->matchInfos[1].offset.y = -5;
//	t52->matchInfos[1].precison = 0.9027984738349915;
//	tileMap.emplace(p52, t52);
//
//	// ��53
//	cv::Point p53;
//	p53.x = 3;
//	p53.y = 5;
//	std::shared_ptr<Tile> t53 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t53->matchFlags[0] = 1;
//	t53->matchInfos[0].offset.x = 0;
//	t53->matchInfos[0].offset.y = 0;
//	t53->matchInfos[0].precison = 0.36974385380744934;
//	// 00��
//	t53->matchFlags[1] = 1;
//	t53->matchInfos[1].offset.x = 0;
//	t53->matchInfos[1].offset.y = 4;
//	t53->matchInfos[1].precison = 0.6229782104492188;
//	tileMap.emplace(p53, t53);
//
//	// ��54
//	cv::Point p54;
//	p54.x = 4;
//	p54.y = 5;
//	std::shared_ptr<Tile> t54 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t54->matchFlags[0] = 1;
//	t54->matchInfos[0].offset.x = 0;
//	t54->matchInfos[0].offset.y = 1516;
//	t54->matchInfos[0].precison = 0.5582572817802429;
//	// 00��
//	t54->matchFlags[1] = 1;
//	t54->matchInfos[1].offset.x = 0;
//	t54->matchInfos[1].offset.y = 4;
//	t54->matchInfos[1].precison = 0.83234703540802;
//	tileMap.emplace(p54, t54);
//
//	// ��55
//	cv::Point p55;
//	p55.x = 5;
//	p55.y = 5;
//	std::shared_ptr<Tile> t55 = std::make_shared<Tile>(input, world_coor, store_in_memory, clone);
//	// 00��
//	t55->matchFlags[0] = 1;
//	t55->matchInfos[0].offset.x = 0;
//	t55->matchInfos[0].offset.y = 1516;
//	t55->matchInfos[0].precison = 0.5789828300476074;
//	// 00��
//	t55->matchFlags[1] = 1;
//	t55->matchInfos[1].offset.x = 0;
//	t55->matchInfos[1].offset.y = 4;
//	t55->matchInfos[1].precison = 0.6671748757362366;
//	tileMap.emplace(p55, t55);		
//	
//	// ���ر��λ
//	int resFlag = 0;
//
//	// ƽ̨��ģ�๹��
//	ModelingDefault* sm = new ModelingDefault();
//
//	// ģ�ͳ�ʼ��
//	sm->Init(6, 6, 2048, 1536, 3.0, 0.5, tileMap);
//	// ��ģ
//	sm->build(tileMap);
//
//
//	for (const auto& pair : tileMap)
//	{
//		// ��ȡkey
//		const cv::Point& key = pair.first;
//		// ��ȡvalue
//		const std::shared_ptr<Tile>& value = pair.second;
//		// ��ȡ�±�
//		int j = key.x;
//		int i = key.y;
//
//		std::cout << "i: " << i << " j: " << j << std::endl;
//		std::cout << "label: " << value->matchFlags[0] << " ncc: " << value->matchInfos[0].precison << " x: " << value->matchInfos[0].offset.x << " y: " << value->matchInfos[0].offset.y << std::endl;
//		std::cout << "label: " << value->matchFlags[1] << " ncc: " << value->matchInfos[1].precison << " x: " << value->matchInfos[1].offset.x << " y: " << value->matchInfos[1].offset.y << std::endl;
//
//	}
//
//	return 0;
//}