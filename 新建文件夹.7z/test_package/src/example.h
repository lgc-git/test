#pragma once
#include <chrono>
#include <string>
#include <iostream>
#include<opencv2/opencv.hpp>
#include"nlohmann/json.hpp"
int main_self();

//����ƴ�Ӳ�������
int test_BatchStitch();
int test_OverlapCut();
int test_NormalStitch();
int test_VHX();//����ʿͼ�����
int test_modeling();
int test_NormalStitchLgc();
int test_NormalStitchLgc2();
int test_NormalStitchLgc3();
int test_NormalStitchXC();
int test_NormalStitchXC2();
int test_NormalUseDataStitch();
int test_readbinary();

int test_StitchNewSxd();

// ����ɨ��ģʽö��
enum ScanType {
	RowColScan,
	SpiralScan,
	IrregularScan
};
//
int test_stitch_DiffType();//��ͬɨ��ͼ���ƴ��ģʽ
int simulate_ScanType(std::vector<std::vector<std::string>>& correctFiles, std::vector<std::vector<cv::Point>>& imgCoorVec, int row, int col, int imgNum, cv::Point spiralLeftUpPoint, ScanType scanMode);
int simulate_ScanTypeAdaptive(std::vector<std::vector<std::string>>& correctFilesVec, std::vector<std::vector<cv::Point>>& imgsCoorVec, int row, int col, int imgNum, cv::Point spiralLeftUp, ScanType scanMode, std::string imgFirstName = "", std::string imgLastName = "bmp");
//