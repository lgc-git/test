#include"example.h"
#include "example.h"
#include "alg_app_stitch.h"
#include "stitchConfig.h"
#include "alg_base_common.h"
#include <iostream>
#include "opencv2/opencv.hpp"
#include <windows.h>
#include<nlohmann/json.hpp>
#include<filesystem>
using namespace std;
using namespace cv;
using namespace stitchAlg;
namespace fs = std::filesystem;

int test_OverlapCut()
{
	string imageDir = "G:\\DMS\\0-StitchAbnormalAnalysis2\\beforeStitchAbnormal\\18-16-29-53\\";
	if (!fs::exists(imageDir)) {

		std::cout << "imageDir Error:" << imageDir << std::endl;
	}
	std::string configPath = imageDir + "/" + "config.json";
	std::string blenderPath = imageDir + "/" + "blender.json";
	std::ifstream configFile(configPath);
	int row_num = 10;
	int col_num = 10;
	StitchConfig stitchParams;
	stitchParams.cacheDir = "E:/StitchImgInfo/";
	stitchParams.matchTaskConsumerNum = 1;
	stitchParams.refineTaskConsumerNum = 1;
	stitchParams.horizontalOverlap = 0.5;//�ٷֱ�
	stitchParams.verticalOverlap = 0.5;
	stitchParams.taskConsumerType = eTaskConsumerDefault;
	ScanType scanMode = /*SpiralScan*/ RowColScan/*IrregularScan*/;
	if (configFile.is_open())
	{
		nlohmann::json jsonObj;
		configFile >> jsonObj;
		stitchParams.horizontalOverlap = jsonObj["horizontalOverlap"];
		stitchParams.verticalOverlap = jsonObj["verticalOverlap"];
		stitchParams.pathPlanningType = jsonObj["pathPlanningType"] /*0-ePathPlanningDefault; 1-ePathPlanningKruskal*/;
		stitchParams.imageHeight = jsonObj["imageHeight"];
		stitchParams.imageWidth = jsonObj["imageWidth"];
	}
	int iOverlapX = floor(stitchParams.imageWidth * stitchParams.horizontalOverlap);
	int iOverlapY = floor(stitchParams.imageHeight  * stitchParams.verticalOverlap);
	cv::Rect rectUp = cv::Rect(0, 0, stitchParams.imageWidth, iOverlapY);
	cv::Rect rectDown = cv::Rect(0, stitchParams.imageHeight - iOverlapY, stitchParams.imageWidth, iOverlapY);
	cv::Rect rectLeft = cv::Rect(0, 0, iOverlapX, stitchParams.imageHeight);
	cv::Rect rectRight = cv::Rect(stitchParams.imageWidth - iOverlapX, 0, iOverlapX, stitchParams.imageHeight);
	std::ifstream blenderFile(blenderPath);
	if (blenderFile.is_open())
	{
		nlohmann::json jsonObj;
		blenderFile >> jsonObj;
		row_num = jsonObj["GridInfo"]["height"];
		col_num = jsonObj["GridInfo"]["width"];
	}
	std::string saveRectImg = imageDir + "/rectImgs/";
	if (!fs::exists(saveRectImg))
	{
		if (fs::create_directory(saveRectImg));
	}
	for (int iRow = 0; iRow < row_num; iRow++)
	{
		for (int iCol = 0; iCol < col_num; iCol++)
		{
			std::string	imgName = to_string(iRow) + "_" + to_string(iCol);
			cv::Mat srcImg = cv::imread(imageDir + "//data//" + imgName + +".bmp");
			cv::Mat imgRectUp = srcImg(rectUp);
			cv::Mat imgRectDown = srcImg(rectDown);
			cv::Mat imgRectLeft = srcImg(rectLeft);
			cv::Mat imgRectRight = srcImg(rectRight);
			cv::imwrite(saveRectImg + imgName + "_Up.bmp", imgRectUp);
			cv::imwrite(saveRectImg + imgName + "_Down.bmp", imgRectDown);
			cv::imwrite(saveRectImg + imgName + "_Left.bmp", imgRectLeft);
			cv::imwrite(saveRectImg + imgName + "_Right.bmp", imgRectRight);
		}
		std::cout << "cut end" << std::endl;
	}
	
	return 1;
}