#include "example.h"
#include "alg_app_stitch.h"
#include "stitchConfig.h"
#include "alg_base_common.h"
#include <iostream>
#include "opencv2/opencv.hpp"
#include <windows.h>
using namespace std;
using namespace cv;
using namespace stitchAlg;

//
std::vector<std::vector<cv::Point>> polygons; // �洢�����յĶ����
std::vector<cv::Point> currentPolygon; // ��ǰ���ƵĶ����
bool drawing = false; // �Ƿ����ڻ���

// �������еĶ���κ͵�ǰ�����
void drawPolygons(cv::Mat& img) 
{
	img.setTo(cv::Scalar(0, 0, 0)); // ���ͼ��
	for (const auto& polygon : polygons) 
	{
		// �������
		cv::fillPoly(img, std::vector<std::vector<cv::Point>>{polygon}, cv::Scalar(0, 255, 0)); // ��ɫ���
		cv::polylines(img, polygon, true, cv::Scalar(255, 255, 255), 2); // ��ɫ�߿�
	}
	if (!currentPolygon.empty()) 
	{
		cv::polylines(img, currentPolygon, true, cv::Scalar(255, 0, 0), 2); // ��ɫ��ǰ����α߿�
	}
}

void mouseCallback(int event, int x, int y, int flags, void* userdata) {
	cv::Mat& img = *(cv::Mat*)userdata;

	if (event == cv::EVENT_LBUTTONDOWN) {
		drawing = true;
		currentPolygon.push_back(cv::Point(x, y)); // ������ʼ��
	}
	else if (event == cv::EVENT_MOUSEMOVE && drawing) {
		currentPolygon.push_back(cv::Point(x, y)); // ���ӵ�ǰ��
		drawPolygons(img);
		cv::imshow("Drawing", img);
	}
	else if (event == cv::EVENT_LBUTTONUP) {
		drawing = false;
		if (currentPolygon.size() > 2) { // ������Ҫ����������γɶ����
			currentPolygon.push_back(currentPolygon[0]); // �������һ�������һ����
			polygons.push_back(currentPolygon); // ���浱ǰ�����
		}
		currentPolygon.clear(); // ��յ�ǰ�����
		drawPolygons(img);
		cv::imshow("Drawing", img);
	}
}

//����������ƴ��
int irregularAreasStitch(std::vector<std::vector<string>>& correctFilesVec, std::vector<std::vector<cv::Point>>& imgsCoorVec, int row, int col)
{
	cv::Mat scanImg = cv::Mat::zeros(cv::Size(col, row), CV_8UC3);
	cv::Mat demoImg = scanImg.clone();
	cv::namedWindow("Drawing", cv::WINDOW_NORMAL);
	cv::setMouseCallback("Drawing", mouseCallback, &scanImg);

	while (true) {
		cv::imshow("Drawing", scanImg);
		if (cv::waitKey(30) == 27) { // ��ESC�˳�
			break;
		}
	}
	//
	// ת��Ϊ�Ҷ�ͼ
	cv::Mat gray;
	cv::cvtColor(scanImg, gray, cv::COLOR_BGR2GRAY);
	// Ӧ����ֵ
	cv::Mat binary;
	cv::threshold(gray, binary, 128, 255, cv::THRESH_BINARY);
	// Ѱ������
	std::vector<std::vector<cv::Point>> contours;
	cv::findContours(binary, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
	// ��ȡÿ�������ڵĵ�
	for (size_t i = 0; i < contours.size(); i++) 
	{
		std::vector<string > correctFiles;
		std::vector<cv::Point> imgsCoor;
		// ��ȡ�����ı߽��
		cv::Rect boundingBox = cv::boundingRect(contours[i]);

		// �����߽���ڵ�ÿ����
		for (int y = boundingBox.y; y < boundingBox.y + boundingBox.height; y++) {
			for (int x = boundingBox.x; x < boundingBox.x + boundingBox.width; x++) {
				// �����Ƿ���������
				if (cv::pointPolygonTest(contours[i], cv::Point(x, y), false) >= 0) {
					// ����ͼ���ϱ�ǵ�
					//scanImg.at<cv::Vec3b>(y, x) = cv::Vec3b(0, 255, 0); // ��ɫ��
					imgsCoor.emplace_back(cv::Point(x, y));
					std::string imgName = to_string(y) + "-" + to_string(x) + ".bmp";
					correctFiles.emplace_back(imgName);
				}
			}
		}
		correctFilesVec.emplace_back(correctFiles);
		imgsCoorVec.emplace_back(imgsCoor);
	}
	//
	
	//��֤ɨ������
	for (int k = 0; k < imgsCoorVec.size(); k++)
	{
		std::vector<cv::Point> imgsCoorTem = imgsCoorVec[k];
		for (int i = 0; i < imgsCoorTem.size(); i++)
		{
			cv::Point drawPoint = cv::Point(imgsCoorTem[i].x, imgsCoorTem[i].y);
			Vec3b colorR(0, 0, 255);
			demoImg.ptr<Vec3b>(drawPoint.y)[drawPoint.x] = colorR;
		}
	}
	return 1;
}
//
int simulate_ScanType(std::vector<std::vector<string>>& correctFilesVec, std::vector<std::vector<cv::Point>>& imgsCoorVec, int row, int col, int imgNum,cv::Point spiralLeftUp, ScanType scanMode)
{
	std::vector<string> correctFiles;
	std::vector<cv::Point> imgsCoor;
	switch (scanMode)
	{
	case RowColScan://���� - ��ɨ��
	{
		for (int iRow = 0; iRow < row; iRow++)
		{
			std::string imgName;
			//
			if (iRow % 2 != 0)
			{
				for (int iCol = (col - 1); iCol > (-1); iCol--)
				{
					imgName = to_string(iRow) + "_" + to_string(iCol) + ".bmp";
					correctFiles.emplace_back(imgName);
					imgsCoor.emplace_back(iCol, iRow);
				}
			}
			else
			{
				for (int iCol = 0; iCol < col; iCol++)
				{
					imgName = to_string(iRow) + "_" + to_string(iCol) + ".bmp";
					correctFiles.emplace_back(imgName);
					imgsCoor.emplace_back(iCol, iRow);
				}
			}
		}
		correctFilesVec.emplace_back(correctFiles);
		imgsCoorVec.emplace_back(imgsCoor);
		break;
	}
	case SpiralScan:
	{  // ��ʼ��
		std::array<int, 2> point = { 0, 0 };
		// ����
		std::array<std::array<int, 2>, 4> directs = { {{0, 1}, {1, 0}, {0, -1}, {-1, 0}} };
		// ���ڰ뾶����
		int number = 0;
		//����ȷ������ͼ������
		int imgInNum = 0;
		// �뾶
		int r = 1;
		std::string imgName = to_string(point[0]) + "-" + to_string(point[1]) + ".bmp";
		correctFiles.emplace_back(imgName);
		imgsCoor.emplace_back(point[0], point[1]);
		// ���ɵ�
		while (number <= imgNum && imgInNum < imgNum)
		{
			// ȷ����ǰ����
			int directsId = number % 4;
			auto direct = directs[directsId];
			// ���°뾶
			if (number > 0 && number % 2 == 0) {
				r += 1;
			}

			// ���ɵ�ǰ�����ϵĵ�
			for (int rNum = 0; rNum < r; ++rNum) 
			{
				std::cout << "Number: " << number << ", Point: ("
					<< point[0] + (rNum + 1) * direct[0] << ", "
					<< point[1] + (rNum + 1) * direct[1] << ")\n";
				//
				cv::Point imgRowColIndex = cv::Point(point[1] + (rNum + 1) * direct[1], point[0] + (rNum + 1) * direct[0]);
				imgName = to_string(imgRowColIndex.y - spiralLeftUp.y) + "-" + to_string(imgRowColIndex.x - spiralLeftUp.x) + ".bmp";
				correctFiles.emplace_back(imgName);
				//
				imgsCoor.emplace_back(imgRowColIndex);
				if (correctFiles.size() >= imgNum)
				{
					imgInNum = correctFiles.size() + 1;
					break;
				}
			}
			// ���µ�ǰλ��
			point[0] += r * direct[0];
			point[1] += r * direct[1];
			// ���±��
			number += 1;
			//
		}
		correctFilesVec.emplace_back(correctFiles);
		imgsCoorVec.emplace_back(imgsCoor);
		break;
	}
	case IrregularScan:
	{
		//������ƴ��,�����ͼ������������һ������,�ڴ����ڻ���ƴ������(����/���)��֧��,esc�˳����ڿ�ʼ�ֿ�ƴ��
		int resFlag = irregularAreasStitch(correctFilesVec, imgsCoorVec, row, col);
		break;
	}
	}

	return 0;
}
//
int simulate_ScanTypeAdaptive(std::vector<std::vector<string>>& correctFilesVec, std::vector<std::vector<cv::Point>>& imgsCoorVec, int row, int col, int imgNum, cv::Point spiralLeftUp, ScanType scanMode, std::string imgFirstName, std::string imgLastName)
{
	std::vector<string> correctFiles;
	std::vector<cv::Point> imgsCoor;
	switch (scanMode)
	{
	case RowColScan://���� - ��ɨ��
	{
		for (int iRow = 0; iRow < row; iRow++)
		{
			std::string imgName;
			//
			if (iRow % 2 != 0)
			{
				for (int iCol = (col - 1); iCol > (-1); iCol--)
				{
					imgName = imgFirstName + to_string(iRow) + "_" + to_string(iCol) + "." + imgLastName;
					correctFiles.emplace_back(imgName);
					imgsCoor.emplace_back(iCol, iRow);
				}
			}
			else
			{
				for (int iCol = 0; iCol < col; iCol++)
				{
					imgName = imgFirstName + to_string(iRow) + "_" + to_string(iCol) + "." + imgLastName;
					correctFiles.emplace_back(imgName);
					imgsCoor.emplace_back(iCol, iRow);
				}
			}
		}
		correctFilesVec.emplace_back(correctFiles);
		imgsCoorVec.emplace_back(imgsCoor);
		break;
	}
	}

	return 0;
}
//
int convertToRowColScanInfo(std::vector<cv::Point>& imgsCoor, int& iScanRow, int& iScanCol)
{
	int minPointX = 999999;
	int minPointY = 999999;
	int maxPointX = -99999;
	int maxPointY = -99999;
	for (int i = 0; i < imgsCoor.size(); i++)
	{
		if (imgsCoor[i].x < minPointX)
		{
			minPointX = imgsCoor[i].x;
		}
		if (imgsCoor[i].y < minPointY)
		{
			minPointY = imgsCoor[i].y;
		}
		if (imgsCoor[i].x > maxPointX)
		{
			maxPointX = imgsCoor[i].x;
		}
		if (imgsCoor[i].y > maxPointY)
		{
			maxPointY = imgsCoor[i].y;
		}
	}
	//
	cv::Point leftUpPoint = cv::Point(minPointX, minPointY);
	//
	iScanCol = maxPointX - minPointX + 1;
	iScanRow = maxPointY - minPointY + 1;
	//
	return 1;
}

//
int test_stitch_DiffType()
{
	_ALG_STITCH_Init();
	//
	int row_num = 6;
	int col_num = 6;
	//
	StitchConfig stitchParams;
	stitchParams.matchTaskConsumerNum = 4;
	stitchParams.refineTaskConsumerNum = 4;
	stitchParams.cacheDir = "./cache";
	//ͼ���Ƿ񱣴���CPU�ڴ���
	stitchParams.storeInMemory = true;
	//�Ƿ񿽱�����,����ʹ�õ��ö˿��ٵ��ڴ�(*falseʱͼ����ʹ����ʱ����)
	stitchParams.copyImage = false;
	//�洢����ͼ���ļ��ĵ�ַ
	std::vector<std::vector<string>> correctFilesVec;
	std::vector<std::vector<cv::Point>> imgsCoorVec;//�洢����ͼ�����������,�����ò�ͬɨ��ģʽ
	int imgNum = 45;//����ƴ����Ҫ�жϵ�ͼ������(������ƴ�ӻ�������)
	ScanType scanMode = SpiralScan /*RowColScan*//*IrregularScan*/;
	//ͼ���ļ���ַ:https://pan.sunnyoptical.cn/link/AR28BB805251C94B5A99BF906043C484A8
	string imageDir = "E:/DmsData/DMSimg/";
	//����ƴ�ӽ���������,ת������������;
	//���ͼ�������ǻ���ƴ������piralLeftUp = cv::Point(0,0);������Ҫ����ͼ��������������spiralLeftUp=(-(row-1)/2,-(row-1)/2);
	cv::Point spiralLeftUp = cv::Point(-3, -3);
	simulate_ScanType(correctFilesVec, imgsCoorVec, row_num, col_num, imgNum, spiralLeftUp, scanMode);
	//
	for (int k = 0; k < correctFilesVec.size(); k++)
	{
		std::vector<std::string> correctFiles = correctFilesVec[k];
		std::vector<cv::Point> imgsCoor = imgsCoorVec[k];
		//����ɨ���������/����
		/*int iScanRow_Num = row_num;
		int iScanCol_Num = col_num;
		convertToRowColScanInfo(imgsCoor, iScanRow_Num, iScanCol_Num);*/
		//
		cv::Mat srcImg = cv::imread(imageDir + correctFiles[0]);
		if (srcImg.empty())
		{
			//�����쳣����
			const char* title = "���󾯸�";
			const char* message = "ReadImg: Error";
			MessageBoxA(NULL, message, title, MB_OK | MB_ICONINFORMATION);

			return -1;
		}
		stitchParams.imageHeight = srcImg.rows;
		stitchParams.imageWidth = srcImg.cols;
		stitchParams.imageChannels = srcImg.channels();
		stitchParams.horizontalOverlap = 0.264286;
		stitchParams.verticalOverlap = 0.261905;
		stitchParams.cacheDir = "";
		
		//ƴ�ӷ��ںϷ���
		stitchParams.stitchBlenderType = /*eStitchBlenderBoardWeightTiff*/eStitchBlenderDefault/*eStitchBlenderBoardWeight*/;
		//
		std::vector<cv::Mat> ins;
		if (stitchParams.storeInMemory == true)
		{
			ins.resize(correctFiles.size());
			for (size_t i = 0; i < correctFiles.size(); i++)
			{
				ins[i] = cv::imread(imageDir + correctFiles[i], -1);
			}
		}
		//
		STITCH_HANDLE  stitch_handle = _ALG_STITCH_CreateStitchApp(stitchParams);
		if (stitch_handle == nullptr)
		{
			std::cout << "create stitch app error!" << endl;
			return -1;
		}
		int sourceType = -1;
		for (size_t i = 0; i < correctFiles.size(); i++)
		{
			/*cv::Mat input = cv::imread(imageDir + correctFiles[i], -1);*/
			SyImage image;
			image.data = ins[i].data;
			image.height = ins[i].rows;
			image.width = ins[i].cols;
			image.type = ins[i].type();
			sourceType = ins[i].type();
			cv::Point imgRowCol = imgsCoor[i];
			cout << "getImage" << i << endl;
			int flag = _ALG_STITCH_PostImageOnce(stitch_handle, image, imgRowCol.y, imgRowCol.x);
			//
			if (flag != 1)
			{
				cout << correctFiles[i] << endl;
			}
		}
		//
		int flag = _ALG_STITCH_PostImageFinish(stitch_handle);
		if (flag != 1)
		{
			cout << "_ALG_STITCH_PostImageFinish error!" << endl;
		}
		//
		flag = _ALG_STITCH_PlatformModel(stitch_handle);
		if (flag != 1)
		{
			cout << "_ALG_STITCH_PlatformModel error!" << endl;
		}
		//
		flag = _ALG_STITCH_RefineMatch(stitch_handle);
		if (flag != 1)
		{
			cout << "_ALG_STITCH_RefineMatch error!" << endl;
		}
		//
		flag = _ALG_STITCH_PathPlanning(stitch_handle);
		if (flag != 1)
		{
			cout << "_ALG_STITCH_PathPlanning error!" << endl;
		}
		//����ͼ��ƴ�Ӻ�Ŀ��͸�
		int resWidth, resHeight;
		_ALG_STITCH_GetWSISize(stitch_handle, resWidth, resHeight);
		//
		Mat res(resHeight, resWidth, sourceType, Scalar::all(0));
		SyImage resImage;
		resImage.data = res.data;
		resImage.width = res.cols;
		resImage.height = res.rows;
		resImage.type = res.type();
		_ALG_STITCH_WSIBlender(stitch_handle, resImage);
		//ͼ�����ۺ���
		float fScores;
		_ALG_STITCH_Evaluate(stitch_handle, fScores);
	}
	
	return 1;
}
