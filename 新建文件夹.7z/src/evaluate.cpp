#include"evaluate.h"

CEvaluateDefault::CEvaluateDefault()
{

}

CEvaluateDefault::~CEvaluateDefault()
{

}

int CEvaluateDefault::evaluate(const std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tiles_Map, float& fScore)
{
	//if (tiles_Map.size() == 0)
	//{
	//	return -1;
	//}
	//cv::Mat inImg;
	//size_t imgMemorySize = 0;
	//for (const auto& pair : tiles_Map)
	//{
	//	const cv::Point& point = pair.first;                // ��ȡ��
	//	const std::shared_ptr<Tile>& tile = pair.second;   // ��ȡֵ
	//	inImg = tile->getMat();
	//	imgMemorySize = size_t(inImg.rows* inImg.cols)* size_t(inImg.channels());
	//	break;
	//}
	//unsigned char** inImgPtr = new unsigned char*[tiles_Map.size()];
	//std::vector<cv::Mat> srcImgVec(tiles_Map.size());
	//std::vector<GlobalPoint> imgPoints(tiles_Map.size());
	//int i = 0;
	//for (const auto& pair : tiles_Map)
	//{
	//	const cv::Point& point = pair.first;                // ��ȡ��
	//	const std::shared_ptr<Tile>& tile = pair.second;   // ��ȡֵ
	//	inImg = tile->getMat();
	//	GlobalPoint pTem;
	//	pTem.x = tile->_global_coor.x;
	//	pTem.y = tile->_global_coor.y;
	//	imgPoints[i] = pTem;
	//	srcImgVec[i] = inImg;
	//	inImgPtr[i] = new unsigned char [imgMemorySize];
	//	memcpy(inImgPtr[i], inImg.data, imgMemorySize);
	//	i++;
	//}
	//
	//EvaluateParam matchInfo;
	//matchInfo.iImgWidth = srcImgVec[0].cols;
	//matchInfo.iImgHeight = srcImgVec[0].rows;
	//matchInfo.iInBitDepth = 8;
	//matchInfo.iBufferNums = srcImgVec.size();
	//int evaFlag = imageStitchQualityEva(inImgPtr, imgPoints, matchInfo);
	//fScore = matchInfo.stitchMeanScores;
	//for (int i = 0; i < tiles_Map.size(); ++i) {
	//	delete[] inImgPtr[i]; // �ͷ�ÿһ�е��ڴ�
	//}
	//delete[] inImgPtr; // �ͷ�ָ������
	return 1;
}

