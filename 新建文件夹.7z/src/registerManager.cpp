﻿#include "registerManager.h"

template<typename BaseType, typename DerivedType, typename keyType>
void register_class_once(const keyType& key)
{
	std::string skey = std::to_string(int(key));
	factory<BaseType>::register_t<DerivedType>REGISTER_CLASS_VNAME(BaseType, DerivedType)(skey);
}

template<typename BaseType, typename DerivedType, typename keyType, typename... Args>
void register_class_once(keyType& key, Args... args)
{
	std::string skey = std::to_string(int(key));
	factory<BaseType>::register_t<DerivedType>REGISTER_CLASS_VNAME(BaseType, DerivedType)(skey, args);
}


void registerClass()
{
	//注册TileProducer
	register_class_once<TileProducerDefault, TileProducerDefault, TileProducerType>(TileProducerType::eTileProducerDefault);

	//注册TaskProducer
	register_class_once<TaskProducerDefault, TaskProducerDefault, TaskProducerType>(TaskProducerType::eTaskProducerDefault);

	//注册TaskConsumer
	register_class_once<TaskConsumerDefault, TaskConsumerDefault, TaskConsumerType>(TaskConsumerType::eTaskConsumerDefault);
	register_class_once<TaskConsumerDefault, TaskConsumerSIFT, TaskConsumerType>(TaskConsumerType::eTaskConsumerSIFT);

	//注册platformModel
	register_class_once<ModelingDefault, ModelingDefault, PlatformModelType>(PlatformModelType::ePlatformModelDefault);

	//注册RefineConsumer
	register_class_once<RefineConsumerDefault, RefineConsumerDefault, RefineConsumerType>(RefineConsumerType::eRefineConsumerDefault);

	//注册PathPlanningDefault
	register_class_once<PathPlanningDefault, PathPlanningKruskal, PathPlanningType>(PathPlanningType::ePathPlanningDefault);
	register_class_once<PathPlanningDefault, PathPlanningNearest, PathPlanningType>(PathPlanningType::ePathPlanningNearest);

	//注册BlenderDefault
	register_class_once<BlenderDefault, BlenderDefault, StitchBlenderType>(StitchBlenderType::eStitchBlenderDefault);
	register_class_once<BlenderDefault, CBoarderWeightFusion, StitchBlenderType>(StitchBlenderType::eStitchBlenderBoardWeight);
	register_class_once<BlenderDefault, CBoarderPyrFusion, StitchBlenderType>(StitchBlenderType::eStitchBlenderBoardPyr);
	//注册CEvaluateDefault
	register_class_once< CEvaluateDefault, CEvaluateDefault, StitchEvaluateType>(StitchEvaluateType::eEvaluateNCC);
	return;
}
