﻿#include "stitchDataStruct.h"
#include "errorInfo.h"
AtomicTaskQueue::AtomicTaskQueue() 
{
	
}
AtomicTaskQueue::~AtomicTaskQueue() 
{
	
}

void AtomicTaskQueue::push(std::shared_ptr<Task>& task)
{
	std::unique_lock<std::mutex> lock(mtx);
	taskQueue.push(task);
	return;
}
bool AtomicTaskQueue::take(std::shared_ptr<Task>& task)
{
	std::unique_lock<std::mutex> lock(mtx);
	if (!taskQueue.empty())
	{
		task = taskQueue.front();
		taskQueue.pop();
		return true;
	}
	else
	{
		return false;
	}
}


nlohmann::json AtomicTaskQueue::toJson()
{
	// 创建一个临时队列用于遍历
	std::queue<std::shared_ptr<Task>> tempQueue;
	// 遍历队列并将元素存入临时队列
	nlohmann::json jsonObj;
	while (!taskQueue.empty())
	{
		std::shared_ptr<Task> front = taskQueue.front();      // 获取队头元素
		jsonObj.merge_patch(front->toJson());
		tempQueue.push(front);       // 将元素放入临时队列
		taskQueue.pop();                     // 移除队头元素
	}
	// 将元素重新放回原队列
	while (!tempQueue.empty())
	{
		taskQueue.push(tempQueue.front());
		tempQueue.pop();
	}
	return jsonObj;
}
int AtomicTaskQueue::fromJson(nlohmann::json& jsonObj, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap)
{
	for (nlohmann::json::iterator it = jsonObj.begin(); it != jsonObj.end(); ++it)
	{
		Position point1, point2;
		std::string col1_str, row1_str, col2_str, row2_str;

		// 使用字符串流分割字符串
		std::istringstream ss(it.key());

		// 获取第一个点的坐标
		std::getline(ss, col1_str, '_');
		std::getline(ss, row1_str, '_');

		// 获取第二个点的坐标
		std::getline(ss, col2_str, '_');
		std::getline(ss, row2_str); // 最后一个值没有分隔符

		// 将字符串转换为整数
		point1._col = std::stoi(col1_str);
		point1._row = std::stoi(row1_str);
		point2._col = std::stoi(col2_str);
		point2._row = std::stoi(row2_str);
		std::shared_ptr<Tile> t1_ptr = tileMap[point1];
		std::shared_ptr<Tile> t2_ptr = tileMap[point2];

		cv::Point relativeWorldCoor, relativeGlobalCoor;
		nlohmann::json val = it.value();
		std::shared_ptr<Task> task = std::make_shared<Task>();
		task->fromJson(val, t1_ptr, t2_ptr);
		taskQueue.push(task);
	}
	return INFO_OK;
}

