﻿#include "ncc.h"

int computeNCC_8UC1(const cv::Mat& a1, const cv::Mat& a2, double& nccVal)
{
	if (a1.size() != a2.size())
	{
		return -1;
	}
	double sz = a1.total();
	int block_size = 2;
	__m128d sum_a2 = _mm_setr_pd(0, 0);
	__m128d sum_b2 = _mm_setr_pd(0, 0);
	__m128d sum_ab = _mm_setr_pd(0, 0);
	__m128d sum_a = _mm_setr_pd(0, 0);
	__m128d sum_b = _mm_setr_pd(0, 0);

	float r_sum_a2 = 0;
	float r_sum_b2 = 0;
	float r_sum_ab = 0;
	float r_sum_a = 0;
	float r_sum_b = 0;

	cv::Mat t1, t2;
	a1.convertTo(t1, CV_32F);
	a2.convertTo(t2, CV_32F);
	double aaaa = 0;
	int i = 0;
	for (; i < a1.rows; i++)
	{
		const uchar* rowPtr1 = a1.ptr<uchar>(i);
		const uchar* rowPtr2 = a2.ptr<uchar>(i);
		int j = 0;
		for (; j < a1.cols - block_size + 1; j += block_size)
		{
			__m128d a = _mm_cvtepi32_pd(_mm_cvtepu8_epi32(_mm_loadu_si128((__m128i*)&rowPtr1[j])));
			__m128d b = _mm_cvtepi32_pd(_mm_cvtepu8_epi32(_mm_loadu_si128((__m128i*)&rowPtr2[j])));
			sum_a2 = _mm_add_pd(_mm_mul_pd(a, a), sum_a2);
			sum_b2 = _mm_add_pd(_mm_mul_pd(b, b), sum_b2);
			sum_ab = _mm_add_pd(_mm_mul_pd(a, b), sum_ab);
			sum_a = _mm_add_pd(a, sum_a);
			sum_b = _mm_add_pd(b, sum_b);
		}
		for (; j < a1.cols; j++)
		{
			float a = static_cast<float>(rowPtr1[j]);
			float b = static_cast<float>(rowPtr2[j]);
			r_sum_a2 += a * a;
			r_sum_b2 += b * b;
			r_sum_ab += a * b;
			r_sum_a += a;
			r_sum_b += b;
		}
	}


	double val_sum_a2 = MM_EXTRACT_DOUBLE(sum_a2, 0) + MM_EXTRACT_DOUBLE(sum_a2, 1) + r_sum_a2;
	double val_sum_b2 = MM_EXTRACT_DOUBLE(sum_b2, 0) + MM_EXTRACT_DOUBLE(sum_b2, 1) + r_sum_b2;
	double val_sum_ab = MM_EXTRACT_DOUBLE(sum_ab, 0) + MM_EXTRACT_DOUBLE(sum_ab, 1) + r_sum_ab;
	double val_sum_a = MM_EXTRACT_DOUBLE(sum_a, 0) + MM_EXTRACT_DOUBLE(sum_a, 1) + r_sum_a;
	double val_sum_b = MM_EXTRACT_DOUBLE(sum_b, 0) + MM_EXTRACT_DOUBLE(sum_b, 1) + r_sum_b;

	double numer = val_sum_ab - val_sum_a * (val_sum_b / sz);
	double denom = std::sqrt((val_sum_a2 - val_sum_a * (val_sum_a / sz)) * (val_sum_b2 - val_sum_b * (val_sum_b / sz)));
	nccVal = numer / denom;
	if (std::isnan(nccVal) || std::isinf(nccVal))
	{
		nccVal = -1.0;
	}
	return 1;
}

