﻿#include "tileProducer.h"

TileProducerDefault::TileProducerDefault()
{
}

TileProducerDefault::~TileProducerDefault()
{
}
void TileProducerDefault::setStitchConfig(const StitchConfig & config) 
{
	_config = config;
	return;
}
std::shared_ptr<Tile> TileProducerDefault::tileProduce(void* ptr_Mapping)
{
	return std::make_shared<Tile>(_config.storeInMemory, _config.copyImage, ptr_Mapping, _config._mappingFileDir);
}

template<class TileProducerType>
std::shared_ptr<TileProducerDefault> createTileProducer()
{
	return std::make_shared<TileProducerType>();
}


