﻿#include "stitchDataStruct.h"
#include <corecrt_io.h>
#include "alg_base_common.h"
#include <algorithm>
#include <filesystem>
#include"readSaveImg.h"
namespace fs = std::filesystem;


Tile::Tile(const bool storeInMemory, const bool clone,  void* ptr_Mapping, const std::string& cacheDir): _store_in_memory(storeInMemory), _clone(clone), _ptr_Mapping(ptr_Mapping), _cacheDir(cacheDir)
{
}

Tile::~Tile()
{

}


int Tile::saveMat(const cv::Mat& input, const Position & grid_coor)
{
	if (_store_in_memory)
	{
		if (_clone)
		{
			_input = input.clone();
		}
		else
		{
			_input = input;
		}
	}
	else
	{

		ESaveMode mySave = MAPPING/*WRITE*/;
		_path = _cacheDir + "/" + std::to_string(grid_coor._row) + "_" + std::to_string(grid_coor._col) + ".data";
		int resFlag = saveMatToDisk(input, _path, mySave);
		if (resFlag != 1)
		{
			return INFO_FAIL;
		}
	}

	_grid_coor = grid_coor;
	return INFO_OK;
}


cv::Mat Tile::getMat()
{
	if (_store_in_memory)
	{
		return _input;
	}
	else
	{
		cv::Mat outImg;
		int resFlag = getMappingImg(&_ptr_Mapping, outImg, _path);
		//int resFlag = readMapingImgStitch(_path, outImg);
		if (resFlag != 1 || outImg.empty())
		{
			LOG_ERROR("default", "readMapingImgStitch outImg empty !");
			throw std::runtime_error("readMapingImgStitch outImg empty !");
		}
		return outImg;  
	}
}

void Tile::cacheMat(const std::string& cacheDir, const bool & storeOrNot)
{
	try
	{
		if (cacheDir != "" && storeOrNot)
		{
			std::string saveDir = cacheDir + "/data";
			fs::path save_root = saveDir;
			if (!fs::exists(save_root)) {
				if (fs::create_directory(save_root))
				{
					//LOG_INFO("default", "Directory created: " + saveDir);
				}
				else
				{
					LOG_ERROR("default", "Failed to create directory: " + saveDir);
				}
			}
			std::string savePath = saveDir + "/" + getRowColKeyStr() + ".bmp";
			cv::Mat img = this->getMat();
			cv::Mat saveImg;
			cv::cvtColor(img, saveImg, cv::COLOR_RGB2BGR);
			cv::imwrite(savePath, saveImg);
		}
	}
	catch (std::exception stdError)
	{
		LOG_ERROR("default", stdError.what());
		return;
	}
}

nlohmann::json Tile::toJson()
{
	nlohmann::json jsonObj;
	std::string key = getRowColKeyStr();
	jsonObj[key]["_grid_coor"] = {  _grid_coor._row, _grid_coor._col};
	jsonObj[key]["_global_coor"] = { _global_coor.x, _global_coor.y };
	for (size_t i = 0; i < 4; i++)
	{
		jsonObj[key]["matchFlags"][i] = matchFlags[i];
		jsonObj[key]["matchInfos"][i] = { matchInfos[i].offset.x, matchInfos[i].offset.y, matchInfos[i].precison };
	}
	return jsonObj;
}

void Tile::fromJson(const nlohmann::json& jsonObj) 
{
	jsonObj["_grid_coor"][0].get_to(_grid_coor._row);
	jsonObj["_grid_coor"][1].get_to(_grid_coor._col);

	jsonObj["_global_coor"][0].get_to(_global_coor.x);
	jsonObj["_global_coor"][1].get_to(_global_coor.y);

	for (size_t i = 0; i < 4; i++)
	{
		jsonObj["matchFlags"][i].get_to(matchFlags[i]);
		jsonObj["matchInfos"][i][0].get_to(matchInfos[i].offset.x);
		jsonObj["matchInfos"][i][1].get_to(matchInfos[i].offset.y);
		jsonObj["matchInfos"][i][2].get_to(matchInfos[i].precison);
	}
	return;
}
std::string Tile::getRowColKeyStr()
{
	return std::to_string(int(_grid_coor._row)) + "_" + std::to_string(int(_grid_coor._col));
}

template<typename Key, typename Value, typename Hash>
std::pair<typename std::unordered_map<Key, Value, Hash>::iterator, bool> TileMap<Key, Value, Hash>::insert(const Key& key, const Value& value, const std::string& cacheDir)
{
	std::unique_lock<std::mutex> lock(mtx);
	auto res = std::unordered_map<Key, Value, Hash>::insert({ key, value });
	if (res.second)
	{
		grid_coor_min_row = grid_coor_min_row < key._row ? grid_coor_min_row : key._row;
		grid_coor_max_row = grid_coor_max_row > key._row ? grid_coor_max_row : key._row;
		grid_coor_min_col = grid_coor_min_col < key._col ? grid_coor_min_col : key._col;
		grid_coor_max_col = grid_coor_max_col > key._col ? grid_coor_max_col : key._col;
		value->cacheMat(cacheDir, storeOrNot);
	}
	return res;
}


template<typename Key, typename Value, typename Hash>
typename std::unordered_map<Key, Value, Hash>::iterator TileMap<Key, Value, Hash>::find(const Key& key)
{
	std::unique_lock<std::mutex> lock(mtx);
	auto it = std::unordered_map<Key, Value, Hash>::find(key);
	return it;
}

template<typename Key, typename Value, typename Hash>
nlohmann::json TileMap<Key, Value, Hash>::toJson()
{
	std::unique_lock<std::mutex> lock(mtx);
	nlohmann::json jsonObj;
	for (auto it = this->begin(); it != this->end(); ++it)
	{
		jsonObj["TileMapInfos"].merge_patch(it->second->toJson());
	}

	jsonObj["GridInfo"]["grid_coor_min_row"] = grid_coor_min_row;
	jsonObj["GridInfo"]["grid_coor_max_row"] = grid_coor_max_row;
	jsonObj["GridInfo"]["grid_coor_min_col"] = grid_coor_min_col;
	jsonObj["GridInfo"]["grid_coor_max_col"] = grid_coor_max_col;
	jsonObj["GridInfo"]["width"] = width();
	jsonObj["GridInfo"]["height"] = height();

	return jsonObj;
}

template<typename Key, typename Value, typename Hash>
void  TileMap<Key, Value, Hash>::fromJson(const nlohmann::json& jsonObj, const std::string& cacheDir)
{
	nlohmann::json jsonObj_TileMapInfos = jsonObj["TileMapInfos"];
	for (nlohmann::json::iterator it = jsonObj_TileMapInfos.begin(); it != jsonObj_TileMapInfos.end(); ++it)
	{
		std::string row_str, col_str;

		// 使用字符串流分割字符串
		std::istringstream ss(it.key());
		std::getline(ss, row_str, '_'); // 以 '_' 为分隔符获取 x
		std::getline(ss, col_str);       // 获取 y

		Position p(std::stoi(row_str), std::stoi(col_str));
		std::shared_ptr<Tile> tile = std::make_shared<Tile>(true, true, nullptr, "");
		tile->fromJson(it.value());

		std::string imagePath = cacheDir + "/data/" + ss.str() + ".bmp";
		cv::Mat image = cv::imread(imagePath);
		tile->saveMat(image, p);

		this->insert(p, tile, "");
	}

	nlohmann::json jsonObj_GridInfo = jsonObj["GridInfo"];
	jsonObj_GridInfo["grid_coor_min_row"].get_to(grid_coor_min_row);
	jsonObj_GridInfo["grid_coor_max_row"].get_to(grid_coor_max_row);
	jsonObj_GridInfo["grid_coor_min_col"].get_to(grid_coor_min_col);
	jsonObj_GridInfo["grid_coor_max_col"].get_to(grid_coor_max_col);
	return;
}

template class TileMap<Position, std::shared_ptr<Tile>, Position::Hash>;



Task::Task(const std::shared_ptr<Tile>& t1_ptr, const std::shared_ptr<Tile>& t2_ptr, const Position& relativeWorldCoor, const cv::Point& relativeOffset, const cv::Point& platformDeviationCoor)
	:_t1_ptr(t1_ptr), _t2_ptr(t2_ptr), _relativeGridCoor(relativeWorldCoor), _relativeGlobalCoor(relativeOffset), _platformDeviationCoor(platformDeviationCoor)
{
}

Task::~Task()
{
}


nlohmann::json Task::toJson() 
{
	std::string key = std::to_string(_t1_ptr->_grid_coor._row) + "_" + std::to_string(_t1_ptr->_grid_coor._col) + "_" +\
						std::to_string(_t2_ptr->_grid_coor._row) + "_" + std::to_string(_t2_ptr->_grid_coor._col);
	nlohmann::json jsonObj;
	jsonObj[key]["_relativeGridCoor"] = { _relativeGridCoor._row, _relativeGridCoor._col };
	jsonObj[key]["_relativeGlobalCoor"] = { _relativeGlobalCoor.x, _relativeGlobalCoor.y };
	jsonObj[key]["_platformDeviationCoor"] = { _platformDeviationCoor.x, _platformDeviationCoor.y };

	return jsonObj;
}

void Task::fromJson(const nlohmann::json& jsonObj, const std::shared_ptr<Tile>& t1_ptr, const std::shared_ptr<Tile>& t2_ptr)
{
	jsonObj["_relativeGridCoor"][0].get_to(_relativeGridCoor._row);
	jsonObj["_relativeGridCoor"][1].get_to(_relativeGridCoor._col);

	jsonObj["_relativeGlobalCoor"][0].get_to(_relativeGlobalCoor.x);
	jsonObj["_relativeGlobalCoor"][1].get_to(_relativeGlobalCoor.y);

	jsonObj["_platformDeviationCoor"][0].get_to(_platformDeviationCoor.x);
	jsonObj["_platformDeviationCoor"][1].get_to(_platformDeviationCoor.y);

	_t1_ptr = t1_ptr;
	_t2_ptr = t2_ptr;

	return;
}

