#include"readSaveImg.h"

#include <filesystem>
using namespace cv;
using namespace std;
//

// �ڴ�ӳ�䱣��ͼ��
int memMapToDiskStitch(const cv::Mat &image, const std::string &filename) {
	size_t mmf_size = image.total() * image.elemSize();
	DWORD error_code;
	const char *file_nameChar = filename.c_str();
	HANDLE hFile = CreateFile(file_nameChar, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL,
		OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hFile == INVALID_HANDLE_VALUE) {
		error_code = GetLastError();
		if (error_code == ERROR_FILE_NOT_FOUND) {
			std::cerr << "����: �ļ�δ�ҵ� (�������: " << error_code << ")" << std::endl;
		}
		else {
			std::cerr << "����: �޷����ļ� (�������: " << error_code << ")" << std::endl;
		}
		std::cerr << "CreateFileA CreateFile Error: " + error_code << error_code << std::endl;
		return error_code;
	}
	ULARGE_INTEGER uliMaximumSize;
	uliMaximumSize.QuadPart = static_cast<ULONGLONG>(mmf_size);
	HANDLE hMapFile =
		CreateFileMappingW(hFile, NULL, PAGE_READWRITE, uliMaximumSize.HighPart, uliMaximumSize.LowPart, NULL);
	;
	if (hMapFile == NULL) {
		error_code = GetLastError();
		std::cerr << "CreateFileMapping  Error: " + error_code << error_code << std::endl;
		std::string errorInfo = "CreateFileMapping Error: " + error_code;
		CloseHandle(hFile);
		return 1;
	}
	uchar *mappedImageData = static_cast<uchar *>(hMapFile);
	LPVOID mmfm_base_address = MapViewOfFile(mappedImageData, FILE_MAP_ALL_ACCESS, 0, 0, mmf_size);
	CopyMemory((PVOID)mmfm_base_address, image.data /*imgData.pInBuffer*/, mmf_size);

	if (UnmapViewOfFile(mmfm_base_address) == FALSE) {
		error_code = GetLastError();
		std::cout << "deleteMappingMemory UnmapViewOfFile(m_mmfm_base_address) == FALSE Error: " + to_string(error_code)
			<< std::endl;
		std::string errorStr =
			"deleteMappingMemory UnmapViewOfFile(m_mmfm_base_address) == FALSE Error:" + to_string(error_code);
	}
	if (hMapFile != nullptr) {
		CloseHandle(hMapFile);
		error_code = GetLastError();
		if (error_code != 0) {
			std::cout << "CloseHandle(m_mmfmHandle) error: " << error_code << endl;
			std::string errorStr = "CloseHandle(m_mmfmHandle): " + to_string(error_code);
		}
	}
	hMapFile = nullptr;
	if (hMapFile != nullptr) {
		//
		CloseHandle(hMapFile);
		error_code = GetLastError();
		if (error_code != 0) {
			std::cout << "CloseHandle(m_mmHandle) error: " << error_code << endl;
			// CSunnyLog("deleteMappingMemory CloseHandle(m_mmHandle) Error: " + to_string(error_code));
			std::string errorStr = "CloseHandle(m_mmHandle): " + to_string(error_code);
		}
		hMapFile = nullptr;
	}
	return 1;
}

// �� cv::Mat ����д���ļ�
int saveMatToFileStitch(const cv::Mat &mat, const std::string &filename) {
	try {
		if (mat.empty()) {
			throw std::invalid_argument("Input cv::Mat is empty.");
		}

		// ���ļ�
		std::ofstream outFile(filename, std::ios::binary);
		if (!outFile.is_open()) {
			throw std::runtime_error("Failed to open file for writing.");
		}
		// д��ͼ������
		int rows = mat.rows, cols = mat.cols, type = mat.type();
		outFile.write((char*)&rows, sizeof(int));
		outFile.write((char*)&cols, sizeof(int));
		outFile.write((char*)&type, sizeof(int));
		outFile.write((char*)mat.data, mat.total() * mat.elemSize());

		outFile.close();
		return 1;
	}
	catch (const cv::Exception &cv_str) {
		std::string error_info = cv_str.what();
		LOG_ERROR("default", "scanAreaImageStitchMapFusion " + error_info);
		return ERR_TRY_CATCH_OPENCV;
	}
	catch (const std::string &std_str) {
		std::string error_info = std_str;
		LOG_ERROR("default", "scanAreaImageStitchMapFusion " + error_info);
		return ERR_TRY_CATCH_STD;
	}
}

// ����ͼ�񵽴�����
int saveMatToDiskStitch(const cv::Mat &in_Img, const std::string &name_Str, ESaveMode saveMode) {
	try {
		int resFlag = 0;
		switch (saveMode) {
		case WRITE: {
			resFlag = saveMatToFileStitch(in_Img, name_Str);
			break;
		}
		case MAPPING: {
			resFlag = memMapToDiskStitch(in_Img, name_Str);
			break;
		}
		default:
			resFlag = saveMatToFileStitch(in_Img, name_Str);
			break;
		}
		return resFlag;
	}
	catch (const cv::Exception &cv_str) {
		std::string error_info = cv_str.what();
		LOG_ERROR("default", "scanAreaImageStitchMapFusion " + error_info);
		return ERR_TRY_CATCH_OPENCV;
	}
	catch (const std::string &std_str) {
		std::string error_info = std_str;
		LOG_ERROR("default", "scanAreaImageStitchMapFusion " + error_info);
		return ERR_TRY_CATCH_STD;
	}
}
// �����ƶ�ȡ
cv::Mat loadFromBinary(const string& filename)
{
	try
	{
		ifstream inFile(filename, ios::binary);
		if (!inFile) {
			cerr << "�޷����ļ� " << filename << " ���ж�ȡ��" << endl;
			LOG_ERROR("default", "can not open img binary file"); 
			return Mat();
		}

		int rows, cols, type;
		inFile.read((char*)&rows, sizeof(int));
		inFile.read((char*)&cols, sizeof(int));
		inFile.read((char*)&type, sizeof(int));

		Mat img(rows, cols, type);
		inFile.read((char*)img.data, img.total() * img.elemSize());

		inFile.close();
		return img;
	}
	catch (std::exception errStr)
	{
		LOG_ERROR("default", errStr.what());
		return cv::Mat();
	}
	catch (cv::Exception errStr)
	{
		LOG_ERROR("default", errStr.what());
		return cv::Mat();
	}
}
//

int readMapingImgStitch(std::string imgPath, cv::Mat& outImg)
{
	try
	{
		outImg = loadFromBinary(imgPath);
		return 1;
	}
	catch (std::exception errStr)
	{
		LOG_ERROR("default", errStr.what());
		return ERR_TRY_CATCH_STD;
	}
	catch (cv::Exception errStr)
	{
		LOG_ERROR("default", errStr.what());
		return ERR_TRY_CATCH_OPENCV;
	}
}