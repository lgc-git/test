﻿#pragma once
#include <memory>
#include "opencv2/opencv.hpp"
#include "taskProducer.h"

TaskProducerDefault::TaskProducerDefault() 
{
	
}
TaskProducerDefault::~TaskProducerDefault() 
{
	
}
std::shared_ptr<Task> TaskProducerDefault::taskProduce(const std::shared_ptr<Tile>& t1_ptr, const std::shared_ptr<Tile>& t2_ptr, const Position & relativeGridCoor, const cv::Point& relativeGlobalCoor, const cv::Point& platformDeviationCoor)
{
	return std::make_shared<Task>(t1_ptr, t2_ptr, relativeGridCoor, relativeGlobalCoor, platformDeviationCoor);
}