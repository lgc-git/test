﻿#include "taskConsumer.h"
#include"matchResultDemo.h"
#include "ncc.h"
#ifdef GPU_SUPPORT

#endif // GPU_SUPPORT


TaskConsumerDefault::TaskConsumerDefault() 
{
}

TaskConsumerDefault::~TaskConsumerDefault() 
{
}

int TaskConsumerDefault::taskConsume(const std::shared_ptr<Task>& task_ptr) 
{
	if (!task_ptr)
	{
		throw std::invalid_argument("Consume task_ptr is null");
	}
	Task& task = *task_ptr;
	MatchInfo result;
	 
	cv::Mat img_in1 = task._t1_ptr->getMat();
	cv::Mat img_in2 = task._t2_ptr->getMat();
	Position relativeWorldCoor = task._relativeGridCoor;
	cv::Point relativeOffset = task._relativeGlobalCoor;
	cv::Point PtDeviationBias = task._platformDeviationCoor;
	//cv::Point relativeOffset = { -1500, 0 };
	if (img_in1.empty() || img_in2.empty())
	{
		return ERR_IMG_EMPTY;
	}
	int matchOriten;	// "0"-左右  "1"-上下
	if (relativeWorldCoor == Position(0, 1) || relativeWorldCoor == Position(0, -1)) {
		matchOriten = 0;	// 第二张图在第一张图右侧或左侧
	}
	else
	{
		matchOriten = 1;	// 第二张图在第一张图下方或上方
	}

	// 提取重叠区域ROI
	cv::Mat img_in1_roi = extract_subregion(img_in1, relativeOffset.x, relativeOffset.y);
	if (img_in1_roi.empty())
	{
		return -1;
	}
	cv::Mat img_in2_roi = extract_subregion(img_in2, -relativeOffset.x, -relativeOffset.y);
	if (img_in2_roi.empty())
	{
		return -1;
	}
	//PtDeviationBias = { 50,50 };
	cv::Point outputPtBias;
	double matchValue = -1;

	// 图像匹配
	int matchFlag = matchOption_PCIAM(img_in1_roi, img_in2_roi, PtDeviationBias, matchOriten, outputPtBias, matchValue);
	if (!matchFlag)
	{
		return ERR_FUNC_FAILED;
	}

	// 偏移量计算
	cv::Point allPtBias;
	allPtBias = relativeOffset - outputPtBias;

	if (relativeWorldCoor == Position(0, 1))		// 右侧
	{
		task._t1_ptr->matchFlags[1] = 1;	//右
		task._t2_ptr->matchFlags[3] = 1;	//左	
		task._t1_ptr->matchInfos[1] = { allPtBias,matchValue };
		task._t2_ptr->matchInfos[3] = { {-allPtBias.x,-allPtBias.y},matchValue };

	}
	else if (relativeWorldCoor == Position(0, -1))	// 左侧
	{
		task._t1_ptr->matchFlags[3] = 1;	//左
		task._t2_ptr->matchFlags[1] = 1;	//右
		task._t1_ptr->matchInfos[3] = { allPtBias,matchValue };
		task._t2_ptr->matchInfos[1] = { {-allPtBias.x,-allPtBias.y},matchValue };

	}
	else if (relativeWorldCoor == Position(1, 0))	// 下方
	{
		task._t1_ptr->matchFlags[2] = 1;	//下
		task._t2_ptr->matchFlags[0] = 1;	//上
		task._t1_ptr->matchInfos[2] = { allPtBias,matchValue };
		task._t2_ptr->matchInfos[0] = { {-allPtBias.x,-allPtBias.y},matchValue };

	}
	else if (relativeWorldCoor == Position(-1, 0))	// 上方
	{
		task._t1_ptr->matchFlags[0] = 1;	//上
		task._t2_ptr->matchFlags[2] = 1;	//下
		task._t1_ptr->matchInfos[0] = { allPtBias,matchValue };
		task._t2_ptr->matchInfos[2] = { {-allPtBias.x,-allPtBias.y},matchValue };
	}
	else
	{
		return ERR_WRONG_INPUT;
	}

	//cv::Mat mask(img_in1.size(), CV_8UC1, cv::Scalar::all(255));
	//cv::detail::MultiBandBlender blender1 = cv::detail::MultiBandBlender(false, 5);
	//std::vector<cv::Point>modify_coordinates{ cv::Point(0,0) , allPtBias };
	//std::vector<cv::Size>sizes{ img_in1.size(), img_in1.size() };
	//cv::Rect resultRoi = cv::detail::resultRoi(modify_coordinates, sizes);

	//blender1.prepare(resultRoi);
	//blender1.feed(img_in1, mask, cv::Point(0, 0));
	//blender1.feed(img_in2, mask, allPtBias);
	//cv::Mat res, m;
	//blender1.blend(res, m);


	return INFO_OK;
}

cv::Mat TaskConsumerDefault::extract_subregion(const cv::Mat& t1, int x, int y)
{
	cv::Rect roi1(0, 0, t1.cols, t1.rows);
	cv::Rect roi2(x, y, t1.cols, t1.rows);
	cv::Rect overRoi = roi1 & roi2;
	if (abs(x) >= t1.cols || abs(y) >= t1.rows)
	{
		return cv::Mat();
	}
	return t1(overRoi).clone();
}

void computeCPS(const float* fft, float* cps, const int& width, const int& height)
{
	int block_size = 2;
	for (int i = 0; i < height; i++)
	{
		const float* srcLinePtr = fft + i * width * 2;
		float * resLinePtr = cps + i * width * 2;
		int j = 0;
		for (; j < width - block_size + 1; j += block_size)
		{
			__m128 val = _mm_loadu_ps(srcLinePtr + j * 2);
			__m128 powval = _mm_mul_ps(val, val);
			__m128 shufflePowVal = _mm_shuffle_ps(powval, powval, _MM_SHUFFLE(2, 3, 0, 1));
			__m128 addPow = _mm_add_ps(powval, shufflePowVal);
			__m128 sqrtAdd = _mm_sqrt_ps(addPow);
			__m128 res = _mm_div_ps(val, sqrtAdd);
			_mm_storeu_ps(resLinePtr + j * 2, res);
		}
		for (; j < width; j++)
		{
			float a = srcLinePtr[j * 2 + 0];
			float b = srcLinePtr[j * 2 + 1];
			float p = sqrt(a * a + b * b);
			resLinePtr[j * 2 + 0] = a / p;
			resLinePtr[j * 2 + 1] = b / p;
		}
	}
	return;
}

void computeCPS(const cv::Mat& src1, const cv::Mat& src2, cv::Mat& res)
{
	if (res.empty() || src1.size() != res.size())
	{
		res = cv::Mat(src1.size(), src1.type(), cv::Scalar::all(0));
	}
	int rows = src1.rows;
	int cols = src1.cols;
	int blockSize = 2;
	for (int i = 0; i < rows; i++)
	{
		const float * src1LinePtr = (float*)src1.ptr<cv::Vec2f>(i);
		const float * src2LinePtr = (float*)src2.ptr<cv::Vec2f>(i);
		float * resLinePtr = (float*)res.ptr<cv::Vec2f>(i);
		int j = 0;
		for (;  j < cols - blockSize + 1; j+= blockSize)
		{
			__m128 val1 = _mm_loadu_ps(src1LinePtr + j * 2);
			__m128 val2 = _mm_loadu_ps(src2LinePtr + j * 2);

			__m128 val3 = _mm_mul_ps(_mm_shuffle_ps(val2, val2, _MM_SHUFFLE(2, 3, 0, 1)), _mm_setr_ps(-1, 1, -1, 1));
			__m128 mul1 = _mm_mul_ps(val1, val2);
			__m128 mul2 = _mm_mul_ps(val1, val3);

			__m128 hadd = _mm_hadd_ps(mul1, mul2);
			__m128 shufhadd = _mm_shuffle_ps(hadd, hadd, _MM_SHUFFLE(3, 1, 2, 0));
			shufhadd = _mm_add_ps(shufhadd, _mm_setr_ps(1e-10, 0, 1e-10, 0));
			__m128 powval = _mm_mul_ps(shufhadd, shufhadd);
			__m128 shufflePowVal = _mm_shuffle_ps(powval, powval, _MM_SHUFFLE(2, 3, 0, 1));
			__m128 addPow = _mm_add_ps(powval, shufflePowVal);
			__m128 sqrtAdd = _mm_sqrt_ps(addPow);
			__m128 res = _mm_div_ps(shufhadd, sqrtAdd);

			_mm_storeu_ps(resLinePtr + j * 2, res);
			
		}
		for (; j < cols; j++)
		{
			float a = src1LinePtr[j * 2 + 0];
			float b = src1LinePtr[j * 2 + 1];
			float c = src2LinePtr[j * 2 + 0];
			float d = src2LinePtr[j * 2 + 1];
			float v0 = a * c + b * d;
			float v1 = b * c - a * d;
			float vs = sqrt(v0*v0 + v1 * v1);
			resLinePtr[j * 2 + 0] = v0 / vs;
			resLinePtr[j * 2 + 1] = v1 / vs;
		}
	}
	return;
}

int TaskConsumerDefault::computePCM(cv::Mat& I1, cv::Mat& I2, cv::Mat& pcm_Mat) {

	if (I1.empty() || I2.empty())
	{
		std::cout << "图像为空" << std::endl;
		return -1;
	}
	//傅里叶变换

	dft(I1, Img1_DFT, cv::DFT_COMPLEX_OUTPUT);
	dft(I2, Img2_DFT, cv::DFT_COMPLEX_OUTPUT);
	//cv::Mat FFT1;
	//cout << Img1_DFT.row(0) << endl;
	//Img2_DFT共轭变换后并相乘,
	//mulSpectrums(Img1_DFT, Img2_DFT, FFT1, 0, true);  //对傅里叶变换后的搜索图像和模板图像进行点乘
	//
	////替换零值
	//FFT1.forEach<cv::Vec2f>([](cv::Vec2f& value, const int* position) {
	//	if (value[0] == 0 && value[1] == 0) {
	//		value[0] = std::numeric_limits<float>::epsilon();  //当实部虚部都为0，只需要换实部即可
	//	}
	//});

	////计算模值
	//cv::Mat channels[2];
	//split(FFT1, channels);

	//cv::Mat abs;
	//magnitude(channels[0], channels[1], abs);

	////计算互功率谱
	//cv::Mat CPS_real = channels[0] / abs;
	//cv::Mat CPS_imag = channels[1] / abs;

	//std::vector<cv::Mat> channels2 = { CPS_real ,CPS_imag };
	//merge(channels2, CPS);
	computeCPS(Img1_DFT, Img2_DFT, CPS);

	//	逆傅里叶变换
	dft(CPS, PCM, cv::DFT_INVERSE | cv::DFT_REAL_OUTPUT | cv::DFT_SCALE);

	//先验经验，重叠部分不会在边缘，而PCIAM算法往往在边缘处的峰值高
	//所以进行峰值过滤
	PCM.row(0).setTo(cv::Scalar(0.0));
	PCM.row(PCM.rows - 1).setTo(cv::Scalar(0.0));
	PCM.col(0).setTo(cv::Scalar(0));
	PCM.col(PCM.cols - 1).setTo(cv::Scalar(0.0));
	//PCM.row(1).setTo(cv::Scalar(0.0));
	//PCM.row(PCM.rows - 2).setTo(cv::Scalar(0.0));
	//PCM.col(1).setTo(cv::Scalar(0));
	//PCM.col(PCM.cols - 2).setTo(cv::Scalar(0.0));
	return 1;
}


void TaskConsumerDefault::peaksearch(cv::Mat& PCM, int& num_peaks, std::vector<double>& max_value, std::vector<cv::Point>& max_Loc) {
	for (int i = 0; i < num_peaks; i++) {
		double minValue, maxValue;
		cv::Point  minLoc, maxLoc;
		minMaxLoc(PCM, &minValue, &maxValue, &minLoc, &maxLoc);

		max_value.push_back(maxValue);
		max_Loc.push_back(maxLoc);

		// 将找到的最大值置为一个较小的值，以便继续查找下一个最大值
		PCM.at<float>(maxLoc) = -std::numeric_limits<float>::max();
	
	}
	return;
}

int TaskConsumerDefault::computePCC(const cv::Mat& I1, const cv::Mat& I2, std::string& direction, cv::Point& Loc, std::vector<int>& m, std::vector<int>& n, std::vector<double>& value) {
	int h = I1.rows;
	int w = I1.cols;

	int x = Loc.x;
	int y = Loc.y;

	//8种可能的平移解释
	if (direction == "north") {
		m = { y,y,h - y,h - y,y,y,h - y,h - y };
		n = { x,w - x,x,w - x,-x,x - w,-x,x - w };
		/*m = { y,y,h - y,h - y,y,y,h - y,h - y   ,-y,-y,y - h,y - h };
		n = { x,w - x,x,w - x,-x,x - w,-x,x - w ,x,w - x,x,w - x };*/

	}
	else if (direction == "west") {
		m = { y,y,h - y,h - y,-y,-y,y - h,y - h };
		n = { x,w - x,x,w - x,x,w - x,x,w - x };
	}
	else {
		std::cerr << "direction is wrong,please retry follow the ture direction" << std::endl;
		return ERR_WRONG_INPUT;
	}

	for (int i = 0; i < m.size(); i++) {
		cv::Mat I1_roi = extract_subregion(I1, n[i], m[i]);
		cv::Mat I2_roi = extract_subregion(I2, -n[i], -m[i]);

		//roi大小不一样，roi没有长或者框，直接返回n[i]，m[i],-1
		if (I1_roi.size() != I2_roi.size()) {
			//PCC = initial(n[i], m[i], -1);
			value.push_back(-1);
		}
		else if (I1_roi.rows == 0 || I1_roi.cols == 0 || I2_roi.rows == 0 || I2_roi.cols == 0) {
			//PCC = initial(n[i], m[i], -1);
			value.push_back(-1);
		}
		else {
			//value.push_back(compute_similarityChannel3SSE1(I1_roi, I2_roi));
			float nccValue;
			cv::Point offset(0, 0);
			int nccFlag = calNccValueBaseShift_SSE(I1_roi, I2_roi, offset, nccValue);
			value.push_back(nccValue);
		}
	}

	return INFO_OK;
}


double compute_similarity8UC1(const cv::Mat& src1, const cv::Mat& src2)
{
	cv::Mat a1,a2;
	src1.convertTo(a1, CV_32F, 1 / 255.0f);
	src2.convertTo(a2, CV_32F, 1 / 255.0f);
	double sum_prod = 0.0;
	double sum1 = 0.0;
	double sum2 = 0.0;
	double norm1 = 0.0;
	double norm2 = 0.0;
	// ensure that both images are the same size
	if (a1.rows != a2.rows || a1.cols != a2.cols) {
		return -1.0;
	}
	int sz = a1.total();
	for (int i = 0; i < a1.rows; i++) {
		for (int j = 0; j < a1.cols; j++) {
			float a1_ij = a1.ptr<float>(i)[j];
			float a2_ij = a2.ptr<float>(i)[j];
			sum_prod += a1_ij * a2_ij;
			sum1 += a1_ij;
			sum2 += a2_ij;
			norm1 += a1_ij * a1_ij;
			norm2 += a2_ij * a2_ij;
		}
	}
	double numer = sum_prod - sum1 * sum2 / sz;
	double denom = std::sqrt((norm1 - sum1 * sum1 / sz) * (norm2 - sum2 * sum2 / sz));

	double val = numer / denom;

	if (std::isnan(val) || std::isinf(val)) {
		val = -1.0;
	}
	return val;
}

int TaskConsumerDefault::matchOption_PCIAM(const cv::Mat& preImg, const cv::Mat& curImg, const cv::Point& inputBias, int matchOriten, cv::Point& outputBias, double& matchValue)
{
	if (preImg.empty() || curImg.empty())
	{
		return 0;
	}
	if (preImg.channels() != curImg.channels() && preImg.rows != curImg.rows && preImg.cols != curImg.cols)
	{
		return 0;
	}
	cv::Mat preImgGray, curImgGray, inputPrePro, inputCurPro;
	if (preImg.channels() == 3)
	{
		cv::cvtColor(preImg, preImgGray, cv::COLOR_BGR2GRAY);
		cv::cvtColor(curImg, curImgGray, cv::COLOR_BGR2GRAY);
	}
	else
	{
		preImgGray = preImg;
		curImgGray = curImg;
	}
	preImgGray.convertTo(inputPrePro, CV_32F, 1 / 255.0f); // 转换数据类型
	curImgGray.convertTo(inputCurPro, CV_32F, 1 / 255.0f);
	/*cv::GaussianBlur(inputPrePro, inputPrePro, cv::Size(5, 5), 1.5);
	cv::GaussianBlur(inputCurPro, inputCurPro, cv::Size(5, 5), 1.5);*/

	// 计算峰值相关矩阵
	int pcmFlag = computePCM(inputPrePro, inputCurPro, PCM);

	if (1 != pcmFlag)
	{
		return -1;
	}

	//搜索峰值及其位置
	int numPeaks = 2; //峰值搜索个数
	std::vector<double> max_value;
	std::vector<cv::Point> max_Loc;
	peaksearch(PCM, numPeaks, max_value, max_Loc);
	bool findBestMatch = false;


	float maxValue = -std::numeric_limits<float>::infinity(); // 用于存储最大相关度值
	cv::Point bestMatch(0, 0);


	for (size_t i = 0; i < numPeaks; i++)
	{
		cv::Point shift = max_Loc[i];
		cv::Vec2i vec = shift - cv::Point(preImgGray.cols / 2, preImgGray.rows / 2);

		cv::Vec2f die(vec[0] / (abs(vec[0] + 1e-10)), vec[1] / (abs(vec[1]) + 1e-10));

		cv::Point res(0, 0);
		res.x = (die[0] > 0 ? preImgGray.cols - shift.x : shift.x) * die[0];
		res.y = (die[1] > 0 ? preImgGray.rows - shift.y : shift.y) * die[1];




		if (abs(res.x) <= inputBias.x && abs(res.y) <= inputBias.y)
		{

			cv::Rect roi1(0, 0, preImgGray.cols, preImgGray.rows);
			cv::Rect roi2(res.x, res.y, preImgGray.cols, preImgGray.rows);

			cv::Rect r = roi1 & roi2;

			cv::Mat I1_roi = curImgGray(r).clone();
			cv::Mat I2_roi = preImgGray(r - res).clone();

			double nccValue = 0;
			//cv::Point offsett(0, 0);
			//int nccFlag = calNccValueBaseShift_SSE(I1_roi, I2_roi, offsett, nccValue);
			//double nccVal = 0;
			computeNCC_8UC1(I1_roi, I2_roi, nccValue);

			//double val = compute_similarity8UC1(I1_roi, I2_roi);
			if (nccValue > maxValue)
			{
				maxValue = nccValue;
				bestMatch = res;
				findBestMatch = true;
			}
		}
	}

	//PCC互相关筛选
	//int idx = 0;
	//int x = 0;
	//int y = 0;
	//std::string direction;
	//if (matchOriten)
	//{
	//	direction = "north";
	//}
	//else
	//{
	//	direction = "west";
	//}
	//for (int i = 0; i < numPeaks; i++) {
	//	std::vector<int>m;
	//	std::vector<int>n;
	//	std::vector<double>value;
	//	int ePCCFlag = computePCC(preImgGray, curImgGray, direction, max_Loc[i], m, n, value);
	//	if (!ePCCFlag)
	//	{
	//		return ERR_FUNC_FAILED;
	//	}
	//	for (size_t i = 0; i < m.size(); i++) {
	//		// 计算 (m[i], n[i]) 和 inputBias 之间的距离
	//		if (abs(m[i]) <= inputBias.x && abs(n[i]) <= inputBias.y) {
	//			// 如果是，检查该位置的 value 是否为最大值
	//			if (value[i] > maxValue) {
	//				maxValue = value[i]; // 更新最大相关度值
	//				bestMatch = cv::Point(m[i], n[i]); // 更新最佳匹配坐标
	//				findBestMatch = true;
	//			}
	//		}
	//	}
	//}
	//拼接结果验证
	//cv::Mat sititchImg;
	//stitchTwoImg(preImg, curImg, outputBias, sititchImg);
	//
	if (findBestMatch)
	{
		outputBias = bestMatch;
		matchValue = maxValue;
	}
	else
	{
		outputBias = cv::Point(0, 0);
		matchValue = 0.1;
	}
	return 1;
}



TaskConsumerSIFT::TaskConsumerSIFT()
{

}

TaskConsumerSIFT::~TaskConsumerSIFT()
{

}

int TaskConsumerSIFT::taskConsume(const std::shared_ptr<Task>& task_ptr)
{
	if (!task_ptr)
	{
		throw std::invalid_argument("Consume task_ptr is null");
	}
	Task& task = *task_ptr;
	MatchInfo result;

	cv::Mat img_in1 = task._t1_ptr->getMat();
	cv::Mat img_in2 = task._t2_ptr->getMat();
	Position relativeWorldCoor = task._relativeGridCoor;
	cv::Point relativeOffset = task._relativeGlobalCoor;
	cv::Point PtDeviationBias = task._platformDeviationCoor;
	if (img_in1.empty() || img_in2.empty())
	{
		return ERR_IMG_EMPTY;
	}
	int matchOriten;	// "0"-左右  "1"-上下
	if (relativeWorldCoor == Position(0, 1) || relativeWorldCoor == Position(0, -1)) {
		matchOriten = 0;	// 第二张图在第一张图右侧或左侧
	}
	else
	{
		matchOriten = 1;	// 第二张图在第一张图下方或上方
	}

	// 提取重叠区域ROI
	cv::Mat img_in1_roi = extract_subregion(img_in1, relativeOffset.x, relativeOffset.y);
	if (img_in1_roi.empty())
	{
		return -1;
	}
	cv::Mat img_in2_roi = extract_subregion(img_in2, -relativeOffset.x, -relativeOffset.y);
	if (img_in2_roi.empty())
	{
		return -1;
	}
	//PtDeviationBias = { 50,50 };
	cv::Point outputPtBias;
	double matchValue = -1;

	// 图像匹配
	int matchFlag = matchOption_SIFT(img_in1_roi, img_in2_roi, PtDeviationBias, matchOriten, outputPtBias, matchValue);
	if (!matchFlag)
	{
		return ERR_FUNC_FAILED;
	}

	// 偏移量计算
	cv::Point allPtBias;
	allPtBias = relativeOffset + outputPtBias;

	if (relativeWorldCoor == Position(0, 1))		// 右侧
	{
		task._t1_ptr->matchFlags[1] = 1;	//右
		task._t2_ptr->matchFlags[3] = 1;	//左	
		task._t1_ptr->matchInfos[1] = { allPtBias,matchValue };
		task._t2_ptr->matchInfos[3] = { {-allPtBias.x,-allPtBias.y},matchValue };

	}
	else if (relativeWorldCoor == Position(0, -1))	// 左侧
	{
		task._t1_ptr->matchFlags[3] = 1;	//左
		task._t2_ptr->matchFlags[1] = 1;	//右
		task._t1_ptr->matchInfos[3] = { allPtBias,matchValue };
		task._t2_ptr->matchInfos[1] = { {-allPtBias.x,-allPtBias.y},matchValue };

	}
	else if (relativeWorldCoor == Position(1, 0))	// 下方
	{
		task._t1_ptr->matchFlags[2] = 1;	//下
		task._t2_ptr->matchFlags[0] = 1;	//上
		task._t1_ptr->matchInfos[2] = { allPtBias,matchValue };
		task._t2_ptr->matchInfos[0] = { {-allPtBias.x,-allPtBias.y},matchValue };

	}
	else if (relativeWorldCoor == Position(-1, 0))	// 上方
	{
		task._t1_ptr->matchFlags[0] = 1;	//上
		task._t2_ptr->matchFlags[2] = 1;	//下
		task._t1_ptr->matchInfos[0] = { allPtBias,matchValue };
		task._t2_ptr->matchInfos[2] = { {-allPtBias.x,-allPtBias.y},matchValue };
	}
	else
	{
		return ERR_WRONG_INPUT;
	}

	cv::Mat mask(img_in1.size(), CV_8UC1, cv::Scalar::all(255));
	cv::detail::MultiBandBlender blender1 = cv::detail::MultiBandBlender(false, 5);
	std::vector<cv::Point>modify_coordinates{ cv::Point(0,0) , allPtBias };
	std::vector<cv::Size>sizes{ img_in1.size(), img_in1.size() };
	cv::Rect resultRoi = cv::detail::resultRoi(modify_coordinates, sizes);

	blender1.prepare(resultRoi);
	blender1.feed(img_in1, mask, cv::Point(0, 0));
	blender1.feed(img_in2, mask, allPtBias);
	cv::Mat res, m;
	blender1.blend(res, m);

	return INFO_OK;
}

int TaskConsumerSIFT::matchOption_SIFT(const cv::Mat& img_in1, const cv::Mat& img_in2, const cv::Point& inputPtBias, int matchOriten, cv::Point& outputPtBias, double& matchValue)
{
	//sift特征匹配
	//sift特征匹配-特征点提取
	bool flag0 = extractSiftFeature_CUDA(img_in1, featureData1, 2.0);
	bool flag1 = extractSiftFeature_CUDA(img_in2, featureData2, 2.0);
	//sift特征匹配-特征匹配参数输入
	matchParam.matchOriten = matchOriten;//0左右匹配, 1上下匹配
	std::vector<cv::Point2f> matchPoints;
	//matchParam.shiftLimitXY = inputPtBias;
	matchParam.shiftLimitXY = cv::Point{ 0,0 };
	//sift特征匹配-特征点匹配
	std::vector<cv::Point2f> good_offsets;
	int flat2 = siftFeatureMatch_CUDA(featureData1, featureData2, matchParam, matchPoints);
	freeSiftData_CUDA(featureData1);
	freeSiftData_CUDA(featureData2);
	good_offsets = PointsFilter_ClusteringV2(matchPoints, 3 /*1*/);
	if (good_offsets.empty())
	{
		outputPtBias = cv::Point(0, 0);
		matchValue = 0.1;
		return 1;
	}
	else
	{
		float dx = 0, dy = 0;
		for (int i = 0; i < good_offsets.size(); i++)
			dx += good_offsets[i].x, dy += good_offsets[i].y;
		cv::Point meanOffset = cv::Point(round(dx / good_offsets.size()), round(dy / good_offsets.size()));
		if (abs(meanOffset.x) <= inputPtBias.x && abs(meanOffset.y) <= inputPtBias.y)
		{
			outputPtBias = meanOffset;
			float nccValue;
			int nccFlag = calNccValueBaseShift_SSE(img_in1, img_in2, outputPtBias, nccValue);
			matchValue = nccValue;
		}
		else
		{
			outputPtBias = cv::Point(0, 0);
			matchValue = 0.1;
		}

		return 1;
	}
}

