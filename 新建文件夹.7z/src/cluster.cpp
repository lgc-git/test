#include "cluster.h"
#include <opencv2/opencv.hpp>
using namespace std;
using namespace cv;

float stringToFloat(string i) {
	stringstream sf;
	float score = 0;
	sf << i;
	sf >> score;
	return score;
}

float EuclideanDistance(point a, point b)
{
	return sqrt((a.x - b.x)*(a.x - b.x) + (a.y - b.y)*(a.y - b.y));
}

float ManhattenDistance(point a, point b)
{
	return max(abs(a.x - b.x), abs(a.y - b.y));
}

void HierarchicalClustering(vector<point>& dataset, int dis_thresh)
{
	//Similarity table��distance table 
	vector<vector<float> > dTable;
	for (int i = 0; i < dataset.size(); i++) {
		vector<float> temp;
		for (int j = 0; j < dataset.size(); j++) {
			if (j > i)
				temp.push_back(EuclideanDistance(dataset[i], dataset[j]));
			else if (j < i)
				temp.push_back(dTable[j][i]);
			else
				temp.push_back(0);
		}
		dTable.push_back(temp);
	}
	int len = dataset.size();
	while (dataset.size() > 2) {
		//Merge two closest clusters
		float minDt = INT_MAX;
		int mi, mj;
		for (int i = 0; i < dTable.size(); i++) {
			for (int j = i + 1; j < dTable[i].size(); j++) {
				if (dTable[i][j] < minDt) {
					minDt = dTable[i][j];
					mi = i;
					mj = j;
				}
			}
		}
		if (minDt > dis_thresh)
			break;
		for (int i = 0; i < dataset[mj].nds.size(); i++) {
			dataset[mi].nds.push_back(dataset[mj].nds[i]);
		}
		//rm
		vector<point>::iterator imj = dataset.begin();
		imj += mj;
		dataset.erase(imj);

		//Update the dTable
		for (int j = 0; j < dTable.size(); j++) {
			if (j == mi || j == mj) continue;
			if (dTable[mi][j] > dTable[mj][j]) {
				dTable[mi][j] = dTable[mj][j];
				dTable[j][mi] = dTable[mi][j];
			}
		}
		//rm
		vector<vector<float> >::iterator ii = dTable.begin();
		ii += mj;
		dTable.erase(ii);
		for (int i = 0; i < dTable.size(); i++) {
			vector<float>::iterator ij = dTable[i].begin();
			ij += mj;
			dTable[i].erase(ij);
		}
	}
}


bool FourFieldsDistance(point a, point b,
	vector<int> imgStatus_left, vector<int> imgStatus_right,
	vector<int> imgStatus_top, vector<int> imgStatus_down, int col)
{
	int aIndex = a.y * col + a.x, bIndex = b.y * col + b.x;
	if (a.y == b.y)
	{
		if (a.x - 1 == b.x && imgStatus_left[aIndex] == 3 && imgStatus_right[bIndex] == 3)
			return true;
		if (a.x + 1 == b.x && imgStatus_right[aIndex] == 3 && imgStatus_left[bIndex] == 3)
			return true;
	}
	if (a.x == b.x)
	{
		if (a.y - 1 == b.y && imgStatus_top[aIndex] == 3 && imgStatus_down[bIndex] == 3)
			return true;
		if (a.y + 1 == b.y && imgStatus_down[aIndex] == 3 && imgStatus_top[bIndex] == 3)
			return true;
	}
	return false;
}

void HierarchicalClustering_match(vector<point>& dataset,
	vector<int> imgStatus_left, vector<int> imgStatus_right,
	vector<int> imgStatus_top, vector<int> imgStatus_down, int col)
{
	//Similarity table��distance table 
	vector<vector<bool> > dTable;
	for (int i = 0; i < dataset.size(); i++) {
		vector<bool> temp;
		for (int j = 0; j < dataset.size(); j++) {
			if (j > i)
				temp.push_back(FourFieldsDistance(dataset[i], dataset[j],
					imgStatus_left, imgStatus_right, imgStatus_top, imgStatus_down, col));
			else if (j < i)
				temp.push_back(dTable[j][i]);
			else
				temp.push_back(true);
		}
		dTable.push_back(temp);
	}

	int len = dataset.size();
	//
	while (dataset.size() > 1) {
		//Merge two closest clusters
		bool is_match = false;
		int mi, mj;
		for (int i = 0; i < dTable.size(); i++) {
			for (int j = i + 1; j < dTable[i].size(); j++) {
				if (dTable[i][j]) {
					is_match = true;
					mi = i;
					mj = j;
					break;
				}
			}
			if (is_match)
				break;
		}
		if (!is_match)
			break;
		//if (minDt > dis_thresh)
		//	break;
		for (int i = 0; i < dataset[mj].nds.size(); i++) {
			dataset[mi].nds.push_back(dataset[mj].nds[i]);
		}
		//rm
		vector<point>::iterator imj = dataset.begin();
		imj += mj;
		dataset.erase(imj);

		//Update the dTable
		for (int j = 0; j < dTable.size(); j++) {
			if (j == mi || j == mj) continue;
			if (dTable[mj][j]) {
				dTable[mi][j] = dTable[mj][j];
			}
		}
		//rm
		vector<vector<bool> >::iterator ii = dTable.begin();
		ii += mj;
		dTable.erase(ii);
		for (int i = 0; i < dTable.size(); i++) {
			vector<bool>::iterator ij = dTable[i].begin();
			ij += mj;
			dTable[i].erase(ij);
		}
	}
}

void HierarchicalClustering_match_new(vector<point>& dataset,
	vector<int> imgStatus_left, vector<int> imgStatus_right,
	vector<int> imgStatus_top, vector<int> imgStatus_down, int row, int col)
{
	//Similarity table��distance table 
	vector<vector<bool>> dTable(dataset.size(), vector<bool>(dataset.size(), false));
	for (int i = 0; i < dataset.size(); i++) {
		int y = i / col, x = i - y * col;
		if (y > 0 && imgStatus_top[i] == 3 && imgStatus_down[i - col] == 3)
			dTable[i][i - col] = true;
		if (x < col - 1 && imgStatus_right[i] == 3 && imgStatus_left[i + 1] == 3)
			dTable[i][i + 1] = true;
		if (y < row - 1 && imgStatus_down[i] == 3 && imgStatus_top[i + col] == 3)
			dTable[i][i + col] = true;
		if (x > 0 && imgStatus_left[i] == 3 && imgStatus_right[i - 1] == 3)
			dTable[i][i - 1] = true;
		dTable[i][i] = true;
	}

	int len = dataset.size();
	//cout << dTable.size() << endl;
	while (dataset.size() > 1) {
		//Merge two closest clusters
		bool is_match = false;
		int mi, mj;
		for (int i = 0; i < dTable.size(); i++) {
			for (int j = i + 1; j < dTable[i].size(); j++) {
				if (dTable[i][j]) {
					is_match = true;
					mi = i;
					mj = j;
					break;
				}
			}
			if (is_match)
				break;
		}
		if (!is_match)
			break;
		//if (minDt > dis_thresh)
		//	break;
		for (int i = 0; i < dataset[mj].nds.size(); i++) {
			dataset[mi].nds.push_back(dataset[mj].nds[i]);
		}
		//rm
		vector<point>::iterator imj = dataset.begin();
		imj += mj;
		dataset.erase(imj);

		//Update the dTable
		for (int j = 0; j < dTable.size(); j++) {
			if (j == mi || j == mj) continue;
			if (dTable[mj][j]) {
				dTable[mi][j] = dTable[mj][j];
			}
		}
		//rm
		vector<vector<bool> >::iterator ii = dTable.begin();
		ii += mj;
		dTable.erase(ii);
		for (int i = 0; i < dTable.size(); i++) {
			vector<bool>::iterator ij = dTable[i].begin();
			ij += mj;
			dTable[i].erase(ij);
		}
	}
}

void HierarchicalClustering_match_fast(vector<point>& dataset,
	vector<int> imgStatus_left, vector<int> imgStatus_right,
	vector<int> imgStatus_top, vector<int> imgStatus_down, int row, int col)
{
	//Similarity table��distance table 
	vector<vector<bool>> dTable(dataset.size(), vector<bool>(dataset.size(), false));
	for (int i = 0; i < dataset.size(); i++) {
		int y = i / col, x = i - y * col;
		if (y > 0 && imgStatus_top[i] == 3 && imgStatus_down[i - col] == 3)
			dTable[i][i - col] = true;
		if (x < col - 1 && imgStatus_right[i] == 3 && imgStatus_left[i + 1] == 3)
			dTable[i][i + 1] = true;
		if (y < row - 1 && imgStatus_down[i] == 3 && imgStatus_top[i + col] == 3)
			dTable[i][i + col] = true;
		if (x > 0 && imgStatus_left[i] == 3 && imgStatus_right[i - 1] == 3)
			dTable[i][i - 1] = true;
		dTable[i][i] = true;
	}

	vector<bool> data_flag(dataset.size(), false);
	int len = dataset.size();

	while (dataset.size() > 1) {
		//Merge two closest clusters
		bool is_match = false;
		int mi, mj;
		for (int i = 0; i < dTable.size(); i++) {
			if (data_flag[i])
				continue;
			for (int j = i + 1; j < dTable[i].size(); j++) {
				if (dTable[i][j] && !data_flag[j]) {
					is_match = true;
					mi = i;
					mj = j;
					break;
				}
			}
			if (is_match)
				break;
		}
		if (!is_match)
			break;

		for (int i = 0; i < dataset[mj].nds.size(); i++) {
			dataset[mi].nds.push_back(dataset[mj].nds[i]);
		}

		//Update the dTable
		for (int j = 0; j < dTable.size(); j++) {
			if (j == mi || j == mj) continue;
			if (dTable[mj][j]) {
				dTable[mi][j] = dTable[mj][j];
			}
		}
		//rm
		data_flag[mj] = true;
	}

	vector<point> dataset_out;
	for (int i = 0; i < dataset.size(); i++)
	{
		if (!data_flag[i] || dataset[i].nds.size() > 1)
		{
			dataset_out.push_back(dataset[i]);
		}
	}

	dataset.clear();
	dataset = dataset_out;
}

bool p_comp(point& a, point& b)
{
	return a.nds.size() > b.nds.size();
}

int HierarchicalClustering_match_faster(std::vector<point>& dataset,
	std::vector<int> imgStatus_left, std::vector<int> imgStatus_right,
	std::vector<int> imgStatus_top, std::vector<int> imgStatus_down, int row, int col)
{
	if (row <= 0 || col <= 0)
		return -1;
	if (row * col != dataset.size())
		return -2;
	//if (dataset.size() != imgStatus_left.size() || dataset.size() != imgStatus_right.size() || dataset.size() != imgStatus_top.size()
	//	|| dataset.size() != imgStatus_down.size())
	//	return -3;

	vector<point> datasetCopy;
	Mat labelImg = Mat::zeros(Size(col, row), CV_32SC1);
	vector<node> dataPoint;
	dataPoint.resize(dataset.size());
	for (int i = 0; i < dataset.size(); i++)
	{
		if (dataset[i].y >= row || dataset[i].y < 0)
			return -4;
		if (dataset[i].x >= col || dataset[i].x < 0)
			return -4;
		if (imgStatus_left[i] == 3 || imgStatus_right[i] == 3 || imgStatus_top[i] == 3 || imgStatus_down[i] == 3)
		{

			int *data = labelImg.ptr<int>(int(dataset[i].y));
			data[int(dataset[i].x)] = 1;
			dataPoint[i].x = dataset[i].x;
			dataPoint[i].y = dataset[i].y;
		}
		else
		{
			dataPoint[i].x = dataset[i].x;
			dataPoint[i].y = dataset[i].y;
			datasetCopy.push_back(dataset[i]);
		}
	}
	int labelValue = 1;
	for (int i = 0; i < dataset.size(); i++)
	{
		node areaPoint;
		int *data1 = labelImg.ptr<int>(int(dataset[i].y));
		if (data1[int(dataset[i].x)] == 1)
		{
			point dataCopy;
			std::stack<node> neighborPixels;
			++labelValue;
			neighborPixels.push(dataPoint[i]);
			dataCopy.x = dataPoint[i].x;
			dataCopy.y = dataPoint[i].y;
			while (!neighborPixels.empty())
			{
				vector<node>::iterator iter;
				node curPixel = neighborPixels.top();
				int curX = curPixel.x;
				int curY = curPixel.y;
				int *data = labelImg.ptr<int>(curY);
				if (data[curX] == labelValue)
				{
					neighborPixels.pop();
					continue;
				}
				dataCopy.nds.push_back(curPixel);
				data[curX] = labelValue;

				iter = find(dataPoint.begin(), dataPoint.end(), curPixel);
				int location = iter - dataPoint.begin();
				int curStatusLeft = imgStatus_left[location];
				int curStatusRight = imgStatus_right[location];
				int curStatusDown = imgStatus_down[location];
				int curStatusTop = imgStatus_top[location];

				neighborPixels.pop();

				if (curStatusTop == 3)
				{
					areaPoint.x = curX;
					areaPoint.y = curY - 1;
					if (areaPoint.y >= row || areaPoint.y < 0)
						return -4;
					if (areaPoint.x >= col)
						return -4;
					int *data2 = labelImg.ptr<int>(int(areaPoint.y));
					if (data2[int(areaPoint.x)] == 1)
						neighborPixels.push(areaPoint);
				}
				if (curStatusRight == 3)
				{
					areaPoint.x = curX + 1;
					areaPoint.y = curY;
					if (areaPoint.y >= row)
						return -4;
					if (areaPoint.x >= col)
						return -4;
					int *data2 = labelImg.ptr<int>(int(areaPoint.y));
					if (data2[int(areaPoint.x)] == 1)
						neighborPixels.push(areaPoint);
				}
				if (curStatusDown == 3)
				{
					areaPoint.x = curX;
					areaPoint.y = curY + 1;
					if (areaPoint.y >= row)
						return -4;
					if (areaPoint.x >= col)
						return -4;
					int *data2 = labelImg.ptr<int>(int(areaPoint.y));
					if (data2[int(areaPoint.x)] == 1)
						neighborPixels.push(areaPoint);
				}
				if (curStatusLeft == 3)
				{
					areaPoint.x = curX - 1;
					areaPoint.y = curY;
					if (areaPoint.y >= row)
						return -4;
					if (areaPoint.x >= col || areaPoint.x < 0)
						return -4;
					int *data2 = labelImg.ptr<int>(int(areaPoint.y));
					if (data2[int(areaPoint.x)] == 1)
						neighborPixels.push(areaPoint);
				}
			}
			datasetCopy.push_back(dataCopy);
		}
	}
	sort(datasetCopy.begin(), datasetCopy.end(), p_comp);

	dataset = datasetCopy;

	return 1;
}

std::vector<cv::Point2f> PointsFilter_ClusteringV2(
	std::vector<cv::Point2f> inputs, int dis_thresh, float good_rate)

{
	if (inputs.size() < 2)
		return std::vector<cv::Point2f>();
	vector<point> dataset(inputs.size());
	for (int i = 0; i < inputs.size(); i++)
		dataset[i] = point(inputs[i].x, inputs[i].y);
	HierarchicalClustering(dataset, dis_thresh);
	int maxTypeNum = 0, maxTypeIndex = 0;
	for (int i = 0; i < dataset.size(); i++)
	{
		if (maxTypeNum < dataset[i].nds.size())
		{
			maxTypeNum = dataset[i].nds.size();
			maxTypeIndex = i;
		}
	}
	if (maxTypeNum < inputs.size() * good_rate && maxTypeNum < 5)
		return std::vector<cv::Point2f>();

	vector<Point2f> outputs(maxTypeNum);
	for (int i = 0; i < maxTypeNum; i++)
		outputs[i] = Point2f(dataset[maxTypeIndex].nds[i].x, dataset[maxTypeIndex].nds[i].y);

	return outputs;
}
