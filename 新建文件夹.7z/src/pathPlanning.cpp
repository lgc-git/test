﻿#pragma once
#include <map>
#include <memory>
#include <unordered_set>
#include "opencv2/opencv.hpp"
#include"pathPlanning.h"
#include"miniSpanTree.h"
#include"stitchApp.h"
//#include "errorInfo.h"

#define _COUT_ (1)

PathPlanningDefault::PathPlanningDefault()
{

}

PathPlanningDefault::~PathPlanningDefault()
{

}

PathPlanningKruskal::dsu::dsu(const std::vector<Position>& nodes)
{
	for (size_t i = 0; i < nodes.size(); i++)
	{
		pa.insert({ nodes[i], nodes[i] });
	}
}
Position PathPlanningKruskal::dsu::find(Position& key)
{
	return pa[key] == key ? key : pa[key] = find(pa[key]);
}

void PathPlanningKruskal::dsu::unite(Position& x, Position& y)
{
	 pa[find(x)] = find(y); 
	 return;
}


int PathPlanningKruskal::pathPlanning(std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, const SPathInfo& pathIn)
{
	if (tileMap.size() < 2)
	{
		return 1;
	}
	std::vector<Position> nodes;
	std::vector<sEdge> edges;
	std::vector<sEdge> res_edges;
	//BFS遍历，生成所有节点以及所有边
	std::queue<Position> que;
	//std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>::iterator it;
	std::unordered_set<Position, Position::Hash> visited;


	que.push(tileMap.begin()->first);

	while (!que.empty())
	{
		Position key = que.front();
		auto p = visited.insert(key);
		que.pop();
		if (!p.second)
		{
			continue;
		}

		nodes.emplace_back(key);
		Position searchKey;
		//上
		searchKey = key + Position(-1, 0);
		auto it = tileMap.find(searchKey);
		if (it != tileMap.end() && visited.find(it->first) == visited.end())
		{
			que.push(it->first);
			edges.emplace_back(sEdge{ key, it->first, it->second->matchInfos[2].precison });
		}
		//右
		searchKey = key + Position(0, 1);
		it = tileMap.find(searchKey);
		if (it != tileMap.end() && visited.find(it->first) == visited.end())
		{
			que.push(it->first);
			edges.emplace_back(sEdge{ key, it->first, it->second->matchInfos[3].precison });
		}
		//下
		searchKey = key + Position(1, 0);
		it = tileMap.find(searchKey);
		if (it != tileMap.end() && visited.find(it->first) == visited.end())
		{
			que.push(it->first);
			edges.emplace_back(sEdge{ key, it->first, it->second->matchInfos[0].precison });
		}
		//左
		searchKey = key + Position(0, -1);
		it = tileMap.find(searchKey);
		if (it != tileMap.end() && visited.find(it->first) == visited.end())
		{
			que.push(it->first);
			edges.emplace_back(sEdge{ key, it->first, it->second->matchInfos[1].precison });
		}
	}
	//加边法最小生成树
	std::sort(edges.begin(), edges.end(), sEdge::cmp);  // 1. 按权重排序
	dsu dsuobj(nodes);
	std::unordered_map<cv::Point, int, cvPointHash> edgeCount;

	int maxEdgesPerNode = 2;

	int tot = 0;  // 已选的边数
	float sum_weight = 0;
	for (int i = 0; i <= edges.size(); i++) 
	{
		Position xr = dsuobj.find(edges[i].start);
		Position yr = dsuobj.find(edges[i].end);
		if (xr != yr)
		{  
			dsuobj.unite(xr, yr);  // 合并
			tot++;          // 边数增加
			res_edges.emplace_back(edges[i]);
			sum_weight += edges[i].val;
		}
		if (tot == nodes.size() - 1) //边数等于node num - 1时跳出
		{
			break;
		}
	}
	LOG_INFO("default", "sum_weight:" + std::to_string(sum_weight));
	//遍历所有边，计算每个点的世界坐标
	visited.clear();
	que.push(tileMap.begin()->first);
	while (!que.empty()) 
	{
		Position key = que.front();
		visited.insert(key);
		que.pop();
		for (size_t i = 0; i < res_edges.size(); i++)
		{
			Position son_key;
			if (res_edges[i].start == key)
			{
				son_key = res_edges[i].end;
			}
			else if (res_edges[i].end == key)
			{
				son_key = res_edges[i].start;
			}
			else
			{
				continue;
			}
			
			if (visited.find(son_key) != visited.end())
			{
				continue;
			}
			que.push(son_key);
			std::shared_ptr<Tile>& parent = tileMap.find(key)->second;
			std::shared_ptr<Tile>& son = tileMap.find(son_key)->second;
			Position rela = son_key - key;
			if (rela == Position(-1, 0)) //上
			{
				son->_global_coor = parent->_global_coor + parent->matchInfos[0].offset;
			}
			else if (rela == Position(0, 1)) //右
			{
				son->_global_coor = parent->_global_coor + parent->matchInfos[1].offset;
			}
			else if (rela == Position(1, 0)) //下
			{
				son->_global_coor = parent->_global_coor + parent->matchInfos[2].offset;
			}
			else if (rela == Position(0, -1)) //左
			{
				son->_global_coor = parent->_global_coor + parent->matchInfos[3].offset;
			}
		}
	}
	float minxxx = 1e10;
	float minyyy = minxxx;
	float maxxxx = -minxxx;
	float maxyyy = -minxxx;
	for (auto itit = tileMap.begin(); itit != tileMap.end(); ++itit)
	{
		cv::Point p = itit->second->_global_coor;
		if (p.x < minxxx)
		{
			minxxx = p.x;
		}
		if (p.y < minyyy)
		{
			minyyy = p.y;
		}
		if (p.x > maxxxx)
		{
			maxxxx = p.x;
		}
		if (p.y > maxyyy)
		{
			maxyyy = p.y;
		}

	}

	for (auto itit = tileMap.begin(); itit != tileMap.end(); ++itit)
	{
		itit->second->_global_coor.x -= minxxx;
		itit->second->_global_coor.y -= minyyy;
	}
	if (pathIn.regularPathStr != "")
	{
		cv::Mat t = tileMap.begin()->second->getMat();
		int imgWidth = t.cols;
		int imgHeight = t.rows;

		int resWidth = imgWidth * 2 + maxxxx - minxxx;
		int resHeight = imgHeight * 2 + maxyyy - minyyy;

		float ratio = 5000.0f / max(resWidth, resHeight);
		resHeight = resHeight * ratio;
		resWidth = resWidth * ratio;
		cv::Size tileSize(imgWidth * ratio, imgHeight * ratio);
		cv::Point offset(tileSize .width/ 2, tileSize .height/ 2);
		cv::Rect roi(0, 0, tileSize.width, tileSize.height);
		cv::Mat drawMat(resHeight, resWidth, CV_8UC1, cv::Scalar::all(0));
		cv::Mat drawMat2(resHeight, resWidth, CV_8UC3, cv::Scalar::all(0));

		for (auto k : tileMap) 
		{
			auto tile = k.second;

			cv::Mat tt = tile->getMat();
			cv::Point coor = tile->_global_coor * ratio;

			cv::Mat ttt;
			cv::resize(tt, ttt, tileSize);
			ttt.copyTo(drawMat2(roi + coor));
		}
		for (size_t i = 0; i < edges.size(); i++)
		{
			cv::Point start = tileMap[edges[i].start]->_global_coor * ratio + offset;
			cv::Point end = tileMap[edges[i].end]->_global_coor * ratio + offset;
			cv::line(drawMat2, start, end, cv::Scalar(255, 0, 0), 2, cv::LINE_AA, 0);

			Position rela =  edges[i].end - edges[i].start;
			float precison = 0;
			if (rela == Position(-1, 0)) //上
			{
				precison = tileMap[edges[i].start]->matchInfos[0].precison;
			}
			else if (rela == Position(0, 1)) //右
			{
				precison = tileMap[edges[i].start]->matchInfos[1].precison;
			}
			else if (rela == Position(1, 0)) //下
			{
				precison = tileMap[edges[i].start]->matchInfos[2].precison;
			}
			else if (rela == Position(0, -1)) //左
			{
				precison = tileMap[edges[i].start]->matchInfos[3].precison;
			}

			std::ostringstream stream;
			stream << std::fixed << std::setprecision(4) << precison;
			std::string text = stream.str();
			cv::Point position = (start + end) / 2 + cv::Point(10, -10);
			cv::putText(drawMat2, text, position, cv::FONT_HERSHEY_SIMPLEX, 2, cv::Scalar(255,0,0), 3);
		}
		for (size_t i = 0; i < res_edges.size(); i++)
		{
			cv::Point start = tileMap[res_edges[i].start]->_global_coor * ratio + offset;
			cv::Point end = tileMap[res_edges[i].end]->_global_coor * ratio + offset;
			cv::line(drawMat2, start, end, cv::Scalar(0, 0, 255), 5, cv::LINE_AA, 0);
			Position rela = res_edges[i].end - res_edges[i].start;
			float precison = 0;
			cv::Point offset;
			if (rela == Position(-1, 0)) //上
			{
				precison = tileMap[res_edges[i].start]->matchInfos[0].precison;
				offset = tileMap[res_edges[i].start]->matchInfos[0].offset;
			}
			else if (rela == Position(0, 1)) //右
			{
				precison = tileMap[res_edges[i].start]->matchInfos[1].precison;
				offset = tileMap[res_edges[i].start]->matchInfos[1].offset;
			}
			else if (rela == Position(1, 0)) //下
			{
				precison = tileMap[res_edges[i].start]->matchInfos[2].precison;
				offset = tileMap[res_edges[i].start]->matchInfos[2].offset;
			}
			else if (rela == Position(0, -1)) //左
			{
				precison = tileMap[res_edges[i].start]->matchInfos[3].precison;
				offset = tileMap[res_edges[i].start]->matchInfos[3].offset;
			}

			std::ostringstream stream;
			stream << std::fixed << std::setprecision(4) << precison ;
			std::string text = stream.str();
			cv::Point position = (start + end) / 2 + cv::Point(10, -10);
			cv::putText(drawMat2, text, position, cv::FONT_HERSHEY_SIMPLEX, 2, cv::Scalar(0, 0, 255), 3);
			std::string offset_str = "(" + std::to_string(offset.x) + "," + std::to_string(offset.y) + ")";
			cv::putText(drawMat2, offset_str, position - cv::Point(0, 80), cv::FONT_HERSHEY_SIMPLEX, 2, cv::Scalar(0, 0, 255), 3);
		}
		for (size_t i = 0; i < edges.size(); i++)
		{
			cv::Point start = tileMap[edges[i].start]->_global_coor * ratio + offset;
			cv::Point end = tileMap[edges[i].end]->_global_coor * ratio + offset;
			cv::circle(drawMat2, start, 15, cv::Scalar(0, 255, 0), -1);
			cv::circle(drawMat2, end, 15, cv::Scalar(0, 255, 0), -1);
		}
		cv::imwrite(pathIn.regularPathStr +"./path.png", drawMat2);
	}
	return 1;
}



// 自定义比较函数
bool PathPlanningNearest::comparePoints(const Position& a, const Position& b)
{
	if (a._col != b._col) return a._col < b._col;
	return a._row < b._row;
}

int PathPlanningNearest::pathPlanning(std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, const SPathInfo& pathIn)
{
	


	// 将 unordered_map 的内容复制到 vector 并排序
	std::vector<std::pair<Position, std::shared_ptr<Tile>>> tileMapVector(tileMap.begin(), tileMap.end());

	// 对 vector 进行排序
	std::sort(tileMapVector.begin(), tileMapVector.end(), [this](const auto& a, const auto& b) {return this->comparePoints(a.first, b.first); });

	for (int i = 0; i < tileMapVector.size(); i++)
	{
		//上边  左边 均没有相邻块
		if ((-1 == tileMapVector[i].second->matchFlags[0]) && (-1 == tileMapVector[i].second->matchFlags[3]))
		{
			//不处理
		}//上边没有相邻块，左边有相邻块
		else if ((-1 == tileMapVector[i].second->matchFlags[0]) && (1 == tileMapVector[i].second->matchFlags[3]))
		{
			Position key = tileMapVector[i].first;
			Position leftKey = key + Position(0, -1);
			auto cur_it = tileMap.find(key);
			auto left_it = tileMap.find(leftKey);
			cur_it->second->_global_coor.x = left_it->second->_global_coor.x + left_it->second->matchInfos[1].offset.x;
			cur_it->second->_global_coor.y = left_it->second->_global_coor.y + left_it->second->matchInfos[1].offset.y;
			int i = 0;
		}//上边有相邻块，左边有相邻块
		else if ((1 == tileMapVector[i].second->matchFlags[0]) && (1 == tileMapVector[i].second->matchFlags[3]))
		{
			cv::Point _global_coor;

			cv::Point _global_coor_baseLeft;
			Position key = tileMapVector[i].first;
			Position leftKey = key + Position(0, -1);
			auto cur_it = tileMap.find(key);
			auto left_it = tileMap.find(leftKey);
			_global_coor_baseLeft.x = left_it->second->_global_coor.x + left_it->second->matchInfos[1].offset.x;
			_global_coor_baseLeft.y = left_it->second->_global_coor.y + left_it->second->matchInfos[1].offset.y;

			cv::Point _global_coor_baseUp;
			Position upKey = key + Position(-1, 0);
			auto up_it = tileMap.find(upKey);
			_global_coor_baseUp.x = up_it->second->_global_coor.x + up_it->second->matchInfos[2].offset.x;
			_global_coor_baseUp.y = up_it->second->_global_coor.y + up_it->second->matchInfos[2].offset.y;

			cur_it->second->_global_coor.x = (_global_coor_baseLeft.x * left_it->second->matchInfos[1].precison + _global_coor_baseUp.x * up_it->second->matchInfos[2].precison) / (left_it->second->matchInfos[1].precison + up_it->second->matchInfos[2].precison);
			cur_it->second->_global_coor.y = (_global_coor_baseLeft.y * left_it->second->matchInfos[1].precison + _global_coor_baseUp.y * up_it->second->matchInfos[2].precison) / (left_it->second->matchInfos[1].precison + up_it->second->matchInfos[2].precison);
		}
		//上边有相邻块，左边没有相邻块
		else if ((1 == tileMapVector[i].second->matchFlags[0]) && (-1 == tileMapVector[i].second->matchFlags[3]))
		{
			Position key = tileMapVector[i].first;
			Position upKey = key + Position(-1, 0);
			auto cur_it = tileMap.find(key);
			auto up_it = tileMap.find(upKey);
			cur_it->second->_global_coor.x = up_it->second->_global_coor.x + up_it->second->matchInfos[2].offset.x;
			cur_it->second->_global_coor.y = up_it->second->_global_coor.y + up_it->second->matchInfos[2].offset.y;
		}
	};


	return 1;
}


