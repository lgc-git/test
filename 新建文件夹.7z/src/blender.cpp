﻿#pragma once
#include<algorithm>
#include<opencv2/opencv.hpp>
#include<vector>
#include<future>
#include<alg_base_common.h>
#include"blender.h"
#include"matchResultDemo.h"

using namespace cv;
using namespace std;

//图像拼接缝融合
typedef struct SBlockFusionParams
{
	int iSplitNum;//
	int iBlockNum;
	int iColBlocks;
	int iIndexNum;
	int iType;
};

//将拼接图像(所有输入图像)的全局坐标转换为组成图像间的全局坐标
int globalCoordinateConvertLocalCoordinate(std::vector<cv::Point>& coordinates, cv::Rect& baseRect, int& maxX, int& maxY, int& minX, int & minY)
{
	int min_x = 999999, min_y = 999999;
	int max_x = 0, max_y = 0;
	for (int i = 0; i < coordinates.size(); i++)
	{
		if (min_x > coordinates[i].x)
			min_x = coordinates[i].x;
		if (min_y > coordinates[i].y)
			min_y = coordinates[i].y;
		if (max_x < coordinates[i].x)
			max_x = coordinates[i].x;
		if (max_y < coordinates[i].y)
			max_y = coordinates[i].y;
	}
	//
	if (min_x > baseRect.x)
		min_x = baseRect.x;
	if (min_y > baseRect.y)
		min_y = baseRect.y;
	if (max_x < baseRect.x)
		max_x = baseRect.x;
	if (max_y < baseRect.y)
		max_y = baseRect.y;
	//
	max_x -= min_x, max_y -= min_y;
	for (int i = 0; i < coordinates.size(); i++)
	{
		coordinates[i].x -= min_x;
		coordinates[i].y -= min_y;
	}
	baseRect.x = baseRect.x - min_x;
	baseRect.y = baseRect.y - min_y;
	maxX = max_x;
	maxY = max_y;
	minX = min_x;
	minY = min_y;
	return 1;
}

//对多张图像组成的矩形区域进行拼接缝融合及裁剪
void imgsOverlapWithBlockFusion(cv::Rect& blockRect, cv::Mat& fusionBlockMat, const cv::Mat& weightMap, const std::vector<cv::Mat>& overlapRectImgs, std::vector<cv::Point> & imgsPoints, std::vector<cv::Rect> overlapBlockRects)
{
	CpuTimer ttime;
	ttime.StartTime();
	int maxX, maxY, minX, minY;
	globalCoordinateConvertLocalCoordinate(imgsPoints, blockRect, maxX, maxY, minX, minY);//转换成局部图像的组成全局坐标
	for (int i = 0; i < overlapBlockRects.size(); i++)
	{
		overlapBlockRects[i].x = overlapBlockRects[i].x - minX;
		overlapBlockRects[i].y = overlapBlockRects[i].y - minY;
	}
	////验证重叠区域
	//cv::RNG randomScalar;
	//cv::Mat bgrFusion;
	//if (fusionBlockMat.channels() == 1)
	//{
	//	cvtColor(fusionBlockMat, bgrFusion, COLOR_GRAY2BGR);
	//}
	//else
	//{
	//	bgrFusion = fusionBlockMat.clone();
	//}
	//for (int i = 0; i < overlapBlockRects.size(); i++)
	//{
	//	int iB = randomScalar.uniform(0, 255);
	//	int iG = randomScalar.uniform(0, 255);
	//	int iR = randomScalar.uniform(0, 255);
	//	cv::Rect temOverRect = overlapBlockRects[i];
	//	cv::Rect temRelaBlockRect = temOverRect;
	//	temRelaBlockRect.x = temOverRect.x - blockRect.x;
	//	temRelaBlockRect.y = temOverRect.y - blockRect.y;
	//	rectangle(bgrFusion, temRelaBlockRect, Scalar(iB, iG, iR), -1);
	//}
	////验证结束
	if (fusionBlockMat.channels() == 1)
	{
		cv::Mat sumWeightMat(fusionBlockMat.size(), CV_32FC1, Scalar::all(0));
		cv::Mat sumFusionMat(fusionBlockMat.size(), CV_32FC1, Scalar::all(0));
		for (int i = 0; i < overlapBlockRects.size(); i++)
		{
			cv::Rect temOverRect = overlapBlockRects[i];//overlapBlockRect是组成图像的在最终大图上全局坐标
			cv::Rect temRelaBlockRect = temOverRect;
			temRelaBlockRect.x = temOverRect.x - blockRect.x;//转换到在裁剪图块上的坐标
			temRelaBlockRect.y = temOverRect.y - blockRect.y;
			//
			cv::Rect temRelaImgRect = temOverRect; //转换到图像上的坐标
			temRelaImgRect.x = temRelaImgRect.x - imgsPoints[i].x;
			temRelaImgRect.y = temRelaImgRect.y - imgsPoints[i].y;

			cv::Mat rectImgWeightMat = weightMap(temRelaImgRect).clone();
			cv::Mat overlapImg = overlapRectImgs[i];
			overlapImg.convertTo(overlapImg, CV_32FC1);
			cv::Mat weightRectPixel = overlapImg.mul(rectImgWeightMat) /*srcImgs[i] * rectWeightMat*/;

			cv::Mat temFusionMat(fusionBlockMat.size(), CV_32FC1, Scalar::all(0));
			weightRectPixel.copyTo(temFusionMat(temRelaBlockRect));
			sumFusionMat += temFusionMat;
			cv::Mat overlapWeightMat(fusionBlockMat.size(), CV_32FC1, Scalar::all(0));
			rectImgWeightMat.copyTo(overlapWeightMat(temRelaBlockRect));
			sumWeightMat += overlapWeightMat;
		}
		//	
		cv::Mat fusionMat;
		cv::divide(sumFusionMat, sumWeightMat, fusionMat);
		// 四舍五入
		cv::convertScaleAbs(fusionMat, fusionBlockMat, 1, 0.5);

	}
	else if (fusionBlockMat.channels() == 3)
	{
		cv::Mat sumWeightMat(fusionBlockMat.size(), CV_32FC3, Scalar::all(0));
		cv::Mat sumFusionMat(fusionBlockMat.size(), CV_32FC3, Scalar::all(0));
		//std::cout << " imgsOverlapWithBlockFusion start" << std::endl;
		for (int i = 0; i < overlapBlockRects.size(); i++)
		{
			cv::Rect temOverRect = overlapBlockRects[i];//overlapBlockRect是组成图像的在最终大图上全局坐标
			cv::Rect temRelaBlockRect = temOverRect;
			temRelaBlockRect.x = temOverRect.x - blockRect.x;//转换到在裁剪图块上的坐标
			temRelaBlockRect.y = temOverRect.y - blockRect.y;
			//
			cv::Rect temRelaImgRect = temOverRect; //转换到图像上的坐标
			temRelaImgRect.x = temRelaImgRect.x - imgsPoints[i].x;
			temRelaImgRect.y = temRelaImgRect.y - imgsPoints[i].y;
			if ((temRelaImgRect.x + temRelaImgRect.width) > weightMap.cols || (temRelaImgRect.y + temRelaImgRect.height) > weightMap.rows)
			{
				LOG_ERROR("default", "temRelaImgRect Over weightMap");
				return;
			}
			cv::Mat rectImgWeightMat = weightMap(temRelaImgRect);
			cv::Mat overlapImg = overlapRectImgs[i];
			overlapImg.convertTo(overlapImg, CV_32FC3);
			cv::Mat weightRectPixel = overlapImg.mul(rectImgWeightMat) /*srcImgs[i] * rectWeightMat*/;
			add(sumFusionMat(temRelaBlockRect), weightRectPixel, sumFusionMat(temRelaBlockRect));
			add(sumWeightMat(temRelaBlockRect), rectImgWeightMat, sumWeightMat(temRelaBlockRect));
		}
		//std::cout << " imgsOverlapWithBlockFusion endl" << std::endl;
		//ttime.StopTime("Mask权重图融合", true);
		//	
		cv::Mat fusionMat;
		cv::divide(sumFusionMat, sumWeightMat, fusionMat);
		// 四舍五入
		cv::convertScaleAbs(fusionMat, fusionBlockMat,1,0.5);
	}
	//ttime.StopTime("边界权重图融合", true);
}

BlenderDefault::BlenderDefault()
{

}

BlenderDefault::~BlenderDefault()
{

}


int BlenderDefault::stitchWidthHeightCalcute(std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tiles_Map, int & stitch_Width, int& stitch_Height,float** pImgCoordinate)
{
	int min_x = 9999999, min_y = 9999999;
	int max_x = 0, max_y = 0;
	for (const auto& pair : tiles_Map)
	{
		const Position& point = pair.first;                // 获取键
		const std::shared_ptr<Tile>& tile = pair.second;   // 获取值
		if (min_x > tile->_global_coor.x)
			min_x = tile->_global_coor.x;
		if (min_y > tile->_global_coor.y)
			min_y = tile->_global_coor.y;
		if (max_x < tile->_global_coor.x)
			max_x = tile->_global_coor.x;
		if (max_y < tile->_global_coor.y)
			max_y = tile->_global_coor.y;
	}
	max_x -= min_x, max_y -= min_y;
	int i = 0;
	for (const auto& pair : tiles_Map)
	{
		const Position& point = pair.first;             // 获取键
		const std::shared_ptr<Tile>& tile = pair.second; // 获取值
		SyPoint2D syPt;
		tile->_global_coor.x = tile->_global_coor.x - min_x;
		tile->_global_coor.y = tile->_global_coor.y - min_y;
		//保存图像全局坐标
		if (pImgCoordinate != nullptr)
		{
			pImgCoordinate[i][0] = point._row;
			pImgCoordinate[i][1] = point._col;
			pImgCoordinate[i][2] = tile->_global_coor.x;
			pImgCoordinate[i][3] = 0;
			pImgCoordinate[i][4] = 0;
			pImgCoordinate[i][5] = tile->_global_coor.y;
			//
			i++;
		}
	}
	int iImgWidth = 0;
	int iImgHeight = 0;
	for (const auto& pair : tiles_Map)
	{
		const Position& point = pair.first;                // 获取键
		const std::shared_ptr<Tile>& tile = pair.second;   // 获取值
		iImgWidth = tile->getMat().cols;
		iImgHeight = tile->getMat().rows;
		break;
	}
	//拼接大图的宽和高
	stitch_Width = max_x + iImgWidth;
	stitch_Height = max_y + iImgHeight;

	return 1;
}


int BlenderDefault::blender(const std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tiles_Map, SyImage* pImg_out)
{
	try
	{
		if (tiles_Map.size() == 0)
		{
			return -1;
		}

		cv::Mat outImg(pImg_out->height, pImg_out->width, pImg_out->type, pImg_out->data);

		for (const auto& pair : tiles_Map)
		{
			const Position& point = pair.first;                // 获取键
			const std::shared_ptr<Tile>& tile = pair.second;   // 获取值
			cv::Mat image1 = tile->getMat();
			int iWidth = image1.cols;
			int iHeight = image1.rows;
			if (image1.empty())
			{
				LOG_ERROR("default", "overlapMultiAreaFusionMapBaseWeightMaskMappThreadBlock  image1.empty()== true ");
				return -1;
			}
			cv::Point imgShiftPoint = tile->_global_coor;
			cv::Rect imgRect = cv::Rect(imgShiftPoint.x, imgShiftPoint.y, iWidth, iHeight);
			if ((imgRect.x + imgRect.width) > outImg.cols || (imgRect.y + imgRect.height) > outImg.rows)
			{
				LOG_ERROR("default", "overlapMultiAreaFusionMapBaseWeightMaskMappThreadBlock  imgRect Over pImg_out ");
				return -2;
			}
			image1.copyTo(outImg(imgRect));
		}
		return 1;
	}
	catch (const cv::Exception& cv_str)
	{
		std::string error_info = cv_str.what();
		std::cout << "error_info:" << error_info << std::endl;
		return ERR_TRY_CATCH_OPENCV;
	}
	catch (const std::string& std_str)
	{
		std::string error_info = std_str;
		std::cout << "error_info:" << error_info << std::endl;
		return ERR_TRY_CATCH_STD;
	}
}

CBoarderWeightFusion::CBoarderWeightFusion()
{

}

CBoarderWeightFusion::~CBoarderWeightFusion()
{

}


//单个线程的图像块拼接缝融-边界加权
void overlapMultiAreaFusionBaseWeightMaskThreadBlock(int indexNumb, int oneThreadBlocks, int blockNums, const std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tiles_Map, const cv::Mat& weightMap, cv::Mat& pImg_out, int rowBlocks, int type)
{
	try
	{
		int iStartIndex = indexNumb * oneThreadBlocks;
		int iEndIndex = (indexNumb + 1) * oneThreadBlocks;
		if (iEndIndex > blockNums)
		{
			iEndIndex = blockNums;
		}
		for (int baseIndex = iStartIndex; baseIndex < iEndIndex; baseIndex++)
		{
			int j = baseIndex / rowBlocks;//行
			int i = baseIndex % rowBlocks;//列
			int iImgWidth = weightMap.cols;
			int iImgHeight = weightMap.rows;
			//与块图像重叠的矩形区域坐标
			std::vector<cv::Rect> overlapBlockRects;
			//重叠的矩形区域图像
			std::vector<cv::Mat> overlapRectImgs;
			//图像的全局坐标
			std::vector<cv::Point> imgsPoints;
			cv::Point rectCenterPoint = cv::Point(i * iImgWidth + iImgWidth / 2, j * iImgHeight + iImgHeight / 2);
			cv::Rect blockRectGlobal = cv::Rect(i * iImgWidth, j * iImgHeight, iImgWidth, iImgHeight);
			cv::Rect globaBlockRect = blockRectGlobal;
			//tile图像
			cv::Mat fusionBlockMat = cv::Mat::zeros(Size(blockRectGlobal.width, blockRectGlobal.height), type/*CV_8UC1*/);

			for (const auto& pair : tiles_Map)
			{
				const std::shared_ptr<Tile>& tile = pair.second;   // 获取值
				const cv::Point& imgPointGlobal = tile->_global_coor; // 获取键
				cv::Point imgCenterPoint = cv::Point(imgPointGlobal.x + iImgWidth / 2, imgPointGlobal.y + iImgHeight / 2);
				int xCenterDiff = abs(imgCenterPoint.x - rectCenterPoint.x);
				int yCenterDiff = abs(imgCenterPoint.y - rectCenterPoint.y);

				if (xCenterDiff < iImgWidth && yCenterDiff < iImgHeight)//两个矩形框有重叠
				{
					cv::Mat image1 = tile->getMat();
					imgsPoints.emplace_back(imgPointGlobal);
					cv::Rect imgRectGlobal = cv::Rect(imgPointGlobal.x, imgPointGlobal.y, iImgWidth, iImgHeight);
					cv::Rect overlapRect = imgRectGlobal & blockRectGlobal;
					overlapBlockRects.emplace_back(overlapRect);//与图块重叠区域的矩形(全局)坐标
					cv::Rect imgCutRect = cv::Rect(overlapRect.x - imgRectGlobal.x, overlapRect.y - imgRectGlobal.y, overlapRect.width, overlapRect.height);
					cv::Mat rectImg = image1(imgCutRect);
					overlapRectImgs.emplace_back(rectImg);
				}
			}

			if (overlapBlockRects.size() > 0)
			{
				imgsOverlapWithBlockFusion(blockRectGlobal, fusionBlockMat, weightMap, overlapRectImgs, imgsPoints, overlapBlockRects);
			}

			if (globaBlockRect.x > pImg_out.cols || globaBlockRect.y > pImg_out.rows)
			{
				return;
			}
			bool bCorrectRect = false;
			cv::Rect rectRelativeBlock = cv::Rect(0, 0, 0, 0);
			rectRelativeBlock.height = globaBlockRect.height;
			rectRelativeBlock.width = globaBlockRect.width;
			//根据拼接图像的大小,删除多余块区域
			if ((globaBlockRect.x + iImgWidth) > pImg_out.cols)
			{
				globaBlockRect.width = pImg_out.cols - globaBlockRect.x;
				rectRelativeBlock.width = globaBlockRect.width;
				bCorrectRect = true;
			}
			if ((globaBlockRect.y + iImgHeight) > pImg_out.rows)
			{
				globaBlockRect.height = pImg_out.rows - globaBlockRect.y;
				rectRelativeBlock.height = globaBlockRect.height;
				bCorrectRect = true;
			}
			if (bCorrectRect == true)
			{
				cv::Mat rectBlockMat = fusionBlockMat(rectRelativeBlock);
				rectBlockMat.copyTo(pImg_out(globaBlockRect));
			}
			else
			{
				fusionBlockMat.copyTo(pImg_out(globaBlockRect));
			}
			//
			//std::string blockName = std::to_string(j) + "_" + std::to_string(i) + ".jpg";
			//cv::imwrite("E:\\blockTiffImg\\" + blockName, fusionBlockMat);
			//
			std::vector<cv::Mat>().swap(overlapRectImgs);
		}
	}
	catch (const cv::Exception& cv_str)
	{
		std::string error_info = cv_str.what();
		LOG_ERROR("default", error_info);
		return ;
	}
	catch (const std::string& std_str)
	{
		std::string error_info = std_str;
		LOG_ERROR("default", error_info);
		return;
	}
	
}


int CBoarderWeightFusion::blender(const std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tiles_Map, SyImage* pImg_out)
{
	try
	{
		if (tiles_Map.size() == 0)
		{
			return -1;
		}
		cv::Mat inImg;
		for (const auto& pair : tiles_Map)
		{
			const Position& point = pair.first;                // 获取键
			const std::shared_ptr<Tile>& tile = pair.second;   // 获取值
			inImg = tile->getMat();
			break;
		}
		int iHeight = inImg.rows;
		int iWidth = inImg.cols;
		//权重响应图计算
		cv::Mat weightMap(iHeight, iWidth, CV_64FC1, cv::Scalar::all(0.0));
		double alpha = 12/*6*/;
		for (int i = 0; i < weightMap.rows; i++)
		{
			for (int j = 0; j < weightMap.cols; j++)
			{
				int iXdist = min(j, iWidth - j - 1) + 1;
				int iYdist = min(i, iHeight - i - 1) + 1;

				double fWeight = double(iXdist) * double(iYdist) / double(iWidth); //5 is empirical value
				double weightPow = pow(fWeight, alpha);
				weightMap.ptr<double>(i)[j] = weightPow;
			}
		}
		cv::normalize(weightMap, weightMap, 0.0, 1.0, cv::NORM_MINMAX, CV_32FC1);
		weightMap.convertTo(weightMap, CV_32FC1);
		if (inImg.channels() == 3)
		{
			cvtColor(weightMap, weightMap, COLOR_GRAY2BGR);
		}
		//
		int stitchImgHeight = pImg_out->height;
		int stitchImgWidth = pImg_out->width;
		int splitRowNums = ceil(float(stitchImgHeight) / iHeight);
		int splitColNums = ceil(float(stitchImgWidth) / iWidth);
		//
		int type = pImg_out->type;
		cv::Mat outImg(pImg_out->height, pImg_out->width, pImg_out->type, pImg_out->data);
		int threadBlockNum = splitRowNums * splitColNums;
		//多线程进行多图像重叠区域融合
		int numThreads = 8;
		int oneThreadImg = ceil(float(threadBlockNum) / numThreads);
		std::vector<std::future<void>> vecFocusFt(numThreads); //线程
		for (int indexNumb = 0; indexNumb < numThreads; indexNumb++)
		{
			vecFocusFt[indexNumb] = std::async(std::launch::async, [&, indexNumb] { overlapMultiAreaFusionBaseWeightMaskThreadBlock(indexNumb, oneThreadImg, threadBlockNum, tiles_Map, weightMap, outImg, splitColNums, type); });
		}
		for (int indexNumb = 0; indexNumb < numThreads; indexNumb++)
		{
			vecFocusFt[indexNumb].wait();
		}
		////串行处理
		//for (int blockIndexThread = 0; blockIndexThread < threadBlockNum; blockIndexThread++)
		//{
		//	overlapMultiAreaFusionBaseWeightMaskThreadBlock(blockIndexThread, 1, threadBlockNum, tiles_Map, weightMap, outImg, splitColNums, type);
		//}
	}
	catch (const cv::Exception& cv_str)
	{
		std::string error_info = cv_str.what();
		LOG_ERROR("default", error_info);
		return ERR_TRY_CATCH_OPENCV;
	}
	catch (const std::string& std_str)
	{
		std::string error_info = std_str;
		LOG_ERROR("default", error_info);
		return ERR_TRY_CATCH_STD;
	}
	return 1;
}

CBoarderPyrFusion::CBoarderPyrFusion()
{

}

CBoarderPyrFusion::~CBoarderPyrFusion()
{

}
//
//对多张图像组成的矩形区域进行拼接缝融合及裁剪-金字塔融合裁剪
void imgsOverlapWithBlockPyrFusion(cv::Rect& blockRect, cv::Mat& fusionBlockMat, const cv::Mat& weightMap_Thin, const cv::Mat& weightMap_Fat, const std::vector<cv::Mat>& overlapRectImgs, std::vector<cv::Point> & imgsPoints, std::vector<cv::Rect> overlapBlockRects)
{
	//CpuTimer ttime;
	//ttime.StartTime();
	int maxX, maxY, minX, minY;
	globalCoordinateConvertLocalCoordinate(imgsPoints, blockRect, maxX, maxY, minX, minY);//转换成局部图像的组成全局坐标
	for (int i = 0; i < overlapBlockRects.size(); i++)
	{
		overlapBlockRects[i].x = overlapBlockRects[i].x - minX;
		overlapBlockRects[i].y = overlapBlockRects[i].y - minY;
	}
	////验证重叠区域
	//cv::RNG randomScalar;
	//cv::Mat bgrFusion;
	//if (fusionBlockMat.channels() == 1)
	//{
	//	cvtColor(fusionBlockMat, bgrFusion, COLOR_GRAY2BGR);
	//}
	//else
	//{
	//	bgrFusion = fusionBlockMat.clone();
	//}
	//for (int i = 0; i < overlapBlockRects.size(); i++)
	//{
	//	int iB = randomScalar.uniform(0, 255);
	//	int iG = randomScalar.uniform(0, 255);
	//	int iR = randomScalar.uniform(0, 255);
	//	cv::Rect temOverRect = overlapBlockRects[i];
	//	cv::Rect temRelaBlockRect = temOverRect;
	//	temRelaBlockRect.x = temOverRect.x - blockRect.x;
	//	temRelaBlockRect.y = temOverRect.y - blockRect.y;
	//	rectangle(bgrFusion, temRelaBlockRect, Scalar(iB, iG, iR), -1);
	//}
	////验证结束
	
	if (fusionBlockMat.channels() == 3)
	{
		cv::Mat sumWeightMatBg(fusionBlockMat.rows, fusionBlockMat.cols, CV_32FC3, Scalar::all(0));
		cv::Mat sumWeightMatDetail(fusionBlockMat.rows, fusionBlockMat.cols, CV_32FC3, Scalar::all(0));
		cv::Mat sumFusionMatBg(fusionBlockMat.rows, fusionBlockMat.cols, CV_32FC3, Scalar::all(0));
		cv::Mat sumFusionMatDetail(fusionBlockMat.rows, fusionBlockMat.cols, CV_32FC3, Scalar::all(0));
		cv::Mat outFusionMat(fusionBlockMat.rows, fusionBlockMat.cols, CV_32FC3, Scalar::all(0));

		for (int i = 0; i < imgsPoints.size(); i++)
		{
			cv::Rect temOverRect = overlapBlockRects[i];//overlapBlockRect是组成图像的在最终大图上全局坐标
			cv::Rect temRelaBlockRect = temOverRect;
			temRelaBlockRect.x = temOverRect.x - blockRect.x;//转换到在裁剪图块上的坐标
			temRelaBlockRect.y = temOverRect.y - blockRect.y;
			//
			cv::Rect temRelaImgRect = temOverRect; //转换到图像上的坐标
			temRelaImgRect.x = temRelaImgRect.x - imgsPoints[i].x;
			temRelaImgRect.y = temRelaImgRect.y - imgsPoints[i].y;

			cv::Mat rectImgWeightMat_Thin = weightMap_Thin(temRelaImgRect);
			cv::Mat rectImgWeightMat_Fat = weightMap_Fat(temRelaImgRect);
			cv::Mat overlapImg = overlapRectImgs[i];
			overlapImg.convertTo(overlapImg, CV_32FC3);

			cv::Mat image1_Bg;
			boxFilter(overlapImg, image1_Bg, -1, Size(31, 31));

			cv::Mat image1_detail = overlapImg - image1_Bg;
			cv::Mat weightPixelDetail = image1_detail.mul(rectImgWeightMat_Thin) /*srcImgs[i] * rectWeightMat*/;
		
			add(sumFusionMatDetail(temRelaBlockRect), weightPixelDetail, sumFusionMatDetail(temRelaBlockRect));
			add(sumWeightMatDetail(temRelaBlockRect), rectImgWeightMat_Thin, sumWeightMatDetail(temRelaBlockRect));

			cv::Mat weightPixelBg = image1_Bg.mul(rectImgWeightMat_Fat) /*srcImgs[i] * rectWeightMat*/;
			add(sumFusionMatBg(temRelaBlockRect), weightPixelBg, sumFusionMatBg(temRelaBlockRect));
			add(sumWeightMatBg(temRelaBlockRect), rectImgWeightMat_Fat, sumWeightMatBg(temRelaBlockRect));
		}

		cv::Mat fusionMatBg;
		cv::divide(sumFusionMatBg, sumWeightMatBg, fusionMatBg);
		cv::Mat fusionMatDetail;
		cv::divide(sumFusionMatDetail, sumWeightMatDetail, fusionMatDetail);
		add(fusionMatDetail, fusionMatBg, fusionMatDetail);
		cv::convertScaleAbs(fusionMatDetail, fusionBlockMat, 1, 0.5);
	}
	//ttime.StopTime("pyr权重图融合", true);
}

//单个线程的图像块拼接缝融合-金字塔融合
void overlapMultiPyrThreadBlock(int indexNumb, int oneThreadBlocks, int blockNums, const std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tiles_Map, const cv::Mat& weightMap_Thin, const cv::Mat& weightMap_Fat, cv::Mat& pImg_out, int rowBlocks, int type)
{
	try
	{
		int iImgWidth = weightMap_Thin.cols;
		int iImgHeight = weightMap_Thin.rows;
		int iStartIndex = indexNumb * oneThreadBlocks;
		int iEndIndex = (indexNumb + 1) * oneThreadBlocks;
		if (iEndIndex > blockNums)
		{
			iEndIndex = blockNums;
		}
		for (int baseIndex = iStartIndex; baseIndex < iEndIndex; baseIndex++)
		{
			int j = baseIndex / rowBlocks;//行
			int i = baseIndex % rowBlocks;//列
			//与块图像重叠的矩形区域坐标
			std::vector<cv::Rect> overlapBlockRects;
			//重叠的矩形区域图像
			std::vector<cv::Mat> overlapRectImgs;
			//图像的全局坐标
			std::vector<cv::Point> imgsPoints;
			cv::Point rectCenterPoint = cv::Point(i * iImgWidth + iImgWidth / 2, j * iImgHeight + iImgHeight / 2);
			cv::Rect blockRectGlobal = cv::Rect(i * iImgWidth, j * iImgHeight, iImgWidth, iImgHeight);
			cv::Rect globaBlockRect = blockRectGlobal;
			//tile图像
			cv::Mat fusionBlockMat = cv::Mat::zeros(Size(blockRectGlobal.width, blockRectGlobal.height), type/*CV_8UC1*/);

			for (const auto& pair : tiles_Map)
			{
				const std::shared_ptr<Tile>& tile = pair.second;   // 获取值
				const cv::Point& imgPointGlobal = tile->_global_coor; // 获取键
				cv::Point imgCenterPoint = cv::Point(imgPointGlobal.x + iImgWidth / 2, imgPointGlobal.y + iImgHeight / 2);
				int xCenterDiff = abs(imgCenterPoint.x - rectCenterPoint.x);
				int yCenterDiff = abs(imgCenterPoint.y - rectCenterPoint.y);

				if (xCenterDiff < iImgWidth && yCenterDiff < iImgHeight)//两个矩形框有重叠
				{
					cv::Mat image1 = tile->getMat();
					imgsPoints.emplace_back(imgPointGlobal);
					cv::Rect imgRectGlobal = cv::Rect(imgPointGlobal.x, imgPointGlobal.y, iImgWidth, iImgHeight);
					cv::Rect overlapRect = imgRectGlobal & blockRectGlobal;
					overlapBlockRects.emplace_back(overlapRect);//与图块重叠区域的矩形(全局)坐标
					cv::Rect imgCutRect = cv::Rect(overlapRect.x - imgRectGlobal.x, overlapRect.y - imgRectGlobal.y, overlapRect.width, overlapRect.height);
					cv::Mat rectImg = image1(imgCutRect);
					overlapRectImgs.emplace_back(rectImg);
				}
			}

			if (overlapBlockRects.size() > 0)
			{
				imgsOverlapWithBlockPyrFusion(blockRectGlobal, fusionBlockMat, weightMap_Thin,weightMap_Fat, overlapRectImgs, imgsPoints, overlapBlockRects);
			}

			if (globaBlockRect.x > pImg_out.cols || globaBlockRect.y > pImg_out.rows)
			{
				return;
			}
			bool bCorrectRect = false;
			cv::Rect rectRelativeBlock = cv::Rect(0, 0, 0, 0);
			rectRelativeBlock.height = globaBlockRect.height;
			rectRelativeBlock.width = globaBlockRect.width;
			//根据拼接图像的大小,删除多余块区域
			if ((globaBlockRect.x + iImgWidth) > pImg_out.cols)
			{
				globaBlockRect.width = pImg_out.cols - globaBlockRect.x;
				rectRelativeBlock.width = globaBlockRect.width;
				bCorrectRect = true;
			}
			if ((globaBlockRect.y + iImgHeight) > pImg_out.rows)
			{
				globaBlockRect.height = pImg_out.rows - globaBlockRect.y;
				rectRelativeBlock.height = globaBlockRect.height;
				bCorrectRect = true;
			}
			if (bCorrectRect == true)
			{
				cv::Mat rectBlockMat = fusionBlockMat(rectRelativeBlock);
				rectBlockMat.copyTo(pImg_out(globaBlockRect));
			}
			else
			{
				fusionBlockMat.copyTo(pImg_out(globaBlockRect));
			}
			//
			//std::string blockName = std::to_string(j) + "_" + std::to_string(i) + ".jpg";
			//cv::imwrite("E:\\blockTiffImg\\" + blockName, fusionBlockMat);
			//
			std::vector<cv::Mat>().swap(overlapRectImgs);
		}
	}
	catch (const cv::Exception& cv_str)
	{
		std::string error_info = cv_str.what();
		LOG_ERROR("default", error_info);
		return;
	}
	catch (const std::string& std_str)
	{
		std::string error_info = std_str;
		LOG_ERROR("default", error_info);
		return;
	}

}

int CBoarderPyrFusion::blender(const std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tiles_Map, SyImage* pImg_out)
{
	try
	{
		if (tiles_Map.size() == 0)
		{
			return -1;
		}
		cv::Mat inImg;
		for (const auto& pair : tiles_Map)
		{
			const Position& point = pair.first;                // 获取键
			const std::shared_ptr<Tile>& tile = pair.second;   // 获取值
			inImg = tile->getMat();
			break;
		}
		int iHeight = inImg.rows;
		int iWidth = inImg.cols;
		//权重响应图计算
		cv::Mat weightMap_Fat(iHeight, iWidth, CV_32FC1, cv::Scalar::all(0.0));
		cv::Mat weightMap_Thin(iHeight, iWidth, CV_32FC1, cv::Scalar::all(0.0));
		float alpha_Thin = 12.0;
		float alpha_Fat = 1.0;
		for (int i = 0; i < weightMap_Thin.rows; i++)
		{
			for (int j = 0; j < weightMap_Thin.cols; j++)
			{
				int iXdist = min(j, iWidth - j - 1) + 1;
				int iYdist = min(i, iHeight - i - 1) + 1;

				float fWeight = float(iXdist) * float(iYdist) / float(iWidth); //5 is empirical value
				float weightPow = pow(fWeight, alpha_Thin);
				weightMap_Thin.ptr<float>(i)[j] = weightPow;

				weightPow = pow(fWeight, alpha_Fat);
				weightMap_Fat.ptr<float>(i)[j] = weightPow;
			}
		}
		if (inImg.channels() == 3)
		{
			cvtColor(weightMap_Thin, weightMap_Thin, COLOR_GRAY2BGR);
			cvtColor(weightMap_Fat, weightMap_Fat, COLOR_GRAY2BGR);
		}
		//
		//
		int stitchImgHeight = pImg_out->height;
		int stitchImgWidth = pImg_out->width;
		int splitRowNums = ceil(float(stitchImgHeight) / iHeight);
		int splitColNums = ceil(float(stitchImgWidth) / iWidth);
		//
		int type = pImg_out->type;
		cv::Mat outImg(pImg_out->height, pImg_out->width, pImg_out->type, pImg_out->data);
		int threadBlockNum = splitRowNums * splitColNums;
		//多线程进行多图像重叠区域融合
		int numThreads = 8;
		int oneThreadImg = ceil(float(threadBlockNum) / numThreads);
		std::vector<std::future<void>> vecFocusFt(numThreads); //线程
		for (int indexNumb = 0; indexNumb < numThreads; indexNumb++)
		{
			vecFocusFt[indexNumb] = std::async(std::launch::async, [&, indexNumb] { overlapMultiPyrThreadBlock(indexNumb, oneThreadImg, threadBlockNum, tiles_Map, weightMap_Thin, weightMap_Fat, outImg, splitColNums, type); });
		}
		for (int indexNumb = 0; indexNumb < numThreads; indexNumb++)
		{
			vecFocusFt[indexNumb].wait();
		}
		////串行处理
		//for (int indexNumb = 0; indexNumb < threadBlockNum; indexNumb++)
		//{
		//	overlapMultiPyrThreadBlock(indexNumb, 1, threadBlockNum, tiles_Map, weightMap_Thin, weightMap_Fat, outImg, splitColNums, type);
		//}
	}
	catch (const cv::Exception& cv_str)
	{
		std::string error_info = cv_str.what();
		LOG_ERROR("default", error_info);
		return ERR_TRY_CATCH_OPENCV;
	}
	catch (const std::string& std_str)
	{
		std::string error_info = std_str;
		LOG_ERROR("default", error_info);
		return ERR_TRY_CATCH_STD;
	}
	return 1;
}