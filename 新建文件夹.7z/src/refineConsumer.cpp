﻿#pragma once
#include "alg_base_common.h"
#include "refineConsumer.h"
#include "errorInfo.h"
#include"matchResultDemo.h"
#include "ncc.h"


using namespace cv;
using namespace std;
RefineConsumerDefault::RefineConsumerDefault() 
{
	
}
RefineConsumerDefault::~RefineConsumerDefault() 
{
	
}
int RefineConsumerDefault::refineTaskConsume(const std::shared_ptr<Task>& task_ptr, const SunnyMatchRefineParam & refineParam) 
{
	// //t2相对与t1的grid坐标偏移
	Position relativeWorldCoor = task_ptr->_relativeGridCoor;

	int id1 = -1, id2 = -1;
	if (relativeWorldCoor == Position(0, 1))		// 右侧
	{
		id1 = 1;
		id2 = 3;
	}
	else if (relativeWorldCoor == Position(0, -1))	// 左侧
	{
		id1 = 3;
		id2 = 1;
	}
	else if (relativeWorldCoor == Position(1, 0))	// 下方
	{
		id1 = 2;
		id2 = 0;
	}
	else if (relativeWorldCoor == Position(-1, 0))	// 上方
	{
		id1 = 0;
		id2 = 2;
	}
	else
	{
		return ERR_WRONG_INPUT;
	}
	// 或者两个图像的tile信息
	std::shared_ptr<Tile>& tile1 = task_ptr->_t1_ptr;
	std::shared_ptr<Tile>& tile2 = task_ptr->_t2_ptr;
	// 获取两个图的tile信息
	MatchInfo& tile1MatchInfo = tile1->matchInfos[id1];
	MatchInfo& tile2MatchInfo = tile2->matchInfos[id2];
	// 满足当前条件，则不进行精匹配
	if (abs(tile1MatchInfo.precison) < 10000)
	{
		return INFO_OK;
	}
	// 获取图像
	cv::Mat img_1 = tile1->getMat();
	cv::Mat img_2 = tile2->getMat();

	// 输入匹配的起始位置
	cv::Point inputPtBias = tile1MatchInfo.offset;
	// 初始化匹配的偏移量
	cv::Point outputPtBias;
	// 匹配精度
	float fPrecision;
	// 原来的匹配精度
	float oldp = tile1MatchInfo.precison;
	// 进行精匹配
	// 输入
	// img_1为当前图像
	// img_2为匹配图像
	// inputPtBias为匹配的起始位置
	// 输出
	// outputPtBias为精匹配之后的位置 
	// refineParam为精匹配参数
	// fPrecision为精匹配之后的精度
	this->refineShiftProcessBaseNccMatch(img_1, img_2, inputPtBias, outputPtBias, refineParam, fPrecision);


	tile1MatchInfo.offset = outputPtBias;
	tile1MatchInfo.precison = fPrecision;

	tile2MatchInfo.offset = -outputPtBias;
	tile2MatchInfo.precison = fPrecision;

	//验证偏移计算准确性
	//cv::Mat sititchImg;
	//stitchTwoImg(img_1, img_2, outputPtBias, sititchImg);
	//cv::Mat mask(img_1.size(), CV_8UC1, cv::Scalar::all(255));
	//cv::detail::MultiBandBlender blender1 = cv::detail::MultiBandBlender(false, 5);
	//std::vector<cv::Point>modify_coordinates{ cv::Point(0,0) , outputPtBias };
	//std::vector<cv::Size>sizes{ img_1.size(), img_1.size() };
	//cv::Rect resultRoi = cv::detail::resultRoi(modify_coordinates, sizes);

	//blender1.prepare(resultRoi);
	//blender1.feed(img_1, mask, cv::Point(0, 0));
	//blender1.feed(img_2, mask, outputPtBias);
	//cv::Mat res, m;
	//blender1.blend(res, m);
	return INFO_OK;
	//if (tile1->_grid_coor == cv::Point(5,3) || tile2->_grid_coor == cv::Point(5, 3))
	//{

	//	cv::Mat mask(img_1.size(), CV_8UC1, cv::Scalar::all(255));
	//	cv::detail::MultiBandBlender blender1 = cv::detail::MultiBandBlender(false, 5);
	//	std::vector<cv::Point>modify_coordinates{ cv::Point(0,0) , outputPtBias };
	//	std::vector<cv::Size>sizes{ img_1.size(), img_1.size() };
	//	cv::Rect resultRoi = cv::detail::resultRoi(modify_coordinates, sizes);

	//	blender1.prepare(resultRoi);
	//	blender1.feed(img_1, mask, cv::Point(0, 0));
	//	blender1.feed(img_2, mask, outputPtBias);
	//	cv::Mat res, m;
	//	blender1.blend(res, m);
	//	std::cout << std::endl;
	//}
	//Mat mask(d1.size(), CV_8UC1, Scalar::all(255));
	//cv::detail::MultiBandBlender blender = cv::detail::MultiBandBlender(false, 5);
	//std::vector<Point>modify_coordinates{ Point(0,0) , refineBias };
	//std::vector<Size>sizes{ d1.size(), d1.size() };
	//cv::Rect resultRoi = cv::detail::resultRoi(modify_coordinates, sizes);

	//blender.prepare(resultRoi);
	//blender.feed(d1, mask, Point(0, 0));
	//blender.feed(d2, mask, refineBias);
	//Mat res, m;
	//blender.blend(res, m);

}

int RefineConsumerDefault::refineShiftProcessBaseNccMatch(const cv::Mat& img_in1, const cv::Mat& img_in2, const cv::Point& inputPtBias, cv::Point& outputPtBias, const SunnyMatchRefineParam& refineParam, float& fPrecision) 
{
	// 函数作用：基于NCC的精匹配函数，用于优化初始函数位置并计算匹配精度
	// 输入
	// img_in1为当前帧图像
	// img_in2为匹配模板图像
	// inputPtBias为初始匹配位置偏移量(模板在img_in1的起始位置)
	// 输出
	// outputPtBias为精匹配之后的匹配位置偏移量
	// refineParam为精匹配参数
	// fPrecision为精匹配之后的精度

	//CpuTimer ttr;
	//// 获取开始时间
	//ttr.StartTime();

	// 1. 定义重叠区域并提取模板
	// 定义当前帧的完整ROI(全图范围)，注意：此处高度应为img_in1.rows
	// img_in1.cols = 1920
	// img_in1.rows = 1200
	Rect r1(0, 0, img_in1.cols, img_in2.rows);
	// 定义模板在img_in1中的预期位置ROI
	// img_in2.cols = 1920
	// img_in2.rows = 1200
	// inputPtBias.x = -1679 
	// inputPtBias.y = -2
	Rect r2(inputPtBias.x, inputPtBias.y, img_in2.cols, img_in2.rows);
	// 计算两区域的交集作为有效匹配区域,此处基本取的是全图范围
	Rect roi = r1 & r2;
	// 提取当前有效区域, overloop1会比img_in1小一点
	// overloop1.cols = 1920+inputPtBias.x
	// overloop1.rows = 1200+inputPtBias.y
	Mat overloop1 = img_in1(roi);


	// 2. 生成模板搜索范围
	// 定义模板的全图范围(用于后续偏移计算)
	Rect r11(0, 0, img_in1.cols, img_in1.rows);
	// 定义模板在img_in1中反向偏移区域(用于对齐计算)
	Rect r22(-inputPtBias.x, -inputPtBias.y, img_in2.cols, img_in2.rows);
	// 计算模板的有效显示区域
	Rect roi2 = r11 & r22;
	// 提取模板的有效区域
	Mat overloop2 = img_in2(roi2);

	// 计算搜索范围参数，取模板短边10%和参数指定值的较大者
	int repeatability = max(int(min(overloop2.cols, overloop2.rows) * 0.1), -refineParam.repeatability);
	// 定义8领域搜索方向(菱形搜索范围)
	vector<Point> searchLimit{
								Point(-repeatability, 0),              // 左
								Point(-repeatability, -repeatability), // 左下
								Point(0, -repeatability),              // 下
								Point(repeatability, -repeatability),  // 右下
								Point(repeatability, 0),               // 右
								Point(repeatability, repeatability),   // 右上
								Point(0, repeatability),               // 上
								Point(-repeatability, repeatability),  // 左上
								
	};
	
	// 计算模板匹配的有效搜索区域(所以方向的交集)
	Rect tempRoi(Point(0, 0), overloop1.size());
	for (size_t i = 0; i < searchLimit.size(); i++)
	{
		tempRoi = tempRoi & (Rect(searchLimit[i], overloop1.size()));
	}
	// 无效区域处理
	if (tempRoi.width == 0 || tempRoi.height == 0)
	{
		// 无有效搜索区域，返回失败
		return INFO_FAIL;
	}

	
	// 3. 模板匹配
	// 提取搜索模板
	Mat tempMat = overloop1(tempRoi);

	Mat result;
	// 归一化互相关匹配
	matchTemplate(overloop2, tempMat, result, TM_CCOEFF_NORMED);
	// 修改1：使用快速匹配
	//matchTemplate(overloop2, tempMat, result, TM_SQDIFF);

	// 获取最佳匹配位置
	Point max_loc;
	double max_val;
	minMaxLoc(result, NULL, &max_val, NULL, &max_loc);

	// 计算偏移量修正(考虑坐标系转换)
	Point offset = roi.tl() + tempRoi.tl() - max_loc - roi2.tl();
	// 更新输出偏移量
	outputPtBias = offset;
	

	//// 修改2：使用降采样处理
	//const int downscale = 2;
	//Mat overloop2_down, tempMat_down;
	//resize(overloop2, overloop2_down, Size(), 1.0 / downscale, 1.0 / downscale, INTER_AREA);
	//resize(tempMat, tempMat_down, Size(), 1.0 / downscale, 1.0 / downscale, INTER_AREA);

	//// 在小图上进行匹配
	//Mat result_down;
	////matchTemplate(overloop2_down, tempMat_down, result_down, TM_CCOEFF_NORMED);
	//matchTemplate(overloop2_down, tempMat_down, result_down, TM_SQDIFF);
	//// 找到最大响应位置并放大回原尺寸
	//Point max_loc_down;
	//minMaxLoc(result_down, NULL, NULL, NULL, &max_loc_down);
	//Point max_loc = max_loc_down * downscale;
	//// 精匹配
	//Rect searchROI(max(0, max_loc.x - downscale),
	//			   max(0, max_loc.y - downscale),
	//			   min(overloop2.cols - tempMat.cols, 2 * downscale),
	//			   min(overloop2.rows - tempMat.rows, 2 * downscale));
	//Mat result;
	//matchTemplate(overloop2(searchROI), tempMat, result, TM_CCOEFF_NORMED);
	//// 获取最佳匹配位置
	//double max_val;
	//minMaxLoc(result, NULL, &max_val, NULL, &max_loc);
	//// 计算偏移量修正(考虑坐标系转换)
	//Point offset = roi.tl() + tempRoi.tl() - max_loc - roi2.tl();
	//// 更新输出偏移量
	//outputPtBias = offset;



	// 4. 二次验证与精度计算
	// 重新定义验证区域(试用优化后的偏移量)
	Rect rr1(0, 0, img_in1.cols, img_in2.rows);
	Rect rr2(offset.x, offset.y, img_in2.cols, img_in2.rows);
	Rect rroi = rr1 & rr2;
	// 提取当前帧验证区域
	Mat overloop1r = img_in1(roi);

	// 重新定义模板反向偏移区域
	Rect rr11(0, 0, img_in1.cols, img_in1.rows);
	Rect rr22(-inputPtBias.x, -inputPtBias.y, img_in2.cols, img_in2.rows);
	Rect rroi2 = rr11 & rr22;
	// 提取模板验证区域
	Mat overloop2r = img_in2(roi2);
	
	// 转换为灰度图进行ncc计算
	Mat over1gray, over2gray;
	cvtColor(overloop1r, over1gray, COLOR_BGR2GRAY);
	cvtColor(overloop2r, over2gray, COLOR_BGR2GRAY);
	// 计算最终ncc精度
	computeNCC_8UC1(over1gray, over2gray, max_val);
	// 输出匹配精度
	fPrecision = max_val;


	//ttr.StopTime("ttr time: ", true);

	return INFO_OK;
	
}


