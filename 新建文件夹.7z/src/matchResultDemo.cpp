#include"opencv2/opencv.hpp"
#include"matchResultDemo.h"
using namespace cv;
using namespace std;

//�㷨��֤����ͼ���ƴ���Ƿ�׼ȷ
void stitchTwoImg(const cv::Mat& baseImg, const cv::Mat& matchImg, cv::Point matchPt, cv::Mat &stitcImg)
{
	//vector<string> image_files = strSort(image_file_path, row, col);
	int min_x = 999999, min_y = 999999;
	int max_x = 0, max_y = 0;
	std::vector<cv::Point> coordinates(2);
	coordinates[0] = cv::Point(0, 0);
	coordinates[1] = matchPt;
	std::vector<cv::Mat> inImg(2);
	inImg[0] = baseImg;
	inImg[1] = matchImg;
	for (int i = 0; i < coordinates.size(); i++)
	{
		if (min_x > coordinates[i].x)
			min_x = coordinates[i].x;
		if (min_y > coordinates[i].y)
			min_y = coordinates[i].y;
		if (max_x < coordinates[i].x)
			max_x = coordinates[i].x;
		if (max_y < coordinates[i].y)
			max_y = coordinates[i].y;
	}
	max_x -= min_x, max_y -= min_y;
	for (int i = 0; i < coordinates.size(); i++)
	{
		coordinates[i].x -= min_x;
		coordinates[i].y -= min_y;
	}
	//
	int iMax = max(max_y, max_x);
	float resizeRate = 1;
	if (iMax > 30000)
	{
		resizeRate = 30000.0 / float(iMax);
	}

	max_y = max_y * resizeRate;
	max_x = max_x * resizeRate;
	//
	int height = baseImg.rows;
	int width = baseImg.cols;
	Mat outImg(max_y + height  /*+ 400*/, max_x + width/* + 400*/, CV_8UC3, Scalar(255, 255, 255));
	//
	for (int k = 0; k < coordinates.size(); k++)
	{
		Mat srcImg = inImg[k];
		//
		resize(srcImg, srcImg, cv::Size(srcImg.cols*resizeRate, srcImg.rows*resizeRate));
		int imgWidth = srcImg.cols;
		int imgHeight = srcImg.rows;
		//
		cv::Mat dstImg = cv::Mat::zeros(srcImg.size(), CV_8UC3);
		//
		srcImg.copyTo(outImg(Rect(coordinates[k].x* resizeRate, coordinates[k].y* resizeRate, imgWidth, imgHeight)));
		//
	}
	stitcImg = outImg;
	//std::cout << "---------" << std::endl;
}

//
void blendTwoImg(cv::Mat img_1, cv::Mat img_2, cv::Point outputPtBias, cv::Mat &stitcImg)
{
	cv::Mat mask(img_1.size(), CV_8UC1, cv::Scalar::all(255));
	cv::detail::MultiBandBlender blender1 = cv::detail::MultiBandBlender(false, 5);
	std::vector<cv::Point>modify_coordinates{ cv::Point(0,0) , outputPtBias };
	std::vector<cv::Size>sizes{ img_1.size(), img_1.size() };
	cv::Rect resultRoi = cv::detail::resultRoi(modify_coordinates, sizes);

	blender1.prepare(resultRoi);
	blender1.feed(img_1, mask, cv::Point(0, 0));
	blender1.feed(img_2, mask, outputPtBias);
	cv::Mat res, m;
	blender1.blend(res, m);
}
	