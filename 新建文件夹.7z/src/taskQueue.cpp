﻿#include "stitchDataStruct.h"

TaskQueue::TaskQueue(const int& max_task_queue_size) : _max_task_queue_size(max_task_queue_size)
{
}

TaskQueue::~TaskQueue()
{
}
void TaskQueue::push(std::shared_ptr<Task>& task)
{
	std::unique_lock<std::mutex> lock(mtx);
	//队列至少要留四个空位， 存放可能的上下左右四个任务；
	cv.wait(lock, [&] { return taskQueue.size() < _max_task_queue_size - 4 || produceFinish.load(); });
	if (produceFinish.load())
	{
		return;
	}
	taskQueue.push(task);
	lock.unlock();
	cv.notify_one(); // 通知消费者
}


bool TaskQueue::take(std::shared_ptr<Task> & task)
{
	std::unique_lock<std::mutex> lock(mtx);
	cv.wait(lock, [&] {return !taskQueue.empty() || produceFinish.load(); }); // 等待直到队列非空
	if (taskQueue.empty() && produceFinish.load())
	{
		cv.notify_all();
		return false;
	}
	task = taskQueue.front();
	taskQueue.pop();
	lock.unlock();
	cv.notify_all(); // 通知生产者
	return true;
}
void TaskQueue::setMaxQueueSize(const int& maxQueueSize)
{
	_max_task_queue_size = maxQueueSize;
	return;
}
void TaskQueue::setProduceFinish()
{
	produceFinish.store(true);
	cv.notify_all();
	return;
}



