﻿#pragma once
#include "modeling.h"
#include <unordered_set>
// 包含随机数生成器
#include <random>  

// 构造函数
ModelingDefault::ModelingDefault()
{

}

// 析构函数
ModelingDefault::~ModelingDefault()
{

}

// 初始化函数
void ModelingDefault::Init(int imageWidth, int imageHeight, float overlapUncertainty, float validCorrelationThreshold, float horizontalOverlap, float verticalOverlap)
{
	// 函数作用：模型初始化, 支持方形拼接、圆形拼接和螺旋拼接
	// 输入
	// imageWidth为函数宽度
	// imageHeight为函数高度
	// overlapUncertainty为重叠度
	// validCorrelationThreshold为ncc阈值
	// tileMap为两两拼接结果
	// scanMode为拼接模式

	LOG_INFO("default", "ModelingDefault Init start");

	// 参数初始化
	ModelingArgsInit(imageWidth, imageHeight, overlapUncertainty, validCorrelationThreshold, horizontalOverlap, verticalOverlap);

	LOG_INFO("default", "ModelingDefault Init end");

	return;

}


// 参数初始化
void ModelingDefault::ModelingArgsInit(int imageWidth, int imageHeight, float overlapUncertainty, float validCorrelationThreshold, float horizontalOverlap, float verticalOverlap)
{
	// 模型参数初始化

	// 初始化图像长宽
	args.imageWidth = imageWidth;
	args.imageHeight = imageHeight;

	// 初始化重叠度
	args.overlapUncertainty = overlapUncertainty;

	// 初始化ncc阈值
	args.validCorrelationThreshold = validCorrelationThreshold;

	// 初始化平台建模精度
	args.stageRepeatability = repeatability;

	// 
	args.horizontalOverlap = horizontalOverlap;
	args.verticalOverlap = verticalOverlap;

	return;

}

// 平台建模
int ModelingDefault::newBuild(std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap)
{
	// 函数作用：用于平台建模，并返回偏移量，主要针对上右下左4个方向分别进行建模
	// 输入
	// tileMap为各图像模块数据

	LOG_INFO("default", "ModelingDefault newBuild start");

	// 至少有一个单方向的有效个数大于7个。如果7个都有效，才可以做四分位数
	std::vector<int32_t> validNumber = { 0, 0, 0, 0 };
	for (std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>::iterator it = tileMap.begin(); it != tileMap.end(); ++it)
	{
		// 取出行列
		int j = it->first._col;
		int i = it->first._row;

		// 收集水平方向 上右下左
		std::shared_ptr<Tile>& tile = it->second;
		for (int32_t directionId = 0; directionId < validNumber.size(); directionId++)
		{
			if ((tile->matchFlags[directionId] > 0) && (tile->matchInfos[directionId].precison > args.validCorrelationThreshold))
			{
				validNumber[directionId] = validNumber[directionId] + 1;
			}
		}
	}
	int32_t minValidNumber = -1;
	for (int32_t directionId = 0; directionId < validNumber.size(); directionId++)
	{
		if (validNumber[directionId] < minValidNumber)
		{
			minValidNumber = validNumber[directionId];
		}
	}



	//if (minValidNumber <= 7)
	//{
	//	LOG_INFO("default", "ModelingDefault newBuild maxValidNumber less 8");
	//	return INFO_FAIL;
	//}




	//// 复制上述矩阵
	//std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash> tileMap;
	//for (const auto& pair : newTileMap)
	//{
	//	tileMap[pair.first] = std::make_shared<Tile>(*pair.second);
	//}

	// 上和左取负
	for (std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>::iterator it = tileMap.begin(); it != tileMap.end(); ++it)
	{
		// 取出行列
		int j = it->first._col;
		int i = it->first._row;

		// 收集水平方向 上右下左
		std::shared_ptr<Tile>& tile = it->second;

		tile->matchInfos[0].offset.y = -tile->matchInfos[0].offset.y;
		tile->matchInfos[3].offset.x = -tile->matchInfos[3].offset.x;

	}

	// 初始化标记位
	int flag = 0;

	// 1. 计算重叠度
	// 1.1 计算上方向的重叠率
	upOverlap = -1;
	flag = ComputerOverlapDirection("UP", tileMap, upOverlap);
	if (flag < 0)
	{
		LOG_INFO("default", "ModelingDefault newBuild Call ComputerOverlapDirection Error");
		//return INFO_FAIL;
	}
	if (abs(upOverlap + 1) > args.epsilon)
	{
		args.upOverlap = upOverlap;
	}
	else
	{
		args.upOverlap = args.verticalOverlap;
	}
	// 1.2 计算右方向的重叠率
	rightOverlap = -1;
	flag = ComputerOverlapDirection("RIGHT", tileMap, rightOverlap);
	if (flag < 0)
	{
		LOG_INFO("default", "ModelingDefault newBuild Call ComputerOverlapDirection Error");
		//return INFO_FAIL;
	}
	if (abs(rightOverlap + 1) > args.epsilon)
	{
		args.rightOverlap = rightOverlap;
	}
	else
	{
		args.rightOverlap = args.horizontalOverlap;
	}
	// 1.3 计算下方向的重叠率
	downOverlap = -1;
	flag = ComputerOverlapDirection("DOWN", tileMap, downOverlap);
	if (flag < 0)
	{
		LOG_INFO("default", "ModelingDefault newBuild Call ComputerOverlapDirection Error");
		//return INFO_FAIL;
	}
	if (abs(downOverlap + 1) > args.epsilon)
	{
		args.downOverlap = downOverlap;
	}
	else
	{
		args.downOverlap = args.verticalOverlap;
	}
	// 1.4 计算左方向的重叠率
	leftOverlap = -1;
	flag = ComputerOverlapDirection("LEFT", tileMap, leftOverlap);
	if (flag < 0)
	{
		LOG_INFO("default", "ModelingDefault newBuild Call ComputerOverlapDirection Error");
		//return INFO_FAIL;
	}
	if (abs(leftOverlap + 1) > args.epsilon)
	{
		args.leftOverlap = leftOverlap;
	}
	else
	{
		args.leftOverlap = args.horizontalOverlap;
	}


	// 2. 计算平台精度
	// 2.1 计算上方向的平台精度
	upRepeatability = -1;
	flag = ComputeRepeatabilityDirection("UP", tileMap, upRepeatability);
	if (flag < 0)
	{
		LOG_INFO("default", "ModelingDefault newBuild Call ComputeRepeatabilityDirection Error");
		//return INFO_FAIL;
	}
	if (abs(upRepeatability + 1) > args.epsilon)
	{
		args.upRepeatability = upRepeatability;
	}
	else
	{
		args.upRepeatability = args.stageRepeatability;
	}

	// 2.2 计算右方向的平台精度
	rightRepeatability = -1;
	flag = ComputeRepeatabilityDirection("RIGHT", tileMap, rightRepeatability);
	if (flag < 0)
	{
		LOG_INFO("default", "ModelingDefault newBuild Call ComputeRepeatabilityDirection Error");
		//return INFO_FAIL;
	}
	if (abs(rightRepeatability + 1) > args.epsilon)
	{
		args.rightRepeatability = rightRepeatability;
	}
	else
	{
		args.rightRepeatability = args.stageRepeatability;
	}
	// 2.3 计算下方向的平台精度
	downRepeatability = -1;
	flag = ComputeRepeatabilityDirection("DOWN", tileMap, downRepeatability);
	if (flag < 0)
	{
		LOG_INFO("default", "ModelingDefault newBuild Call ComputeRepeatabilityDirection Error");
		//return INFO_FAIL;
	}
	if (abs(downRepeatability + 1) > args.epsilon)
	{
		args.downRepeatability = downRepeatability;
	}
	else
	{
		args.downRepeatability = args.stageRepeatability;
	}
	// 2.4 计算左方向的平台精度
	leftRepeatability = -1;
	flag = ComputeRepeatabilityDirection("LEFT", tileMap, leftRepeatability);
	if (flag < 0)
	{
		LOG_INFO("default", "ModelingDefault newBuild Call ComputeRepeatabilityDirection Error");
		//return INFO_FAIL;
	}
	if (abs(leftRepeatability + 1) > args.epsilon)
	{
		args.leftRepeatability = leftRepeatability;
	}
	else
	{
		args.leftRepeatability = args.stageRepeatability;
	}


	// 3. 应用平台模型
	// 3.1 上方向应用模型
	flag = ApplyModelDirection("UP", tileMap);
	// 3.2 右方向应用模型
	flag = ApplyModelDirection("RIGHT", tileMap);
	// 3.3 下方向应用模型
	flag = ApplyModelDirection("DOWN", tileMap);
	// 3.4 左方向应用模型
	flag = ApplyModelDirection("LEFT", tileMap);


	// 上和左取负
	for (std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>::iterator it = tileMap.begin(); it != tileMap.end(); ++it)
	{
		// 取出行列
		int j = it->first._col;
		int i = it->first._row;
		// 收集水平方向 上右下左
		std::shared_ptr<Tile>& tile = it->second;

		tile->matchInfos[0].offset.y = -tile->matchInfos[0].offset.y;
		tile->matchInfos[3].offset.x = -tile->matchInfos[3].offset.x;
	}


	// 计算平台精度
	float maxRepeatability = 0;
	if (upRepeatability > maxRepeatability)
	{
		maxRepeatability = upRepeatability;
	}
	if (rightRepeatability > maxRepeatability)
	{
		maxRepeatability = rightRepeatability;
	}
	if (downRepeatability > maxRepeatability)
	{
		maxRepeatability = downRepeatability;
	}
	if (leftRepeatability > maxRepeatability)
	{
		maxRepeatability = leftRepeatability;
	}

	repeatability = int(2 * maxRepeatability + 1);


	LOG_INFO("default", "ModelingDefault newBuild end");

	return INFO_OK;

}

// 计算各方向重叠率
int ModelingDefault::ComputerOverlapDirection(const std::string direction, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, float& overlap)
{
	// 函数作用：计算各方向的重叠率，目前方向分为上右下左
	// 输入
	// direction为方向，上右下左
	// tileMap为各图像模块信息
	// 输出
	// overlap为重叠度

	// 输入防呆
	// 判断输入
	if ((direction != "UP") && (direction != "RIGHT") && (direction != "DOWN") && (direction != "LEFT"))
	{
		LOG_INFO("default", "ModelingDefault ComputerOverlapDirection Input Direction Error");
		return INFO_FAIL;
	}

	// 初始化标记位
	int flag = 0;

	// 获取该方向上的所有
	std::vector<int32_t> translations;
	translations.clear();
	flag = GetTranslationDirection(direction, tileMap, translations);
	if (flag < 0)
	{
		LOG_INFO("default", "ModelingDefault ComputerOverlapDirection Call GetTranslationDirection Error");
		return INFO_FAIL;
	}


	// 获取该方向图像尺寸
	int hOrW = 0;
	flag = GetImageSizeDirection(direction, hOrW);
	if (flag < 0)
	{
		LOG_INFO("default", "ModelingDefault ComputerOverlapDirection Call GetImageSizeDirection Error");
		return INFO_FAIL;
	}

	// 过滤不在图像范围内的值
	std::vector<int32_t> newTranslations;
	newTranslations.clear();
	flag = FilterTranslationsImageRange(translations, hOrW, newTranslations);
	if (flag < 0)
	{
		LOG_INFO("default", "ModelingDefault ComputeOverlap Call FilterTranslations Error");
		return INFO_FAIL;
	}

	// 将数据转成百分比
	std::vector<float> translationsPercentage;
	translationsPercentage.clear();
	flag = TranslationsToPercentage(newTranslations, hOrW, translationsPercentage);
	if (flag < 0)
	{
		LOG_INFO("default", "ModelingDefault ComputeOverlap Call TranslationsToPercentage Error");
		return INFO_FAIL;
	}

	// 进行极大似然估计
	flag = MleDirection(direction, translationsPercentage, overlap);
	if (flag < 0)
	{
		LOG_INFO("default", "ModelingDefault ComputeOverlap Call MleDirection Error");
		return INFO_FAIL;
	}


	return INFO_OK;
}

// 计算各方向重叠率
int ModelingDefault::GetTranslationDirection(const std::string direction, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, std::vector<int32_t>& translations)
{
	// 函数作用：计算各方向的偏移量，目前方向分为上右下左
	// 输入
	// direction为上右下左方向
	// tileMap为各图像信息
	// 输出
	// translations为各方向偏移量

	// 输入防呆
	// 判断输入
	if ((direction != "UP") && (direction != "RIGHT") && (direction != "DOWN") && (direction != "LEFT"))
	{
		LOG_INFO("default", "ModelingDefault GetTranslationDirection Input Direction Error");
		return INFO_FAIL;
	}


	// 取所有的偏移量
	// 对xy进行循环
	for (std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>::iterator it = tileMap.begin(); it != tileMap.end(); ++it)
	{
		// 取出行列
		int j = it->first._col;
		int i = it->first._row;
		// 收集水平方向
		const std::shared_ptr<Tile>& tile = it->second;
		// 取偏移量，目前是上右下左四个方向
		// 上
		if ("UP" == direction)
		{

			// 去标签
			int label = tile->matchFlags[0];
			if (label > 0)
			{
				MatchInfo matchInfos = tile->matchInfos[0];
				translations.push_back(matchInfos.offset.y);
			}
		}
		// 右
		if ("RIGHT" == direction)
		{

			// 去标签
			int label = tile->matchFlags[1];
			if (label > 0)
			{
				MatchInfo matchInfos = tile->matchInfos[1];
				translations.push_back(matchInfos.offset.x);
			}
		}
		// 下
		if ("DOWN" == direction)
		{

			// 去标签
			int label = tile->matchFlags[2];
			if (label > 0)
			{
				MatchInfo matchInfos = tile->matchInfos[2];
				translations.push_back(matchInfos.offset.y);
			}
		}
		// 左
		if ("LEFT" == direction)
		{

			// 去标签
			int label = tile->matchFlags[3];
			if (label > 0)
			{
				MatchInfo matchInfos = tile->matchInfos[3];
				translations.push_back(matchInfos.offset.x);
			}
		}
	}

	return INFO_OK;
}


// 获取该方向图像尺寸
int ModelingDefault::GetImageSizeDirection(const std::string direction, int& hOrW)
{
	// 函数作用：获取该方向图像尺寸，目前方向分为上右下左
	// 输入
	// direction为方向，上右下左
	// 输出
	// hOrW为图像尺寸

	// 输入防呆
	// 判断输入
	if ((direction != "UP") && (direction != "RIGHT") && (direction != "DOWN") && (direction != "LEFT"))
	{
		LOG_INFO("default", "ModelingDefault GetTranslationDirection Input Direction Error");
		return INFO_FAIL;
	}

	// 上下
	if (("UP" == direction) || ("DOWN" == direction))
	{
		hOrW = args.imageHeight;
	}
	else
	{
		// 左右
		hOrW = args.imageWidth;
	}

	return INFO_OK;
}


// 过滤不在图像范围内的偏移量
int ModelingDefault::FilterTranslationsImageRange(const std::vector<int32_t> translations, const int hOrW, std::vector<int32_t>& newTranslations)
{
	// 函数作用：过滤各方向不在图像范围的偏移量
	// 输入
	// translations为该方向上的偏移量集合
	// hOrW为图像该方向的上限
	// 输出
	// newTranslations为过滤后的偏移量

	// 对偏移量进行循环
	for (int32_t transId = 0; transId < translations.size(); transId++)
	{
		// 条件判断
		if ((translations[transId] > 1) && (translations[transId] < hOrW - 1))
		{
			newTranslations.push_back(translations[transId]);
		}
	}

	// 偏移量判断
	if (newTranslations.size() == 0)
	{
		LOG_INFO("default", "ModelingDefault FilterTranslationsImageRange NewTranslations Size Zeros");
		return INFO_FAIL;
	}

	return INFO_OK;
}


// 将重叠率转成百分比
int ModelingDefault::TranslationsToPercentage(const std::vector<int32_t> newTranslations, int hOrW, std::vector<float>& translationsPercentage)
{
	// 函数作用：将重叠率转成百分比
	// 输入
	// newTranslations为过滤后的偏移量
	// hOrW为图像长或者宽
	// 输出
	// translationsPercentage为偏移量百分比

	// 对偏移量进行循环
	for (int32_t transId = 0; transId < newTranslations.size(); transId++)
	{
		float percentage = float(newTranslations[transId]) / float(hOrW) * 100.0;
		translationsPercentage.push_back(percentage);
	}

	return INFO_OK;
}


// 极大似然估计，去找point最合适的值
int ModelingDefault::MleDirection(const std::string direction, std::vector<float> translationsPercentage, float& overlap)
{
	// 函数作用：极大似然估计

	// 初始化稳定迭代的计数器
	int numStableIteration = 0;
	// 初始化最优点
	MlePoint bestPoint;
	// 初始化最优值
	bestPoint.likelihood = -FLT_MAX;
	// 初始化当前点
	MlePoint point;
	// 进行一定次数的迭代，输出稳定的值
	while (numStableIteration < args.NUMBER_STABLE_MLE_ITERATIONS)
	{
		// 随机创建一个当前起始点
		GetRandomPoint(point);

		// 对该点执行爬行操作
		HillClimbSearchDirection(direction, point, translationsPercentage);

		// 如果当前点优于最优点，则进行替换，否则迭代一次
		if (point.likelihood > bestPoint.likelihood)
		{
			// 找到新的最佳点，重置稳定迭代的计数器
			bestPoint.piUni = point.piUni;
			bestPoint.mu = point.mu;
			bestPoint.sigma = point.sigma;
			bestPoint.likelihood = point.likelihood;
			numStableIteration = 0;
		}
		else
		{
			// 增加稳定迭代的计数器（最佳答案未改变）
			numStableIteration = numStableIteration + 1;
		}
	}

	overlap = 100.0 - bestPoint.mu;

	return INFO_OK;
}


// 随机生成起始点
void ModelingDefault::RandomMlePoint(MlePoint& point)
{
	// 函数作用：随机生成起始点
	// 输出
	// point随机值


	// 用于获取随机数种子
	std::random_device rd;
	// 以rd()作为种子的Mersenne Twister生成器
	std::mt19937 gen(rd());

	// 定义随机数分布范围
	std::uniform_int_distribution<> dis_p(0, 99);
	std::uniform_int_distribution<> dis_m(1, 99);
	std::uniform_int_distribution<> dis_s(1, 99);

	// 生成随机数
	int p = dis_p(gen);
	int m = dis_m(gen);
	int s = dis_s(gen);
	// 取极小值
	float l = -FLT_MAX;

	// 赋值
	point.piUni = p;
	point.mu = m;
	point.sigma = s;
	point.likelihood = l;

	return;
}


// 爬坡搜索
void ModelingDefault::HillClimbSearchDirection(const std::string direction, MlePoint& point, const std::vector<float> translations)
{
	// 函数作用：使用参数空间中的百分位分辨率爬山算法来计算MLE模型。
	// 输入
	// translations为偏移量
	// 输出
	// point为优化后的点

	// 初始化
	bool flag = false;

	// 深拷贝起始点作为当前局部最优解
	MlePoint lcl;
	lcl.piUni = point.piUni;
	lcl.mu = point.mu;
	lcl.sigma = point.sigma;
	// 计算computeLikelihood
	computeLikelihoodDirection(lcl, translations);

	// 开始无限循环，直到找到局部最优解且无法再改进
	MlePoint newPoint;
	while (1)
	{
		// 遍历所有可能的爬山方向
		for (int32_t directionId = 0; directionId < mleHillClimbDirection.size(); directionId++)
		{
			// 生成新点
			newPoint.piUni = point.piUni + mleHillClimbDirection[directionId][0];
			newPoint.mu = point.mu + mleHillClimbDirection[directionId][1];
			newPoint.sigma = point.sigma + mleHillClimbDirection[directionId][2];
			// 判断新点是否有效
			flag = IsValid(newPoint);
			if (!flag)
			{
				continue;
			}

			//// 从缓存中获取似然值
			//auto key = std::make_tuple(direction, newPoint.piUni, newPoint.mu, newPoint.sigma);
			//if (auto it = likelihoodCache.find(key); it != likelihoodCache.end())
			//{
			//	newPoint.likelihood = it->second;
			//}
			//else
			//{
			//	// 计算新点的似然值
			//	computeLikelihood(newPoint, translations);
			//	likelihoodCache.emplace(key, newPoint.likelihood);
			//}

			computeLikelihood(newPoint, translations);


			// 检查缓存以查看该似然值是否已计算
			if (abs(newPoint.likelihood) > args.finite)
			{
				newPoint.likelihood = -FLT_MAX;
			}
			// 如果新点的似然值大于当前局部最优解的似然值
			if (newPoint.likelihood > lcl.likelihood)
			{
				// 更新局部最优解
				lcl.piUni = newPoint.piUni;
				lcl.mu = newPoint.mu;
				lcl.sigma = newPoint.sigma;
				lcl.likelihood = newPoint.likelihood;
			}
		}

		// 检查是否找到了更好的局部最优解
		if (lcl.likelihood > point.likelihood)
		{
			point.piUni = lcl.piUni;
			point.mu = lcl.mu;
			point.sigma = lcl.sigma;
			point.likelihood = lcl.likelihood;
		}
		else
		{
			// 如果当前起始点已经是局部最优解中的最好点
			// 则表示爬山搜索已经结束，无法再找到更好的点
			break;
		}
	}

	return;
}


// 计算爬坡的值
void ModelingDefault::computeLikelihoodDirection(MlePoint& point, const std::vector<float> translations)
{
	// 函数作用：计算爬坡值
	// 输入
	// translations为偏移量
	// 输出
	// point为搜索点


	// w_or_h设置为100.0，可能代表平移量的范围宽度或高度（此处为归一化后的[0,100]范围）
	float wOrH = 100.0;
	// 初始化似然值为负无穷大，用于后续比较和更新
	point.likelihood = -FLT_MAX;

	// 检查point的pi_uni属性是否在有效范围内[0, 100)
	if ((point.piUni >= 0) && (point.piUni < 100))
	{
		point.likelihood = 0;
		// 将pi_uni从百分比转换为小数形式，便于后续计算
		float p = float(point.piUni) / 100.0;
		// 复制translations数组，避免修改原始数据
		std::vector<float> ts;
		ts.clear();
		ts.resize(translations.size());
		for (int32_t translationsId = 0; translationsId < translations.size(); translationsId++)
		{
			// 总的公式为：y = ln(p/wh + (1-p)/(根号(2*pi)*sigma)*e^(-(x-u)^2/2*sigma))

			// 根据MLE模型的参数对平移量进行标准化处理, y=(x-miu)/sigma
			ts[translationsId] = (float(abs(translations[translationsId])) - float(point.mu)) / float(point.sigma);
			// 计算标准化后的平移量的高斯分布概率密度函数值 y=e^(-0.5*x^2)
			ts[translationsId] = std::exp(-0.5*ts[translationsId] * ts[translationsId]);
			// 将高斯分布的概率密度函数值除以标准差的根号乘以根号(2*pi)的倒数，得到正态分布的概率密度 y = x/(根号(2*pi)*sigma)
			ts[translationsId] = ts[translationsId] / (sqrt(2 * args.pi)*point.sigma);
			// 根据pi_uni的值混合均匀分布和高斯分布的概率密度函数值
			// 这里假设pi_uni对应的比例p代表选择均匀分布的概率，1-p代表选择高斯分布的概率 y=(p/wh + (1-p)*x)
			ts[translationsId] = (p / wOrH) + (1.0 - p)*ts[translationsId];
			// 对混合后的概率密度函数值取对数，以便求和计算似然值
			// 注意：这里取绝对值可能是为了避免对数运算中的负无穷或零值问题，但在这个上下文中取绝对值可能不太合适，
			// 因为概率密度函数值应该是非负的。如果ts中存在负数，这可能意味着计算过程中有错误。 y=ln(|x|)
			ts[translationsId] = std::log(std::fabs(ts[translationsId]));
			// 计算所有平移量的对数概率密度之和，得到似然值
			point.likelihood = point.likelihood + ts[translationsId];
		}
	}

	return;
}


// 判断爬坡点是否有效
bool ModelingDefault::IsValid(MlePoint newPoint)
{
	bool flag = (newPoint.piUni >= 0) && (newPoint.piUni < 100) && (newPoint.mu >= 0) && (newPoint.mu < 100) && (newPoint.sigma >= 0) && (newPoint.sigma < 100);
	return flag;
}


// 计算各方向的平台精度
int ModelingDefault::ComputeRepeatabilityDirection(const std::string direction, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, float& repeatability)
{
	// 函数作用：计算各方向的平台精度
	// 输入
	// direction为方向
	// tileMap为各图像模块信息
	// 输出
	// repeatability为平台精度

	// 输入防呆
	// 判断输入
	if ((direction != "UP") && (direction != "RIGHT") && (direction != "DOWN") && (direction != "LEFT"))
	{
		LOG_INFO("default", "ModelingDefault ComputerOverlapDirection Input Direction Error");
		return INFO_FAIL;
	}

	// 初始化标记位
	int flag = 0;

	// 获取该方向上的所有
	std::vector<int32_t> translations;
	translations.clear();
	flag = GetTranslationDirection(direction, tileMap, translations);
	if (flag < 0)
	{
		LOG_INFO("default", "ModelingDefault ComputerOverlapDirection Call GetTranslationDirection Error");
		return INFO_FAIL;
	}
	// 判断如果translations为空，就直接返回
	if (translations.size() == 0)
	{
		LOG_INFO("default", "ModelingDefault ComputeRepeatabilityDirection Translations Is Zeros");
		return INFO_FAIL;
	}

	// 初始化有效集的个数
	int validCount = 0;
	// 过滤各方向偏移量
	flag = FilterTranslationsDirection(direction, tileMap, validCount);
	if (flag < 0)
	{
		LOG_INFO("default", "ModelingDefault ComputeRepeatabilityDirection Call FilterTranslationsDirection Error");
		return INFO_FAIL;
	}
	// 判断有效个数
	if (validCount == 0)
	{
		LOG_INFO("default", "ModelingDefault GetValidTranslation validCount Is Zeros");
		repeatability = args.stageRepeatability;
		return INFO_OK;
	}


	// 计算平台精度1
	float repeatability1 = 0;
	flag = repeatabilityOneDirection(direction, tileMap, repeatability1);
	if (flag < 0)
	{
		LOG_INFO("default", "ModelingDefault ComputeRepeatability Call repeatabilityOne Error");
		return INFO_FAIL;
	}

	// 计算平台精度2
	// 按行列取平台精度，取每行每列的平台精度，这里有个问题，如果行或者列数量较少，则建议不进行此建模
	float repeatability2 = 0;
	flag = repeatabilityTwoDirection(direction, tileMap, repeatability2);
	if (flag < 0)
	{
		LOG_INFO("default", "ModelingDefault ComputeRepeatabilityDirection Call repeatabilityTwo Error");
		return INFO_FAIL;
	}
	// 向上取整
	repeatability2 = ceil(repeatability2);

	// 平台精度为
	if (repeatability1 > repeatability2)
	{
		repeatability = repeatability1;
	}
	else
	{
		repeatability = repeatability2;
	}



	// 如果平台精度较大，则
	if (repeatability > 10)
	{
		LOG_INFO("default", "ModelingDefault ComputeRepeatabilityDirection repeatability Value Bigger");
	}

	return INFO_OK;
}


// 过滤各方向偏移量
int ModelingDefault::FilterTranslationsDirection(const std::string direction, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, int& validCount)
{
	// 函数作用：过滤各方向的偏移量
	// 输入
	// direction为方向
	// 输出
	// tileMap为各图像信息

	// 输入防呆
	// 判断输入
	if ((direction != "UP") && (direction != "RIGHT") && (direction != "DOWN") && (direction != "LEFT"))
	{
		LOG_INFO("default", "ModelingDefault ComputerOverlapDirection Input Direction Error");
		return INFO_FAIL;
	}

	// 初始化标记位
	int flag = 0;

	// 获取图像宽高
	int height = args.imageHeight;
	int width = args.imageWidth;

	// 根据方向设计重叠度合计算平移阈值
	float overlap = 0;
	float tMin = 0;
	float tMax = 0;
	float overlapError = 0;
	flag = ComputeParametersDirection(direction, height, width, overlap, tMin, tMax, overlapError);


	if (flag < 0)
	{
		LOG_INFO("default", "ModelingDefault FilterTranslationsValid Call ComputeOverlapParameters Error");
		return INFO_FAIL;
	}


	// 过滤偏移量，得到有效数据集
	flag = GetValidTranslation(direction, tileMap, tMin, tMax, overlapError, validCount);
	if (flag < 0)
	{
		LOG_INFO("default", "ModelingDefault FilterTranslationsValid Call GetValidTranslation Error");
		return INFO_FAIL;
	}

	return INFO_OK;

}

// 根据方向设置重叠度和平移阈值
int ModelingDefault::ComputeParametersDirection(const std::string direction, int height, int width, float& overlap, float& tMin, float& tMax, float& overlapError)
{
	// 函数作用：根据方向和重叠度计算参数
	// 输入
	// direction为方向
	// 输出
	// overlap为重叠率
	// tMin为理论最小重叠
	// tMax为理论最大重叠
	// overlapError为重叠误差

	// 输入防呆
	// 判断输入
	if ((direction != "UP") && (direction != "RIGHT") && (direction != "DOWN") && (direction != "LEFT"))
	{
		LOG_INFO("default", "ModelingDefault ComputerOverlapDirection Input Direction Error");
		return INFO_FAIL;
	}



	// 根据方向设置重叠度和计算平移阈值
	// 上方向
	if ("UP" == direction)
	{
		// 上方向重叠度
		overlap = args.upOverlap;
		tMin = (float)height - (overlap + args.overlapUncertainty)* (float)height / 100.0;
		tMax = (float)height - (overlap - args.overlapUncertainty)* (float)height / 100.0;
		overlapError = args.overlapUncertainty * (float)height / 100.0;
	}
	// 右方向
	if ("RIGHT" == direction)
	{
		// 右方向重叠度

		overlap = args.rightOverlap;
		tMin = (float)width - (overlap + args.overlapUncertainty)* (float)width / 100.0;
		tMax = (float)width - (overlap - args.overlapUncertainty)* (float)width / 100.0;
		overlapError = args.overlapUncertainty * (float)width / 100.0;
	}
	// 下方向
	if ("DOWN" == direction)
	{
		// 下方向重叠度
		overlap = args.downOverlap;
		tMin = (float)height - (overlap + args.overlapUncertainty)* (float)height / 100.0;
		tMax = (float)height - (overlap - args.overlapUncertainty)* (float)height / 100.0;
		overlapError = args.overlapUncertainty * (float)height / 100.0;
	}
	// 左方向
	if ("LEFT" == direction)
	{
		// 左方向重叠度
		overlap = args.leftOverlap;
		tMin = (float)width - (overlap + args.overlapUncertainty)* (float)width / 100.0;
		tMax = (float)width - (overlap - args.overlapUncertainty)* (float)width / 100.0;
		overlapError = args.overlapUncertainty * (float)width / 100.0;
	}

	return INFO_OK;

}

// 过滤偏移量，得到有效数据集
int ModelingDefault::GetValidTranslation(const std::string direction, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, const float tMin, const float tMax, const float overlapError, int& validCount)
{
	// 函数作用：过滤偏移量，得到有效数据集
	// 输入
	// direction为方向
	// tMin为偏移下界
	// tMax为偏移上界
	// overlapError为重叠误差
	// 输出
	// tileMap为各图像信息

	// 输入防呆
	// 判断输入
	if ((direction != "UP") && (direction != "RIGHT") && (direction != "DOWN") && (direction != "LEFT"))
	{
		LOG_INFO("default", "ModelingDefault ComputerOverlapDirection Input Direction Error");
		return INFO_FAIL;
	}

	// 初始化标记位
	int flag = 0;

	// 对tile进行循环 
	for (std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>::iterator it = tileMap.begin(); it != tileMap.end(); ++it)
	{
		// 取出行列
		int j = it->first._col;
		int i = it->first._row;
		// 收集水平方向 上右下左
		std::shared_ptr<Tile>& tile = it->second;

		// 三道过滤，分别是ncc,有效范围和正交误差，此处ncc过滤掉会改成2， 有效范围过滤会改成3， 正交误差过滤会改成4
		flag = FilterDirection(direction, tile, tMin, tMax, overlapError);
		if (flag < 0)
		{
			LOG_INFO("default", "ModelingDefault SetValidTile Call IsValidTile Error");
			return INFO_FAIL;
		}
	}


	// 用四分位数法过滤
	flag = QuartileFilterDirection(direction, tileMap);

	int directionId = -1;
	if ("UP" == direction)
	{
		directionId = 0;
	}
	if ("RIGHT" == direction)
	{
		directionId = 1;
	}
	if ("DOWN" == direction)
	{
		directionId = 2;
	}
	if ("LEFT" == direction)
	{
		directionId = 3;
	}



	// 统计有效率，这里计算总的数据个数，与有效数据个数
	// 统计总的个数
	int tileCount = 0;

	for (std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>::iterator it = tileMap.begin(); it != tileMap.end(); ++it)
	{
		// 取出行列
		int j = it->first._col;
		int i = it->first._row;
		// 收集水平方向 上右下左
		std::shared_ptr<Tile>& tile = it->second;
		// 总体个数
		if (tile->matchFlags[directionId] > 0)
		{
			tileCount = tileCount + 1;
		}
		// 有效个数
		if (tile->matchFlags[directionId] == 1)
		{
			validCount = validCount + 1;
		}
	}

	// 计算有效率
	float valid_perc = 100 * float(validCount) / float(tileCount);

	return INFO_OK;
}


// 三道过滤，分别是ncc,有效范围和正交误差，此处ncc过滤掉会改成2， 有效范围过滤会改成3， 正交误差过滤会改成4
int ModelingDefault::FilterDirection(const std::string direction, std::shared_ptr<Tile>& tile, const float tMin, const float tMax, const float overlapError)
{
	// 函数作用：根据方向做三道过滤，分别是ncc过滤，有效范围过滤，正交误差过滤
	// 输入
	// direction为方向
	// tMin为偏移下界
	// tMax为偏移上界
	// overlapError为重叠误差
	// 输出
	// tileMap为各图像信息

	// 输入防呆
	// 判断输入
	if ((direction != "UP") && (direction != "RIGHT") && (direction != "DOWN") && (direction != "LEFT"))
	{
		LOG_INFO("default", "ModelingDefault ComputerOverlapDirection Input Direction Error");
		return INFO_FAIL;
	}

	float ncc = 0.0;
	float x = 0.0;
	float y = 0.0;
	// 上
	if ("UP" == direction)
	{
		if (tile->matchFlags[0] == 1)
		{
			// ncc
			ncc = tile->matchInfos[0].precison;
			// x比较小
			x = tile->matchInfos[0].offset.x;
			// y为较大的负值
			y = tile->matchInfos[0].offset.y;

			// ncc过滤,被ncc过滤掉，则置为2
			if (ncc < args.validCorrelationThreshold)
			{
				tile->matchFlags[0] = 2;
			}
			// 有效范围过滤
			if ((y < tMin) || (y > tMax))
			{
				tile->matchFlags[0] = 3;
			}
			// 正交方向过滤
			// 检查正交方向的平移是否在误差范围内
			if ((x < -overlapError) || (x > overlapError))
			{
				tile->matchFlags[0] = 4;
			}
		}
	}
	// 右
	if ("RIGHT" == direction)
	{
		if (tile->matchFlags[1] == 1)
		{
			// ncc
			ncc = tile->matchInfos[1].precison;
			// x为较大的正值
			x = tile->matchInfos[1].offset.x;
			// y为较小
			y = tile->matchInfos[1].offset.y;
			// ncc过滤,被ncc过滤掉，则置为2
			if (ncc < args.validCorrelationThreshold)
			{
				tile->matchFlags[1] = 2;
			}
			// 有效范围过滤
			if ((x < tMin) || (x > tMax))
			{
				tile->matchFlags[1] = 3;
			}
			// 正交方向过滤
			// 检查正交方向的平移是否在误差范围内
			if ((y < -overlapError) || (y > overlapError))
			{
				tile->matchFlags[1] = 4;
			}
		}
	}
	// 下
	if ("DOWN" == direction)
	{
		if (tile->matchFlags[2] == 1)
		{
			// ncc
			ncc = tile->matchInfos[2].precison;
			// x比较小
			x = tile->matchInfos[2].offset.x;
			// y为较大的正值
			y = tile->matchInfos[2].offset.y;
			// ncc过滤,被ncc过滤掉，则置为2
			if (ncc < args.validCorrelationThreshold)
			{
				tile->matchFlags[2] = 2;
			}
			// 有效范围过滤
			if ((y < tMin) || (y > tMax))
			{
				tile->matchFlags[2] = 3;
			}
			// 正交方向过滤
			// 检查正交方向的平移是否在误差范围内
			if ((x < -overlapError) || (x > overlapError))
			{
				tile->matchFlags[2] = 4;
			}
		}
	}
	// 左
	if ("LEFT" == direction)
	{
		if (tile->matchFlags[3] == 1)
		{
			// ncc
			ncc = tile->matchInfos[3].precison;
			// x为较大的负值
			x = tile->matchInfos[3].offset.x;
			// y为较小
			y = tile->matchInfos[3].offset.y;
			// ncc过滤,被ncc过滤掉，则置为2
			if (ncc < args.validCorrelationThreshold)
			{
				tile->matchFlags[3] = 2;
			}
			// 有效范围过滤
			if ((x < tMin) || (x > tMax))
			{
				tile->matchFlags[3] = 3;
			}
			// 正交方向过滤
			// 检查正交方向的平移是否在误差范围内
			if ((y < -overlapError) || (y > overlapError))
			{
				tile->matchFlags[3] = 4;
			}
		}
	}

	return INFO_OK;

}

// 用4分位数法过滤有效值
int ModelingDefault::QuartileFilterDirection(const std::string direction, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap)
{
	// 函数作用：用四分位数法过滤有效值
	// 输入
	// direction为方向
	// 输出
	// tileMap为各图像信息

	// 输入防呆
	// 判断输入
	if ((direction != "UP") && (direction != "RIGHT") && (direction != "DOWN") && (direction != "LEFT"))
	{
		LOG_INFO("default", "ModelingDefault ComputerOverlapDirection Input Direction Error");
		return INFO_FAIL;
	}

	// 初始化标记位
	int flag = 0;

	// 1. y方向
	flag = LclFilterDirection(direction, tileMap, "y");
	// 2. x方向
	flag = LclFilterDirection(direction, tileMap, "x");

	return INFO_OK;

}


// 几个各方向的异常值过滤
int ModelingDefault::LclFilterDirection(const std::string direction, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, const std::string displacement)
{
	// 函数作用：几个各方向的异常值过滤
	// 输入
	// direction为方向
	// tileMap为各图像信息
	// displacement为具体方向

	// 输入防呆
	// 判断输入
	if ((direction != "UP") && (direction != "RIGHT") && (direction != "DOWN") && (direction != "LEFT"))
	{
		LOG_INFO("default", "ModelingDefault ComputerOverlapDirection Input Direction Error");
		return INFO_FAIL;
	}
	if ((displacement != "x") && (displacement != "y"))
	{
		LOG_INFO("default", "ModelingDefault LclFilter Input Displacement Error");
		return INFO_FAIL;
	}

	// 初始化标记位
	int flag = 0;

	// 初始化有效值
	std::vector<int32_t> tVals;

	// 提取有效值
	flag = ExtractValsDirection(tileMap, direction, displacement, tVals);
	if (flag < 0)
	{
		LOG_INFO("default", "ModelingDefault LclFilterDirection Call ExtractValsDirection Error");
		return INFO_FAIL;
	}

	// 初始化中位数
	float medianData = 0;
	// 初始化上四分位数
	float upQuartileData = 0;
	// 初始化下四分位数
	float downQuartileData = 0;
	// 初始化四分位距
	float quartileDistance = 0;

	// 计算中位数和四分位数
	flag = ComputeFilterParametersDirection(tVals, medianData, upQuartileData, downQuartileData, quartileDistance);
	if (flag == 2)
	{
		// 如果是上下分为数较少，则直接返回
		return INFO_OK;
	}
	if (flag < 0)
	{
		LOG_INFO("default", "ModelingDefault LclFilterDirection Call ComputeFilterParametersDirection Error");
		return INFO_FAIL;
	}

	// 对异常值进行过滤
	for (std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>::iterator it = tileMap.begin(); it != tileMap.end(); ++it)
	{
		// 取出行列
		int j = it->first._col;
		int i = it->first._row;
		// 收集水平方向 上右下左
		std::shared_ptr<Tile>& tile = it->second;
		// 判断方向
		int directionId = -1;
		if ("UP" == direction)
		{
			directionId = 0;
		}
		if ("RIGHT" == direction)
		{
			directionId = 1;
		}
		if ("DOWN" == direction)
		{
			directionId = 2;
		}
		if ("LEFT" == direction)
		{
			directionId = 3;
		}

		// x
		if ("x" == displacement)
		{
			float x = (float)(tile->matchInfos[directionId].offset.x);
			if ((x < upQuartileData - weight * quartileDistance) || (x > downQuartileData + weight * quartileDistance))
			{
				tile->matchFlags[directionId] = 5;
			}
		}
		if ("y" == displacement)
		{
			float y = (float)(tile->matchInfos[directionId].offset.y);
			if ((y < upQuartileData - weight * quartileDistance) || (y > downQuartileData + weight * quartileDistance))
			{
				tile->matchFlags[directionId] = 5;
			}
		}
	}

	return INFO_OK;

}

// 对某个方向的数据进行有效值收集
int ModelingDefault::ExtractValsDirection(std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, const std::string direction, const std::string displacement, std::vector<int32_t>& tVals)
{
	// 函数作用：对某个方向的数据进行有效值收集
	// 输入
	// direction为
	// tileMap为各图像的信息
	// orientation为各具体方向
	// displacement为x方向或者y方向
	// 输出
	// tVals为有效值

	for (std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>::iterator it = tileMap.begin(); it != tileMap.end(); ++it)
	{
		// 取出行列
		int j = it->first._col;
		int i = it->first._row;
		// 收集水平方向
		const std::shared_ptr<Tile>& tile = it->second;
		// 上
		if ("UP" == direction)
		{
			if (displacement == "x")
			{
				tVals.push_back(tile->matchInfos[0].offset.x);
			}
			else
			{
				tVals.push_back(tile->matchInfos[0].offset.y);
			}
		}
		// 右
		if ("RIGHT" == direction)
		{
			if (displacement == "x")
			{
				tVals.push_back(tile->matchInfos[1].offset.x);
			}
			else
			{
				tVals.push_back(tile->matchInfos[1].offset.y);
			}
		}
		// 下
		if ("DOWN" == direction)
		{
			if (displacement == "x")
			{
				tVals.push_back(tile->matchInfos[2].offset.x);
			}
			else
			{
				tVals.push_back(tile->matchInfos[2].offset.y);
			}
		}
		// 左
		if ("LEFT" == direction)
		{
			if (displacement == "x")
			{
				tVals.push_back(tile->matchInfos[3].offset.x);
			}
			else
			{
				tVals.push_back(tile->matchInfos[3].offset.y);
			}
		}
	}

	return INFO_OK;

}

// 计算中位数和四分位数
int ModelingDefault::ComputeFilterParametersDirection(const std::vector<int32_t> tVals, float& medianData, float& upQuartileData, float& downQuartileData, float& quartileDistance)
{
	// 函数作用：计算中位数、四分位数和四分位距
	// 输入
	// tVals为偏移量集合
	// 输出
	// medianData为中位数
	// upQuartileData为上四分位数
	// downQuartileData为下四分位数
	// quartileDistance四分位距

	// 初始化标记为
	int flag = 0;

	// 初始化中位数
	medianData = 0;
	flag = Median(tVals, medianData);
	if (flag < 0)
	{
		LOG_INFO("default", "ModelingDefault ComputeFilterParameters Call Median Error");
		return INFO_FAIL;
	}

	// 把值分为小于中位数和大于中位数两个数列
	std::vector<int32_t> lessThan;
	std::vector<int32_t> greaterThan;
	for (int32_t tValsId = 0; tValsId < tVals.size(); tValsId++)
	{
		if (tVals[tValsId] < medianData)
		{
			lessThan.push_back(tVals[tValsId]);
		}
		if (tVals[tValsId] > medianData)
		{
			greaterThan.push_back(tVals[tValsId]);
		}
	}

	if ((lessThan.size() < 3) || (greaterThan.size() < 3))
	{
		LOG_INFO("default", "ModelingDefault ComputeFilterParameters LessThan Or GreaterThan less");
		return 2;
	}

	// 计算上四分位
	upQuartileData = 0;
	flag = Median(lessThan, upQuartileData);
	if (flag < 0)
	{
		LOG_INFO("default", "ModelingDefault ComputeFilterParameters Call Median Error");
		return INFO_FAIL;
	}

	// 计算下四分位
	downQuartileData = 0;
	Median(greaterThan, downQuartileData);
	if (flag < 0)
	{
		LOG_INFO("default", "ModelingDefault ComputeFilterParameters Call Median Error");
		return INFO_FAIL;
	}

	// 计算四分位距
	quartileDistance = abs(upQuartileData - downQuartileData);

	return INFO_OK;
}

// 计算平台精度1
int ModelingDefault::repeatabilityOneDirection(const std::string direction, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, float& repeatability)
{
	// 函数作用：计算各方向的平台精度1
	// 输入
	// direction为方向
	// tileMap为各图像模块信息
	// 输出
	// repeatability为平台精度

	// 输入防呆
	// 判断输入
	if ((direction != "UP") && (direction != "RIGHT") && (direction != "DOWN") && (direction != "LEFT"))
	{
		LOG_INFO("default", "ModelingDefault repeatabilityOneDirection Input Direction Error");
		return INFO_FAIL;
	}

	// 初始化标记位
	int flag = 0;

	// 初始化
	float tOrthogonalValsMax = -FLT_MAX;
	float tOrthogonalValsMin = FLT_MAX;
	// 对tile进行循环 
	for (std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>::iterator it = tileMap.begin(); it != tileMap.end(); ++it)
	{
		// 取出行列
		int j = it->first._col;
		int i = it->first._row;
		// 收集水平方向 上右下左
		std::shared_ptr<Tile>& tile = it->second;
		// 上测数据
		if ("UP" == direction)
		{
			if (tile->matchFlags[0] == 1)
			{
				// 求最大值
				if (tile->matchInfos[0].offset.x > tOrthogonalValsMax)
				{
					tOrthogonalValsMax = (float)(tile->matchInfos[0].offset.x);
				}
				// 求最小值
				if (tile->matchInfos[0].offset.x < tOrthogonalValsMin)
				{
					tOrthogonalValsMin = (float)(tile->matchInfos[0].offset.x);
				}
			}
		}
		// 右侧数据
		if ("RIGHT" == direction)
		{
			if (tile->matchFlags[1] == 1)
			{
				// 求最大值
				if (tile->matchInfos[1].offset.y > tOrthogonalValsMax)
				{
					tOrthogonalValsMax = (float)(tile->matchInfos[1].offset.y);
				}
				// 求最小值
				if (tile->matchInfos[1].offset.y < tOrthogonalValsMin)
				{
					tOrthogonalValsMin = (float)(tile->matchInfos[1].offset.y);
				}
			}
		}
		// 下测数据
		if ("DOWN" == direction)
		{
			if (tile->matchFlags[2] == 1)
			{
				// 求最大值
				if (tile->matchInfos[2].offset.x > tOrthogonalValsMax)
				{
					tOrthogonalValsMax = (float)(tile->matchInfos[2].offset.x);
				}
				// 求最小值
				if (tile->matchInfos[2].offset.x < tOrthogonalValsMin)
				{
					tOrthogonalValsMin = (float)(tile->matchInfos[2].offset.x);
				}
			}
		}
		// 左侧数据
		if ("LEFT" == direction)
		{
			if (tile->matchFlags[3] == 1)
			{
				// 求最大值
				if (tile->matchInfos[3].offset.y > tOrthogonalValsMax)
				{
					tOrthogonalValsMax = (float)(tile->matchInfos[3].offset.y);
				}
				// 求最小值
				if (tile->matchInfos[3].offset.y < tOrthogonalValsMin)
				{
					tOrthogonalValsMin = (float)(tile->matchInfos[3].offset.y);
				}
			}
		}
	}
	// 计算平台精度
	repeatability = std::ceil((tOrthogonalValsMax - tOrthogonalValsMin) / 2.0);

	return INFO_OK;

}

// 计算平台精度2
int ModelingDefault::repeatabilityTwoDirection(const std::string direction, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, float& repeatability)
{
	// 函数作用：从行列中取平台精度
	// 输入
	// direction为方向
	// tileMap为图像信息
	// 输出
	// repeatability为平台精度

	// 输入防呆
	// 判断输入
	if ((direction != "UP") && (direction != "RIGHT") && (direction != "DOWN") && (direction != "LEFT"))
	{
		LOG_INFO("default", "ModelingDefault repeatabilityTwoDirection Input Direction Error");
		return INFO_FAIL;
	}

	// 初始化标记位
	int flag = 0;

	// 用哈希表做行和列
	std::unordered_map<int, float> minTile;
	std::unordered_map<int, float> maxTile;
	// 进行循环，初始化
	for (std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>::iterator it = tileMap.begin(); it != tileMap.end(); ++it)
	{
		// 取出行列
		int j = it->first._col;
		int i = it->first._row;
		// 收集水平方向 上右下左
		std::shared_ptr<Tile>& tile = it->second;
		if ("UP" == direction)
		{
			// 上
			if (tile->matchFlags[0] == 1)
			{
				minTile[i] = FLT_MAX;
				maxTile[i] = -FLT_MAX;
			}
		}
		if ("RIGHT" == direction)
		{
			// 右
			if (tile->matchFlags[1] == 1)
			{
				minTile[j] = FLT_MAX;
				maxTile[j] = -FLT_MAX;
			}
		}
		if ("DOWN" == direction)
		{
			// 下
			if (tile->matchFlags[2] == 1)
			{
				minTile[i] = FLT_MAX;
				maxTile[i] = -FLT_MAX;
			}
		}
		if ("LEFT" == direction)
		{
			// 左
			if (tile->matchFlags[3] == 1)
			{
				minTile[j] = FLT_MAX;
				maxTile[j] = -FLT_MAX;
			}
		}
	}

	// 求每个行列的最大值和最小值
	for (std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>::iterator it = tileMap.begin(); it != tileMap.end(); ++it)
	{
		// 取出行列
		int j = it->first._col;
		int i = it->first._row;
		// 收集水平方向 上右下左
		std::shared_ptr<Tile>& tile = it->second;
		// 上
		if ("UP" == direction)
		{
			// 上
			if (tile->matchFlags[0] == 1)
			{
				// 更新最大值
				if (tile->matchInfos[0].offset.y > maxTile[i])
				{
					maxTile[i] = (float)(tile->matchInfos[0].offset.y);
				}
				// 更新最小值
				if (tile->matchInfos[0].offset.y < minTile[i])
				{
					minTile[i] = (float)(tile->matchInfos[0].offset.y);
				}
			}
		}
		// 右
		if ("RIGHT" == direction)
		{
			// 右
			if (tile->matchFlags[1] == 1)
			{
				// 更新最大值
				if (tile->matchInfos[1].offset.x > maxTile[j])
				{
					maxTile[j] = (float)(tile->matchInfos[1].offset.x);
				}
				// 更新最小值
				if (tile->matchInfos[1].offset.x < minTile[j])
				{
					minTile[j] = (float)(tile->matchInfos[1].offset.x);
				}
			}
		}
		// 下
		if ("DOWN" == direction)
		{
			if (tile->matchFlags[2] == 1)
			{
				// 更新最大值
				if ((float)(tile->matchInfos[2].offset.y) > maxTile[i])
				{
					maxTile[i] = (float)(tile->matchInfos[2].offset.y);
				}
				// 更新最小值
				if ((float)(tile->matchInfos[2].offset.y) < minTile[i])
				{
					minTile[i] = (float)(tile->matchInfos[2].offset.y);
				}
			}
		}
		// 左
		if ("LEFT" == direction)
		{
			if (tile->matchFlags[3] == 1)
			{
				// 更新最大值
				if (tile->matchInfos[3].offset.x > maxTile[j])
				{
					maxTile[j] = (float)(tile->matchInfos[3].offset.x);
				}
				// 更新最小值
				if (tile->matchInfos[3].offset.x < minTile[j])
				{
					minTile[j] = (float)(tile->matchInfos[3].offset.x);
				}
			}
		}
	}

	// 计算平台精度
	float repeatability2 = -FLT_MAX;
	for (std::unordered_map<int, float>::iterator it = minTile.begin(); it != minTile.end(); ++it)
	{
		int index = it->first;
		float value = 0.5*abs(float(minTile[index]) - float(maxTile[index]));
		if (value > repeatability2)
		{
			repeatability2 = value;
		}
	}
	repeatability = repeatability2;

	return INFO_OK;
}

// 在各方向上应用模型
int ModelingDefault::ApplyModelDirection(const std::string direction, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap)
{
	// 函数作用：从行列中取平台精度
	// 输入
	// direction为方向
	// tileMap为图像信息

	// 输入防呆
	// 判断输入
	if ((direction != "UP") && (direction != "RIGHT") && (direction != "DOWN") && (direction != "LEFT"))
	{
		LOG_INFO("default", "ModelingDefault repeatabilityOneDirection Input Direction Error");
		return INFO_FAIL;
	}

	// 初始化标记位
	int flag = 0;

	// 计算有效tile的个数
	int validNum = 0;
	for (std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>::iterator it = tileMap.begin(); it != tileMap.end(); ++it)
	{
		// 取出行列
		int j = it->first._col;
		int i = it->first._row;
		// 收集水平方向 上右下左
		std::shared_ptr<Tile>& tile = it->second;
		// 上
		if ("UP" == direction)
		{
			// 上
			if (tile->matchFlags[0] == 1)
			{
				validNum = validNum + 1;
			}
		}
		// 右
		if ("RIGHT" == direction)
		{
			// 右
			if (tile->matchFlags[1] == 1)
			{
				validNum = validNum + 1;
			}
		}
		// 下
		if ("DOWN" == direction)
		{
			// 下
			if (tile->matchFlags[2] == 1)
			{
				validNum = validNum + 1;
			}
		}
		// 左
		if ("LEFT" == direction)
		{
			// 下
			if (tile->matchFlags[3] == 1)
			{
				validNum = validNum + 1;
			}
		}
	}

	//std::cout << "direction: " << direction << " validNum: " << validNum << std::endl;


	// 如果没有有效值，则用重叠度进行计算
	if (validNum == 0)
	{
		flag = OverlapApplyModelDirection(direction, tileMap);
		if (flag < 0)
		{
			LOG_INFO("default", "ModelingDefault ApplyModelPerDirection Call OverlapApplyModel Error");
			return INFO_FAIL;
		}
	}
	else
	{
		// 根据方向进行过滤
		// 初始化中位数
		std::unordered_map<int, int> medXVals;
		medXVals.clear();
		std::unordered_map<int, int> medYVals;
		medYVals.clear();
		flag = FilterTranslationPerDirection(direction, tileMap, medXVals, medYVals);
		if (flag < 0)
		{
			LOG_INFO("default", "ModelingDefault ApplyModelPerDirection Call FilterTranslationPerDirection Error");
			return INFO_FAIL;
		}


		// 对行列进行填充,用中位数填充
		flag = ReplaceTranslationDirection(direction, tileMap, medXVals, medYVals);
		if (flag < 0)
		{
			LOG_INFO("default", "ModelingDefault ApplyModelPerDirection Call ReplaceTranslationDirection Error");
			return INFO_FAIL;
		}


		// 填充其余tile的数据
		flag = ReplaceOtherTranslationDirection(direction, tileMap);
		if (flag < 0)
		{
			LOG_INFO("default", "ModelingDefault ApplyModelPerDirection Call ReplaceOtherTranslation Error");
			return INFO_FAIL;
		}

	}

	return INFO_OK;
}

// 重叠度建模
int ModelingDefault::OverlapApplyModelDirection(const std::string direction, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap)
{
	// 函数作用：利用重叠度进行建模
	// 输入
	// direction为计算的方向
	// 输出
	// tileMap为各图像信息

	// 获取重叠度
	float overlap = 0;
	float h_or_w = 0;
	// 根据方向获取参数
	// 上
	if ("UP" == direction)
	{
		overlap = args.upOverlap;
		h_or_w = (float)(args.imageHeight);
	}
	// 右
	if ("RIGHT" == direction)
	{
		overlap = args.rightOverlap;
		h_or_w = (float)(args.imageWidth);
	}
	// 下
	if ("DOWN" == direction)
	{
		overlap = args.downOverlap;
		h_or_w = (float)(args.imageHeight);
	}
	// 左
	if ("LEFT" == direction)
	{
		overlap = args.leftOverlap;
		h_or_w = (float)(args.imageWidth);
	}


	// 根据重叠百分比计算非重叠部分的距离
	int estTranslation = int(float(h_or_w)*(1 - overlap / 100.0));
	// 应用建模结果
	for (std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>::iterator it = tileMap.begin(); it != tileMap.end(); ++it)
	{
		// 取出行列
		int j = it->first._col;
		int i = it->first._row;
		// 收集水平方向 上右下左
		std::shared_ptr<Tile>& tile = it->second;
		// 上
		if ("UP" == direction)
		{
			tile->matchInfos[0].precison = args.paddingNcc;
			tile->matchInfos[0].offset.y = -estTranslation;
			tile->matchInfos[0].offset.x = 0;
		}
		// 右
		if ("RIGHT" == direction)
		{
			tile->matchInfos[1].precison = args.paddingNcc;
			tile->matchInfos[1].offset.x = estTranslation;
			tile->matchInfos[1].offset.y = 0;
		}
		// 下
		if ("DOWN" == direction)
		{
			tile->matchInfos[2].precison = args.paddingNcc;
			tile->matchInfos[2].offset.y = estTranslation;
			tile->matchInfos[2].offset.x = 0;
		}
		// 左
		if ("LEFT" == direction)
		{
			// 下
			tile->matchInfos[3].precison = args.paddingNcc;
			tile->matchInfos[3].offset.x = -estTranslation;
			tile->matchInfos[3].offset.y = 0;
		}
	}

	return INFO_OK;
}


// 根据方向对有效tile集进行过滤
int ModelingDefault::FilterTranslationPerDirection(const std::string direction, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, std::unordered_map<int, int>& medXVals, std::unordered_map<int, int>& medYVals)
{
	// 函数作用：利用重叠度进行建模
	// 输入
	// direction为计算的方向
	// 输出
	// tileMap为各图像信息
	// medXVals为x方向中位数
	// medYVals为y方向中位数

	// 输入防呆
	// 判断输入
	if ((direction != "UP") && (direction != "RIGHT") && (direction != "DOWN") && (direction != "LEFT"))
	{
		LOG_INFO("default", "ModelingDefault repeatabilityOneDirection Input Direction Error");
		return INFO_FAIL;
	}

	// 初始化标记位
	int flag = 0;

	// 计算平台精度
	// 初始化平台精度
	if ("UP" == direction)
	{
		repeatability = args.upRepeatability;
	}
	if ("RIGHT" == direction)
	{
		repeatability = args.rightRepeatability;
	}
	if ("DOWN" == direction)
	{
		repeatability = args.downRepeatability;
	}
	if ("LEFT" == direction)
	{
		repeatability = args.leftRepeatability;
	}

	// 初始化每行每列有效tile
	std::unordered_map<int, std::vector<int>> xVals;
	std::unordered_map<int, std::vector<int>> yVals;

	// 对tilemap进行循环
	int key = 0;
	int directionId = -1;
	for (std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>::iterator it = tileMap.begin(); it != tileMap.end(); ++it)
	{
		// 取出行列
		int j = it->first._col;
		int i = it->first._row;
		// 收集水平方向 上右下左
		std::shared_ptr<Tile>& tile = it->second;
		if ("UP" == direction)
		{
			key = i;
			directionId = 0;
		}
		if ("RIGHT" == direction)
		{
			key = j;
			directionId = 1;
		}
		if ("DOWN" == direction)
		{
			key = i;
			directionId = 2;
		}
		if ("LEFT" == direction)
		{
			key = j;
			directionId = 3;
		}

		// 初始化Vals
		if (xVals.find(key) == xVals.end())
		{
			xVals[key] = std::vector<int>();
		}
		if (yVals.find(key) == yVals.end())
		{
			yVals[key] = std::vector<int>();
		}
		// tile数据收集
		if (tile->matchFlags[directionId] == 1)
		{
			xVals[key].push_back(tile->matchInfos[directionId].offset.x);
			yVals[key].push_back(tile->matchInfos[directionId].offset.y);
		}
	}

	// 计算中位数
	// 初始化
	float m = 0;
	for (std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>::iterator it = tileMap.begin(); it != tileMap.end(); ++it)
	{
		// 取出行列
		int j = it->first._col;
		int i = it->first._row;
		// 收集水平方向 上右下左
		std::shared_ptr<Tile>& tile = it->second;
		if ("UP" == direction)
		{
			key = i;
		}
		if ("RIGHT" == direction)
		{
			key = j;
		}
		if ("DOWN" == direction)
		{
			key = i;
		}
		if ("LEFT" == direction)
		{
			key = j;
		}
		// x
		if (xVals[key].size() > 0)
		{
			flag = Median(xVals[key], m);
			if (flag < 0)
			{
				LOG_INFO("default", "ModelingDefault FilterTranslationPerRowCol Call Median Error");
				return INFO_FAIL;
			}
			medXVals[key] = (int)m;
		}
		// y
		if (yVals[key].size() > 0)
		{
			flag = Median(yVals[key], m);
			if (flag < 0)
			{
				LOG_INFO("default", "ModelingDefault FilterTranslationPerRowCol Call Median Error");
				return INFO_FAIL;
			}
			medYVals[key] = (int)m;
		}
	}

	// 遍历，删除不符合条件的偏移量
	float x = 0.0;
	float y = 0.0;
	float ncc = 0.0;
	for (std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>::iterator it = tileMap.begin(); it != tileMap.end(); ++it)
	{
		// 取出行列
		int j = it->first._col;
		int i = it->first._row;
		// 收集水平方向 上右下左
		std::shared_ptr<Tile>& tile = it->second;
		// 获取当前下标
		if ("UP" == direction)
		{
			key = i;
		}
		if ("RIGHT" == direction)
		{
			key = j;
		}
		if ("DOWN" == direction)
		{
			key = i;
		}
		if ("LEFT" == direction)
		{
			key = j;
		}

		// 计算最值
		int xMin = float(medXVals[key]) - float(repeatability);
		int xMax = float(medXVals[key]) + float(repeatability);
		int yMin = float(medYVals[key]) - float(repeatability);
		int yMax = float(medYVals[key]) + float(repeatability);

		if ("UP" == direction)
		{
			// 上
			x = (float)(tile->matchInfos[0].offset.x);
			y = (float)(tile->matchInfos[0].offset.y);
			ncc = (float)(tile->matchInfos[0].precison);
			if ((1 == tile->matchFlags[0]) && ((ncc < args.validCorrelationThreshold) || (x < xMin) || (x > xMax) || (y < yMin) || (y > yMax)))
			{
				tile->matchFlags[0] = 6;
			}
		}
		if ("RIGHT" == direction)
		{
			// 右
			x = (float)(tile->matchInfos[1].offset.x);
			y = (float)(tile->matchInfos[1].offset.y);
			ncc = (float)(tile->matchInfos[1].precison);
			if ((1 == tile->matchFlags[1]) && ((ncc < args.validCorrelationThreshold) || (x < xMin) || (x > xMax) || (y < yMin) || (y > yMax)))
			{
				tile->matchFlags[1] = 6;
			}
		}
		if ("DOWN" == direction)
		{
			// 下
			x = (float)(tile->matchInfos[2].offset.x);
			y = (float)(tile->matchInfos[2].offset.y);
			ncc = (float)(tile->matchInfos[2].precison);
			if ((1 == tile->matchFlags[2]) && ((ncc < args.validCorrelationThreshold) || (x < xMin) || (x > xMax) || (y < yMin) || (y > yMax)))
			{
				tile->matchFlags[2] = 6;
			}
		}
		if ("LEFT" == direction)
		{
			// 左
			x = (float)(tile->matchInfos[3].offset.x);
			y = (float)(tile->matchInfos[3].offset.y);
			ncc = (float)(tile->matchInfos[3].precison);
			if ((1 == tile->matchFlags[3]) && ((ncc < args.validCorrelationThreshold) || (x < xMin) || (x > xMax) || (y < yMin) || (y > yMax)))
			{
				tile->matchFlags[3] = 6;
			}
		}
	}

	return INFO_OK;

}


// 填充有行列tile数据
int ModelingDefault::ReplaceTranslationDirection(const std::string direction, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap, std::unordered_map<int, int> medXVals, std::unordered_map<int, int> medYVals)
{
	// 函数作用：利用重叠度进行建模
	// 输入
	// direction为计算的方向
	// medXVals为该方向x的中位数
	// medYVals为该方向y的中位数
	// 输出
	// tileMap为各图像信息

	// 输入防呆
	// 判断输入
	if ((direction != "UP") && (direction != "RIGHT") && (direction != "DOWN") && (direction != "LEFT"))
	{
		LOG_INFO("default", "ModelingDefault repeatabilityOneDirection Input Direction Error");
		return INFO_FAIL;
	}

	// 对tile进行循环
	int key = 0;
	for (std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>::iterator it = tileMap.begin(); it != tileMap.end(); ++it)
	{
		// 取出行列
		int j = it->first._col;
		int i = it->first._row;
		// 收集水平方向 上右下左
		std::shared_ptr<Tile>& tile = it->second;
		// 上
		if ("UP" == direction)
		{
			key = i;
			if ((tile->matchFlags[0] != 1) && (medXVals.find(key) != medXVals.end()) && (medYVals.find(key) != medYVals.end()))
			{
				tile->matchInfos[0].precison = args.paddingNcc;
				tile->matchInfos[0].offset.x = medXVals[key];
				tile->matchInfos[0].offset.y = medYVals[key];
				tile->matchFlags[0] = args.label;
			}
		}
		// 右
		if ("RIGHT" == direction)
		{
			key = j;
			if ((tile->matchFlags[1] != 1) && (medXVals.find(key) != medXVals.end()) && (medYVals.find(key) != medYVals.end()))
			{
				tile->matchInfos[1].precison = args.paddingNcc;
				tile->matchInfos[1].offset.x = medXVals[key];
				tile->matchInfos[1].offset.y = medYVals[key];
				tile->matchFlags[1] = args.label;
			}
		}
		// 下
		if ("DOWN" == direction)
		{
			key = i;
			if ((tile->matchFlags[2] != 1) && (medXVals.find(key) != medXVals.end()) && (medYVals.find(key) != medYVals.end()))
			{
				tile->matchInfos[2].precison = args.paddingNcc;
				tile->matchInfos[2].offset.x = medXVals[key];
				tile->matchInfos[2].offset.y = medYVals[key];
				tile->matchFlags[2] = args.label;
			}
		}
		// 左
		if ("LEFT" == direction)
		{
			key = j;
			if ((tile->matchFlags[3] != 1) && (medXVals.find(key) != medXVals.end()) && (medYVals.find(key) != medYVals.end()))
			{
				tile->matchInfos[3].precison = args.paddingNcc;
				tile->matchInfos[3].offset.x = medXVals[key];
				tile->matchInfos[3].offset.y = medYVals[key];
				tile->matchFlags[3] = args.label;
			}
		}
	}

	return INFO_OK;

}


// 填充其余tile的数据
int ModelingDefault::ReplaceOtherTranslationDirection(const std::string direction, std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>& tileMap)
{
	// 函数作用：填充其余tile的数据
	// 输入
	// direction为计算的方向
	// 输出
	// tileMap为各图像信息

	// 输入防呆
	// 判断输入
	if ((direction != "UP") && (direction != "RIGHT") && (direction != "DOWN") && (direction != "LEFT"))
	{
		LOG_INFO("default", "ModelingDefault repeatabilityOneDirection Input Direction Error");
		return INFO_FAIL;
	}

	// 初始化
	int flag = 0;

	// 计算重叠率
	float overlap = 0;
	int h_or_w = 0;
	// 获取该方向的重叠率
	// 上
	if ("UP" == direction)
	{
		overlap = args.upOverlap;
		h_or_w = args.imageHeight;
	}
	// 右
	if ("RIGHT" == direction)
	{
		overlap = args.rightOverlap;
		h_or_w = args.imageWidth;
	}
	// 上
	if ("DOWN" == direction)
	{
		overlap = args.downOverlap;
		h_or_w = args.imageHeight;
	}
	// 左
	if ("LEFT" == direction)
	{
		overlap = args.leftOverlap;
		h_or_w = args.imageWidth;
	}


	// 计算有效值的个数
	int valNumber = 0;
	// 均值
	int directionOfTravelEstimate = 0;
	std::vector<int> estimateList;
	estimateList.clear();
	// 循环
	for (std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>::iterator it = tileMap.begin(); it != tileMap.end(); ++it)
	{
		// 取出行列
		int j = it->first._col;
		int i = it->first._row;
		// 收集水平方向 上右下左
		std::shared_ptr<Tile>& tile = it->second;
		// 判断是否是有效数据
		// 上
		if ("UP" == direction)
		{
			if ((tile->matchFlags[0] == 1) && (abs(tile->matchInfos[0].precison) < args.finite))
			{
				estimateList.push_back(tile->matchInfos[0].offset.y);
				valNumber = valNumber + 1;
			}
		}
		// 右
		if ("RIGHT" == direction)
		{
			if ((tile->matchFlags[1] == 1) && (abs(tile->matchInfos[1].precison) < args.finite))
			{
				estimateList.push_back(tile->matchInfos[1].offset.x);
				valNumber = valNumber + 1;
			}
		}
		// 下
		if ("DOWN" == direction)
		{
			if ((tile->matchFlags[2] == 1) && (abs(tile->matchInfos[2].precison) < args.finite))
			{
				estimateList.push_back(tile->matchInfos[2].offset.y);
				valNumber = valNumber + 1;
			}
		}
		// 左
		if ("LEFT" == direction)
		{
			if ((tile->matchFlags[3] == 1) && (abs(tile->matchInfos[3].precison) < args.finite))
			{
				estimateList.push_back(tile->matchInfos[3].offset.x);
				valNumber = valNumber + 1;
			}
		}
	}

	// 判断有效集的个数
	if (valNumber > 0)
	{
		float m = 0;
		flag = Median(estimateList, m);
		if (flag < 0)
		{
			LOG_INFO("default", "ModelingDefault FilterTranslationPerRowCol Call Median Error");
			return INFO_FAIL;
		}
		directionOfTravelEstimate = int(m);
	}
	else
	{
		overlap = 1.0 - overlap / 100.0;
		directionOfTravelEstimate = int(float(h_or_w * overlap));
	}

	for (std::unordered_map<Position, std::shared_ptr<Tile>, Position::Hash>::iterator it = tileMap.begin(); it != tileMap.end(); ++it)
	{
		// 取出行列
		int j = it->first._col;
		int i = it->first._row;
		// 收集水平方向 上右下左
		std::shared_ptr<Tile>& tile = it->second;
		// 上
		if ("UP" == direction)
		{
			if (tile->matchFlags[0] > 1)
			{
				tile->matchInfos[0].precison = args.paddingNcc;
				tile->matchInfos[0].offset.y = directionOfTravelEstimate;
				tile->matchInfos[0].offset.x = 0;
			}
		}
		// 右
		if ("RIGHT" == direction)
		{
			if (tile->matchFlags[1] > 1)
			{
				tile->matchInfos[1].precison = args.paddingNcc;
				tile->matchInfos[1].offset.y = 0;
				tile->matchInfos[1].offset.x = directionOfTravelEstimate;
			}
		}
		// 下
		if ("DOWN" == direction)
		{
			if (tile->matchFlags[2] > 1)
			{
				tile->matchInfos[2].precison = args.paddingNcc;
				tile->matchInfos[2].offset.y = directionOfTravelEstimate;
				tile->matchInfos[2].offset.x = 0;
			}
		}
		// 左
		if ("LEFT" == direction)
		{
			if (tile->matchFlags[3] > 1)
			{
				tile->matchInfos[3].precison = args.paddingNcc;
				tile->matchInfos[3].offset.y = 0;
				tile->matchInfos[3].offset.x = directionOfTravelEstimate;
			}
		}
	}


	return INFO_OK;

}


// 随机生成起始点
int ModelingDefault::GetRandomPoint(MlePoint& point)
{
	// 用于获取随机数种子
	std::random_device rd;
	// 以rd()作为种子的Mersenne Twister生成器
	std::mt19937 gen(rd());

	// 定义随机数分布范围
	std::uniform_int_distribution<> dis_p(0, 99);
	std::uniform_int_distribution<> dis_m(1, 99);
	std::uniform_int_distribution<> dis_s(1, 99);

	// 生成随机数
	int p = dis_p(gen);
	int m = dis_m(gen);
	int s = dis_s(gen);

	float l = -FLT_MAX;

	// 赋值
	point.piUni = p;
	point.mu = m;
	point.sigma = s;
	point.likelihood = l;

	return 1;
}


// 计算爬坡的值
int ModelingDefault::computeLikelihood(MlePoint& point, std::vector<float> translations)
{
	// 根据模型参数和一组平移量计算MLE模型的似然值。
	// 模型参数以平移量范围的百分比值表示。

	// point (MlePoint): 用于计算似然值的MLE控制模型。
	// translations(np.ndarray) : 需要拟合模型的平移量数组，必须在[0, 100]范围内。



	// w_or_h设置为100.0，可能代表平移量的范围宽度或高度（此处为归一化后的[0,100]范围）
	float wOrH = 100.0;
	// 初始化似然值为负无穷大，用于后续比较和更新
	point.likelihood = -FLT_MAX;

	// 检查point的pi_uni属性是否在有效范围内[0, 100)
	if ((point.piUni >= 0) && (point.piUni < 100))
	{
		point.likelihood = 0;
		// 将pi_uni从百分比转换为小数形式，便于后续计算
		float p = float(point.piUni) / 100.0;
		// 复制translations数组，避免修改原始数据
		std::vector<float> ts;
		ts.clear();
		ts.resize(translations.size());
		for (int32_t translationsId = 0; translationsId < translations.size(); translationsId++)
		{
			// 根据MLE模型的参数对平移量进行标准化处理
			ts[translationsId] = (float(translations[translationsId]) - float(point.mu)) / float(point.sigma);
			// 计算标准化后的平移量的高斯分布概率密度函数值
			ts[translationsId] = std::exp(-0.5*ts[translationsId] * ts[translationsId]);
			// 将高斯分布的概率密度函数值除以标准差的根号乘以根号(2*pi)的倒数，得到正态分布的概率密度
			ts[translationsId] = ts[translationsId] / (sqrt(2 * args.pi)*point.sigma);
			// 根据pi_uni的值混合均匀分布和高斯分布的概率密度函数值
			// 这里假设pi_uni对应的比例p代表选择均匀分布的概率，1-p代表选择高斯分布的概率
			ts[translationsId] = (p / wOrH) + (1.0 - p)*ts[translationsId];
			// 对混合后的概率密度函数值取对数，以便求和计算似然值
			// 注意：这里取绝对值可能是为了避免对数运算中的负无穷或零值问题，但在这个上下文中取绝对值可能不太合适，
			// 因为概率密度函数值应该是非负的。如果ts中存在负数，这可能意味着计算过程中有错误。
			ts[translationsId] = std::log(std::fabs(ts[translationsId]));
			// 计算所有平移量的对数概率密度之和，得到似然值
			point.likelihood = point.likelihood + ts[translationsId];
		}
	}

	return 1;
}


// 计算中位数
int ModelingDefault::Median(const std::vector<int> tVals, float& medianData)
{
	// 函数作用：计算中位数
	// 输入
	// tVals为有效数据的数列
	// 输出
	// medianData为中位数

	// 判断tVals是否为空
	if (tVals.size() == 0)
	{
		LOG_INFO("default", "ModelingDefault Median tVals Is Zeros");
		return INFO_FAIL;
	}

	// 拷贝
	std::vector<int> sorted_vals = tVals;
	// 排序
	std::sort(sorted_vals.begin(), sorted_vals.end());
	// 获取个数
	size_t n = sorted_vals.size();
	// 如果是偶数
	if (n % 2 == 0)
	{
		medianData = (float(sorted_vals[n / 2 - 1]) + float(sorted_vals[n / 2])) / 2.0;
		return INFO_OK;
	}
	else
	{
		medianData = float(sorted_vals[n / 2]);
		return INFO_OK;
	}
}
