﻿#include "stitchApp.h"
#include "errorInfo.h"
#include <nlohmann/json.hpp>
#include <filesystem>
namespace fs = std::filesystem;

StitchApp::StitchApp(const StitchConfig& params): _params(params)
{

}

StitchApp::~StitchApp()
{
	if (ptr_Mapping != nullptr)
	{
		clearMappingImg(&ptr_Mapping, _mappingFileDir);
	}
}

int StitchApp::init() 
{
	//注册所有模块类
	registerClass();

	//初始化 tileProducer
	std::string sTileProducerType = std::to_string(int(_params.tileProducerType));
	tileProducer = factory<TileProducerDefault>::produce_shared(sTileProducerType);
	if (tileProducer == nullptr) 
	{
		std::string msg = "TileProducerType:" + sTileProducerType  + " 模块未注册！";
		LOG_INFO("default", msg);
		return -1;
	}
	tileProducer->setStitchConfig(_params);
	ConfigManager& configMan = ConfigManager::getInstance();
	//是否使用config.json控制参数
	bool configInit= configMan.getField("initParams", false);
	if (configInit == true)
	{
		int pathPlaneType = configMan.getField("pathPlaneType", 1);
		int blendType = configMan.getField("blendType", 0);
		_params.pathPlanningType = static_cast<PathPlanningType>(pathPlaneType);
		_params.stitchBlenderType = static_cast<StitchBlenderType>(blendType);
	}
	//初始化 taskProducer
	std::string sTaskProducerType = std::to_string(int(_params.taskProducerType));
	taskProducer = factory<TaskProducerDefault>::produce_shared(sTaskProducerType);
	if (taskProducer == nullptr) 
	{
		std::string msg = "TaskProducerType:" + sTaskProducerType + " 模块未注册！";
		LOG_INFO("default", msg);
		return -2;
	}

	//初始化 taskConsumers
	std::string sTaskConsumerType = std::to_string(int(_params.taskConsumerType));
	for (int i = 0; i < _params.matchTaskConsumerNum; ++i)
	{
		std::shared_ptr<TaskConsumerDefault> consumer = factory<TaskConsumerDefault>::produce_shared(sTaskConsumerType);
		if (consumer == nullptr)
		{
			std::string msg = "TaskConsumerType:" + sTaskConsumerType + " 模块未注册";
			LOG_INFO("default", msg);
			return -3;
		}

		consumer->setId(i);
		consumer->setConfig(_params);
		taskConsumers.emplace_back(consumer);
		taskConsumerThreads.emplace_back(&StitchApp::taskConsumeFunc, this, consumer);
	}

	//初始化 taskQueue，设置taskQueue最大数据量
	taskQueue.setMaxQueueSize(_params.maxTaskQueueSize);


	//初始化platformModel 模块
	std::string sPlatformModelType = std::to_string(int(_params.platformModelType));
	platformModelObj = factory<ModelingDefault>::produce_shared(sPlatformModelType);

	//初始化 pathPlaning 模块
	std::string sPathPlanningType = std::to_string(int(_params.pathPlanningType));
	pathPlannObj = factory<PathPlanningDefault>::produce_shared(sPathPlanningType);

	//初始化内存映射文件
	if (!_params.storeInMemory) 
	{
		LOG_INFO("default", "Init Memory Mapping File - Start");
		SInitMapParams mapParams;
		_mappingFileDir = _params._mappingFileDir;
		mapParams.iHeight =_params.imageHeight;
		mapParams.iWidth = _params.imageWidth;
		mapParams.iImgChannel = _params.imageChannels;
		mapParams.iMapCap = 50;
		mapParams.iCacheCap = 50;
		mapParams.sSaveFile = _mappingFileDir;
		int resFlag = initMappingClass(&ptr_Mapping, mapParams);
		if (resFlag != 1)
		{
			return INFO_FAIL;
		}
		//LOG_INFO("default", "Init Memory Mapping File - Successed");
		//std::string mapCapStr = "iMapCap: " + std::to_string(mapParams.iMapCap) + "iCacheCap: "+ std::to_string(mapParams.iCacheCap);
		//LOG_INFO("default", mapCapStr);
	}

	//初始化blender
	std::string sStitchBlenderType = std::to_string(int(_params.stitchBlenderType));
	blenderObj = factory<BlenderDefault>::produce_shared(sStitchBlenderType);

	//初始化质量评价evaluate
	std::string sStitchEvaluateType = std::to_string(int(_params.stitchEvaluateType));
	evaluateObj = factory<CEvaluateDefault>::produce_shared(sStitchEvaluateType);
	//
	
	tileMap.storeOrNot = configMan.getField("saveImgData", false);
	//保存图像开启,需要软件端和算法的config.json文件联合控制
	if (_params.cacheDir != "" && tileMap.storeOrNot == true)
	{
		//保存图像文件的临时地址
		std::string defaultSavePath = "D://tempImgs//";
		_params.cacheDir = configMan.getField("saveImgPath", defaultSavePath);
		//根据时间构建文件夹保存拼接图像数据
		auto now = std::chrono::system_clock::now();
		auto timestamp = std::chrono::system_clock::to_time_t(now);
		// 将时间戳转换为 std::tm 结构
		std::tm* tm = std::localtime(&timestamp);
		// 格式化时间为字符串
		char bufferStrTime[100];
		std::strftime(bufferStrTime, sizeof(bufferStrTime), "%d-%H-%M-%S", tm);
		_params.cacheDir = _params.cacheDir + bufferStrTime;
		fs::path savePath = _params.cacheDir;
		if (!fs::exists(savePath))
		{
			if (!fs::create_directories(savePath))
			{
				LOG_ERROR("default", "fs::create_directory(_params.cacheDir) Error");
			}
		}
	}
	if (_params.cacheDir != "")
	{
		LOG_INFO("default", "cacheDir:" + _params.cacheDir);
		saveConfig(_params.cacheDir);
	}
	return 1;
}

int StitchApp::init(const std::string& cacheDir, const std::string& processType) 
{
	int flag = loadConfig(cacheDir);
	if (flag != 1)
	{
		return flag;
	}
	if (processType != "begin" && processType != "pathPlanning" && processType != "refineMatch" &&  processType != "blender" && processType != "platformModel")
	{
		LOG_INFO("default", "processType must be one of begin, platformModel,  refineMatch, pathPlanning, or blender.");
		return INFO_FAIL;
	}
	_params.storeInMemory = true;

	if (processType == "begin") 
	{
		
		this->init();
		return INFO_OK;
	}

	//注册所有模块类
	registerClass();
	flag = loadTileMap(cacheDir, processType);
	
	//初始化platformModel 模块
	std::string sPlatformModelType = std::to_string(int(_params.platformModelType));
	platformModelObj = factory<ModelingDefault>::produce_shared(sPlatformModelType);

	//初始化 pathPlaning 模块
	std::string sPathPlanningType = std::to_string(int(_params.pathPlanningType));
	pathPlannObj = factory<PathPlanningDefault>::produce_shared(sPathPlanningType);

	//初始化blender
	std::string sStitchBlenderType = std::to_string(int(_params.stitchBlenderType));
	blenderObj = factory<BlenderDefault>::produce_shared(sStitchBlenderType);

	//如果是"refineMatch", "platformModel" 加载finish task
	if (processType == "refineMatch" || processType == "platformModel")
	{
		flag = loadFinishedTaskVec(cacheDir);
	}

	return flag;
}


int StitchApp::postImage(const cv::Mat& input, const Position & world_coor)
{
	//LOG_INFO("default", "postImage Begin!");
	if (input.empty())
	{
		return INFO_FAIL;
	}

	std::shared_ptr<Tile> tile = tileProducer->tileProduce(ptr_Mapping);
	tile->saveMat(input, world_coor);
	cv::Mat t = tile->getMat();

	auto result = tileMap.insert(world_coor , tile, _params.cacheDir);

	if (!result.second)
	{
		return INFO_FAIL;
	}
	float horizontalOverlap = _params.horizontalOverlap;
	float verticalOverlap = _params.verticalOverlap;
	int image_width = _params.imageWidth;
	int image_height = _params.imageHeight;
	cv::Point platformDeviationCoor;
	platformDeviationCoor.x = horizontalOverlap * image_width * _params.overlapUncertainty / 100;
	platformDeviationCoor.y = verticalOverlap * image_height * _params.overlapUncertainty / 100;

	for (int i = -1; i <= 1; i+=2)
	{
	
		Position relativeGridCoor(i, 0);
		Position searchKey = world_coor + relativeGridCoor;
		auto it = tileMap.find(searchKey);
		if (it != tileMap.end())
		{
			cv::Point relativeOffset(0, i * image_height * (1 - verticalOverlap));
			std::shared_ptr<Task> task_ptr = taskProducer->taskProduce(tile, it->second, relativeGridCoor, relativeOffset, platformDeviationCoor);// 生产数据
			taskQueue.push(task_ptr); 
		}
	}
	for (int i = -1; i <= 1; i += 2)
	{
		Position relativeGridCoor(0, i);
		Position searchKey = world_coor + relativeGridCoor;
		auto it = tileMap.find(searchKey);
		if (it != tileMap.end())
		{
			cv::Point relativeOffset(i * image_width * (1 - horizontalOverlap), 0);
			std::shared_ptr<Task> task_ptr = taskProducer->taskProduce(tile, it->second, relativeGridCoor, relativeOffset, platformDeviationCoor);// 生产数据
			taskQueue.push(task_ptr);
		}
	}
	//LOG_INFO("default", "postImage Finish!");
	return INFO_OK;
}

void StitchApp::saveImage(const cv::Point & world_coor, const cv::Mat & input)
{
	if (_params.cacheDir != "")
	{
		std::string saveDir =  _params.cacheDir + "/data";
		fs::path save_root = saveDir;
		if (!fs::exists(save_root)) {
			if (fs::create_directory(save_root))
			{
				LOG_INFO("default", "Directory created: " + saveDir);
			}
			else
			{
				LOG_ERROR("default", "Failed to create directory: " + saveDir);
			}
		}
		std::string savePath = saveDir + "/" + std::to_string(world_coor.x) + "_" + std::to_string(world_coor.y) + ".bmp";
		//cv::imwrite(savePath, input);
	}
}

int StitchApp::postFinish()
{
	LOG_INFO("default", "postFinish Begin!");
	//关闭Task队列生产
	taskQueue.setProduceFinish();
	//等待Task 队列处理完毕，线程退出
	for (auto& t: taskConsumerThreads)
	{
		t.join();
	}
	LOG_INFO("default", "postFinish Finish!");
	return INFO_OK;
}

int StitchApp::platformModel() 
{
	LOG_INFO("default", "platformModeling Begin!");
	if (_params.cacheDir != "")
	{
		saveTileMapInfos(_params.cacheDir, "platformModel");
	}
	int grid_width = tileMap.width();
	int grid_height = tileMap.height();
	int image_width = _params.imageWidth;
	int image_height = _params.imageHeight;
	float overlapUncertainty = _params.overlapUncertainty;
	float validCorrelationThreshold = _params.validCorrelationThreshold;

	float horizontalOverlap = 100 * _params.horizontalOverlap;
	float verticalOverlap = 100 * _params.verticalOverlap;

	// 平台建模类构造
	//platformModelObj->Init(grid_height, grid_width, image_width, image_height, overlapUncertainty, validCorrelationThreshold, tileMap, scanMode);
	platformModelObj->Init(image_width, image_height, overlapUncertainty, validCorrelationThreshold, horizontalOverlap, verticalOverlap);

	// 建模
	//int flag = platformModelObj->build(tileMap, scanMode);
	int flag = platformModelObj->newBuild(tileMap);
	if (flag != 1)
	{
		refineParam.repeatability = max(overlapUncertainty * image_width / 100.0f, overlapUncertainty * image_height/ 100.0f);
		LOG_INFO("default", "platformModeling error! repeatability=>" + std::to_string(refineParam.repeatability));
	}
	else
	{
		refineParam.repeatability = platformModelObj->repeatability;

	}

	LOG_INFO("default", "platformModeling Finish!");
	return 1;
}

int StitchApp::refineMatch() 
{
	//创建 refineConsumers线程
	//LOG_INFO("default", "refineMatch Begin!");

	//收集所有task
	for (size_t i = 0; i < taskConsumers.size(); i++)
	{
		while (!taskConsumers[i]->finishedTasks.empty())
		{
			finishedTaskVec.taskQueue.push(taskConsumers[i]->finishedTasks.front());
			taskConsumers[i]->finishedTasks.pop();
		}
	}

	if (_params.cacheDir != "")
	{
		saveTileMapInfos(_params.cacheDir, "refineMatch");
		saveFinishedTaskVec(_params.cacheDir);
	}
	std::string sRefineConsumerType = std::to_string(int(_params.refineConsumerType));
	for (int i = 0; i < _params.refineTaskConsumerNum; ++i)
	{
		std::shared_ptr<RefineConsumerDefault> consumer = factory<RefineConsumerDefault>::produce_shared(sRefineConsumerType);
		if (consumer == nullptr)
		{
			std::string msg = "RefineConsumerType:" + sRefineConsumerType + " 模块未注册！";
			LOG_ERROR("default", msg);
			return -1;
		}
		consumer->id = i;
		refineConsumers.emplace_back(consumer);
		refineConsumerThreads.emplace_back(&StitchApp::refineConsumeFunc, this, consumer);
	}
	//等待线程结束
	for (auto& t : refineConsumerThreads)
	{
		t.join();
	}
	//LOG_INFO("default", "refineMatch Finish!");
	return 1;
}

int StitchApp::pathPlanning() 
{
	//LOG_INFO("default", "pathPlanning Begin!");
	SPathInfo pathIn;
	pathIn.regularPathStr = _params.cacheDir;
	if (_params.cacheDir != "")
	{
		saveTileMapInfos(_params.cacheDir, "pathPlanning");
	}
	int flag = pathPlannObj->pathPlanning(tileMap, pathIn);
	//LOG_INFO("default", "pathPlanning Finish!");
	return flag;
}
	
int StitchApp::getWSISize(int& wsiWidth, int& wsiHeight,float** pImgCoordinate)
{
	//LOG_INFO("default", "getWSISize Begin!");
	blenderObj->stitchWidthHeightCalcute(tileMap, wsiWidth, wsiHeight, pImgCoordinate);
	//LOG_INFO("default", "getWSISize Finish!");
	return 1;
}

int StitchApp::blender(SyImage& image)
{
	//LOG_INFO("default", "blender Begin!");
	if (_params.cacheDir != "")
	{
		saveTileMapInfos(_params.cacheDir, "blender");
	}
	int flag = blenderObj->blender(tileMap, &image);
	//LOG_INFO("default", "blender Finish!");
	return flag;
}


int StitchApp::evaluateApp(float& fScore)
{
	LOG_INFO("default", "evaluateApp Begin!");
	if (_params.cacheDir != "")
	{
		saveTileMapInfos(_params.cacheDir, "evaluate");
	}
	int flag = evaluateObj->evaluate(tileMap, fScore);
	LOG_INFO("default", "evaluateApp Finish!");
	return flag;
}

void StitchApp::saveConfig(const std::string& saveDir) 
{
	fs::path save_root = saveDir;
	if (!fs::exists(save_root)) {
		if (fs::create_directory(save_root)) 
		{
			LOG_INFO("default", "Directory created: " + saveDir);
		}
		else 
		{
			LOG_ERROR("default", "Failed to create directory: " + saveDir);
		}
	}
	std::string configSavePath = saveDir + "/config.json";
	
	nlohmann::json jsonObj;
	jsonObj["tileProducerType"] = _params.tileProducerType;
	jsonObj["taskProducerType"] = _params.taskProducerType;
	jsonObj["taskConsumerType"] = _params.taskConsumerType;
	jsonObj["refineConsumerType"] = _params.refineConsumerType;
	jsonObj["pathPlanningType"] = _params.pathPlanningType;
	jsonObj["stitchBlenderType"] = _params.stitchBlenderType;
	jsonObj["matchTaskConsumerNum"] = _params.matchTaskConsumerNum;
	jsonObj["refineTaskConsumerNum"] = _params.refineTaskConsumerNum;
	jsonObj["maxTaskQueueSize"] = _params.maxTaskQueueSize;
	jsonObj["storeInMemory"] = _params.storeInMemory;
	jsonObj["copyImage"] = _params.copyImage;
	jsonObj["imageHeight"] = _params.imageHeight;
	jsonObj["imageWidth"] = _params.imageWidth;
	jsonObj["imageChannels"] = _params.imageChannels;
	jsonObj["_mappingFileDir"] = _params._mappingFileDir;
	jsonObj["stageRepeatabilityX"] = _params.stageRepeatabilityX;
	jsonObj["stageRepeatabilityY"] = _params.stageRepeatabilityY;
	jsonObj["horizontalOverlap"] = _params.horizontalOverlap;;
	jsonObj["verticalOverlap"] = _params.verticalOverlap;;
	jsonObj["overlapUncertainty"] = _params.overlapUncertainty;
	jsonObj["validCorrelationThreshold"] = _params.validCorrelationThreshold;

	std::ofstream file(configSavePath);
	if (file.is_open())
	{
		file << jsonObj.dump(4); // 4 是缩进级别
		file.close();
		LOG_INFO("default", "JSON saved to" + configSavePath);
	}
	else {
		LOG_ERROR("default", "Could not open file for writing." + configSavePath);
	}
	return;
}

int StitchApp::loadConfig(const std::string& saveDir)
{
	fs::path save_root = saveDir;
	if (!fs::exists(save_root)) 
	{
		LOG_ERROR("default", "cache path error: " + save_root.string());
		return INFO_FAIL;
		
	} 
	fs::path configSavePath = saveDir + "/config.json";
	if (!fs::exists(configSavePath))
	{
		LOG_ERROR("default", "config json path error: " + configSavePath.string());
		return INFO_FAIL;
	}
	std::string savePath = configSavePath.string();
	std::ifstream file(savePath);
	if (file.is_open()) {
		nlohmann::json jsonObj;
		file >> jsonObj;

		jsonObj.at("tileProducerType").get_to(_params.tileProducerType);
		jsonObj.at("taskProducerType").get_to(_params.taskProducerType);
		jsonObj.at("taskConsumerType").get_to(_params.taskConsumerType);
		jsonObj.at("refineConsumerType").get_to(_params.refineConsumerType);
		jsonObj.at("pathPlanningType").get_to(_params.pathPlanningType);
		jsonObj.at("stitchBlenderType").get_to(_params.stitchBlenderType);
		jsonObj.at("matchTaskConsumerNum").get_to(_params.matchTaskConsumerNum);
		jsonObj.at("refineTaskConsumerNum").get_to(_params.refineTaskConsumerNum);
		jsonObj.at("maxTaskQueueSize").get_to(_params.maxTaskQueueSize);
		jsonObj.at("storeInMemory").get_to(_params.storeInMemory);
		jsonObj.at("copyImage").get_to(_params.copyImage);
		jsonObj.at("imageHeight").get_to(_params.imageHeight);
		jsonObj.at("imageWidth").get_to(_params.imageWidth);
		jsonObj.at("imageChannels").get_to(_params.imageChannels);
		jsonObj.at("_mappingFileDir").get_to(_params._mappingFileDir);
		jsonObj.at("stageRepeatabilityX").get_to(_params.stageRepeatabilityX);
		jsonObj.at("stageRepeatabilityY").get_to(_params.stageRepeatabilityY);
		jsonObj.at("horizontalOverlap").get_to(_params.horizontalOverlap);;
		jsonObj.at("verticalOverlap").get_to(_params.verticalOverlap);;
		jsonObj.at("overlapUncertainty").get_to(_params.overlapUncertainty);
		jsonObj.at("validCorrelationThreshold").get_to(_params.validCorrelationThreshold);
		_params.cacheDir = "";
		file.close();
		LOG_INFO("default", "JSON read success." + savePath);
	}
	else {
		LOG_ERROR("default", "Could not open file for reading." + savePath);
	}
	return INFO_OK;
}

void StitchApp::saveTileMapInfos(const std::string& saveDir, const std::string& processName) 
{
	fs::path save_root = saveDir;
	if (!fs::exists(save_root)) {
		if (fs::create_directory(save_root))
		{
			LOG_INFO("default", "Directory created: " + saveDir);
		}
		else
		{
			LOG_ERROR("default", "Failed to create directory: " + saveDir);
		}
	}
	std::string configSavePath = saveDir + "/" + processName + ".json";

	nlohmann::json jsonObj = tileMap.toJson();

	jsonObj["refineParam"]["repeatability"] = refineParam.repeatability;

	std::ofstream file(configSavePath);
	if (file.is_open())
	{
		file << jsonObj.dump(4); // 4 是缩进级别
		file.close();
		LOG_INFO("default", "JSON saved to" + configSavePath);
	}
	else {
		LOG_ERROR("default", "Could not open file for writing." + configSavePath);
	}
	return;
}

int StitchApp::loadTileMap(const std::string& saveDir, const std::string& processName) 
{
	fs::path save_root = saveDir;
	if (!fs::exists(save_root)) {
		if (fs::create_directory(save_root))
		{
			LOG_INFO("default", "Directory created: " + saveDir);
		}
		else
		{
			LOG_ERROR("default", "Failed to create directory: " + saveDir);
			return INFO_FAIL;
		}
	}
	std::string configSavePath = saveDir + "/" + processName + ".json";

	std::ifstream file(configSavePath);
	if (file.is_open())
	{
		nlohmann::json jsonObj;
		file >> jsonObj;
		tileMap.fromJson(jsonObj, saveDir);

		nlohmann::json jsonObj_RefineParam = jsonObj["refineParam"];
		jsonObj_RefineParam["repeatability"].get_to(refineParam.repeatability);

		file.close();
		LOG_INFO("default", "JSON read success." + configSavePath);
	}
	else {
		LOG_ERROR("default", "Could not open file for reading." + configSavePath);
		return INFO_FAIL;
	}
	return INFO_OK;
}

void StitchApp::saveFinishedTaskVec(const std::string& saveDir) 
{
	fs::path save_root = saveDir;
	if (!fs::exists(save_root)) {
		if (fs::create_directory(save_root))
		{
			LOG_INFO("default", "Directory created: " + saveDir);
		}
		else
		{
			LOG_ERROR("default", "Failed to create directory: " + saveDir);
		}
	}
	std::string taskSavePath = saveDir + "/"  + "task.json";

	nlohmann::json jsonObj = finishedTaskVec.toJson();
	std::ofstream file(taskSavePath);
	if (file.is_open())
	{
		file << jsonObj.dump(4); // 4 是缩进级别
		file.close();
		LOG_INFO("default", "JSON saved to" + taskSavePath);
	}
	else 
	{
		LOG_ERROR("default", "Could not open file for writing." + taskSavePath);
	}
}

int StitchApp::loadFinishedTaskVec(const std::string& saveDir) 
{
	fs::path save_root = saveDir;
	if (!fs::exists(save_root)) {

		LOG_ERROR("default", "saveDir path error: " + saveDir);
		return INFO_FAIL;
	}
	std::string taskPath = saveDir + "/" + "task.json";
	std::ifstream file(taskPath);
	if (file.is_open())
	{
		nlohmann::json jsonObj;
		file >> jsonObj;
		finishedTaskVec.fromJson(jsonObj, tileMap);
	}
	return INFO_OK;
}

int StitchApp::taskConsumeFunc(std::shared_ptr<TaskConsumerDefault>& consumer)
{
	while (true) 
	{
		std::shared_ptr<Task> task;
		bool flag = taskQueue.take(task);
		if (flag)
		{
			//LOG_INFO("default", "Task consumer id: " + std::to_string(consumer->getId()) + " consume! ");
			consumer->taskConsume(task);
			consumer->finishedTasks.push(task);
		}
		else
		{
			LOG_INFO("default", "Task consumer id: " + std::to_string(consumer->getId()) + " exit! ");
			break;
		}
	}
	return INFO_OK;
}

int StitchApp::refineConsumeFunc(std::shared_ptr<RefineConsumerDefault>& consumer) 
{
	while (true)
	{
		std::shared_ptr<Task> task;
		bool flag = finishedTaskVec.take(task);
		if (flag)
		{
			//LOG_INFO("default", "Refine consumer id: " + std::to_string(consumer->id ) +  " consume! ");
			consumer->refineTaskConsume(task, refineParam);
		}
		else
		{
			LOG_INFO("default", "Refine consumer id: " + std::to_string(consumer->id) + " exit! ");
			break;
		}
	}
	return INFO_OK;
}
